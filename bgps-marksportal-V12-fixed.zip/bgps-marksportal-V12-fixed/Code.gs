/**
 * BG PUBLIC SCHOOL - MARKS + QUESTION PAPER PORTAL
 * Version: V12 safe paste, idempotent submission and single-final workflow hardening
 *
 * Deploy Settings:
 *   Execute as: Me
 *   Who has access: Anyone
 */

const MASTER_SHEET_NAME = 'Master';
const PAPER_SHEET_NAME = 'QuestionPapers';
const PAPER_DRAFTS_SHEET_NAME = 'PaperDrafts';
const PAPER_FOLDER_NAME = 'BGPS Question Papers';
const PAPER_FOLDER_PROPERTY = 'BGPS_QUESTION_PAPER_FOLDER_ID';
const PAPER_SETTINGS_PROPERTY = 'BGPS_PAPER_MODULE_SETTINGS_V2';
const PAPER_WORKFLOW_REPAIR_PROPERTY = 'BGPS_PAPER_WORKFLOW_REPAIR_V12';
const LEGACY_PAPER_FOLDER_NAME = 'BGPS Question Papers DEMO';
const LEGACY_PAPER_FOLDER_PROPERTY = 'BGPS_QUESTION_PAPER_FOLDER_ID_DEMO';
const LEGACY_PAPER_SETTINGS_PROPERTY = 'BGPS_PAPER_MODULE_SETTINGS_V2_DEMO';
const PAPER_PREVIEW_PROPERTY_PREFIX = 'BGPS_PAPER_PREVIEW_';
const GOOGLE_DOC_MIME = 'application/vnd.google-apps.document';
const PAPER_MAX_BYTES = 8 * 1024 * 1024;
const DRAFT_MAX_PAYLOAD_BYTES = 8 * 1024 * 1024;
const DRAFT_INLINE_HTML_MAX_BYTES = 35000;
const DRAFT_INLINE_JSON_MAX_BYTES = 45000;
const DRAFT_MAX_EMBEDDED_IMAGE_BYTES = 1500 * 1024;
const PAPER_REQUEST_TOKEN_MAX_LENGTH = 180;
const ADMIN_PIN_PROPERTY = 'BGPS_ADMIN_PIN';
const DEFAULT_TEACHER_PIN_PROPERTY = 'BGPS_DEFAULT_TEACHER_PIN';
const TEACHER_NAMES_PROPERTY = 'BGPS_TEACHER_NAMES';
const AUTH_FAIL_CACHE_PREFIX = 'bgps-auth-fail-';
const AUTH_BLOCK_SECONDS = 300;
const AUTH_MAX_FAILURES = 5;

const ADMIN_ID = 'ADMIN';
const PAPER_ONLY_TEACHER_ID = 'T-16';
const PRE_PRIMARY_CHAPTER_VALUE = 'Not applicable (Pre-Primary)';

const TEACHER_CLASS_MAP = Object.freeze({
  'T-1': 'Playgroup', 'T-2': 'LKG', 'T-3': 'UKG', 'T-4': 'Class 1', 'T-5': 'Class 2',
  'T-6': 'Class 3', 'T-7': 'Class 4', 'T-8': 'Class 5', 'T-9': 'Class 6', 'T-10': 'Class 7',
  'T-11': 'Class 8', 'T-12': 'Class 9', 'T-13': 'Class 10', 'T-14': 'Class 11', 'T-15': 'Class 12',
  'T-16': 'PAPER_ONLY',
  'ADMIN': 'ALL_CLASSES'
});

const ALL_CLASSES = [
  'Playgroup', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5',
  'Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10', 'Class 11', 'Class 12'
];

const MASTER_HEADERS = [
  'Timestamp', 'Teacher ID', 'Class', 'Subject', 'Exam Type',
  'Component', 'Roll No', 'Marks', 'Max Marks'
];

const PAPER_HEADERS = [
  'Paper ID', 'Uploaded At', 'Updated At', 'Teacher ID', 'Class', 'Subject',
  'Exam / Term', 'Chapters', 'Max Marks', 'Exam Date', 'Teacher Note',
  'Original File Name', 'MIME Type', 'File Size', 'Drive File ID',
  'Version', 'Status', 'Admin Note', 'Source Type', 'Time Allowed',
  'Total Questions', 'Paper Content JSON', 'Teacher Name', 'Preview/PDF File ID'
];

const PAPER_DRAFTS_HEADERS = [
  'Draft ID', 'Created At', 'Updated At', 'Teacher ID', 'Title', 'Class',
  'Subject', 'Exam / Term', 'Chapters', 'Max Marks', 'Exam Date', 'Teacher Note',
  'Time Allowed', 'Instructions', 'Language Mode', 'Editor HTML', 'Body Text',
  'Detected Marks', 'Total Questions', 'Status', 'Source Type', 'Draft JSON', 'Content Drive File ID'
];

const DEFAULT_PAPER_SETTINGS = Object.freeze({
  settingsVersion: 10,
  emergencyLock: false,
  uploadEnabled: true,
  creatorEnabled: true,
  submissionEnabled: true,
  marksEntryEnabled: true,
  adminNotice: 'Paper Upload and Paper Creator are open.'
});

function doGet(e) {
  return jsonOutput_({ ok: true, service: 'BGPS ERP API' });
}

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) throw new Error('Empty request.');
    const request = JSON.parse(e.postData.contents);
    const action = String(request.action || '').trim();

    if (action === 'login') {
      return jsonOutput_(login_(request.teacherId, request.pin));
    }

    const user = authenticate_(request.teacherId, request.pin);

    switch (action) {
      case 'upsert':
        return jsonOutput_(upsertMarks_(user, request.entries));
      case 'getMarks':
        return jsonOutput_(getMarks_(user, request.filters));
      case 'getPaperSettings':
        return jsonOutput_(getPaperSettingsResponse_(user));
      case 'updatePaperSettings':
        return jsonOutput_(updatePaperSettings_(user, request.settings));
      case 'uploadPaper':
        return jsonOutput_(uploadPaper_(user, request.paper));
      case 'importDocxPaper':
        return jsonOutput_(importDocxPaper_(user, request.paper));
      case 'createManualPaper':
        return jsonOutput_(createManualPaper_(user, request.paper));
      case 'listPapers':
        return jsonOutput_(listPapers_(user));
      case 'getPaperFile':
        return jsonOutput_(getPaperFile_(user, request.paperId));
      case 'getPaperOriginalFile':
        return jsonOutput_(getPaperOriginalFile_(user, request.paperId));
      case 'getPaperPreview':
        return jsonOutput_(getPaperPreview_(user, request.paperId));
      case 'getBgpsStandardPreview':
        return jsonOutput_(getBgpsStandardPreview_(user, request.paperId));
      case 'saveBgpsStandardPreview':
        return jsonOutput_(saveBgpsStandardPreview_(user, request.paperId, request.editedContentHtml));
      case 'getPaperContent':
        return jsonOutput_(getPaperContent_(user, request.paperId));
      case 'updatePaperContentAdmin':
        return jsonOutput_(updatePaperContentAdmin_(user, request.paperId, request.paper));
      case 'updatePaperStatus':
        return jsonOutput_(updatePaperStatus_(user, request.paperId, request.status, request.adminNote, request.deleteOriginalAfterApproval === true));
      case 'sendReminder':
        return jsonOutput_(sendReminder_(user, request.reminder));
      case 'addPrincipalComment':
        return jsonOutput_(addPrincipalComment_(user, request.comment));
      case 'listPrincipalActivity':
        return jsonOutput_(listPrincipalActivity_(user));
      case 'deletePaper':
        return jsonOutput_(deletePaper_(user, request.paperId));
      case 'bulkDeleteApprovedOriginals':
        return jsonOutput_(bulkDeleteApprovedOriginals_(user));
      case 'repairPaperWorkflow':
        return jsonOutput_(repairPaperWorkflow_(user));
      case 'savePaperDraft':
        return jsonOutput_(savePaperDraft_(user, request.draft));
      case 'listPaperDrafts':
        return jsonOutput_(listPaperDrafts_(user));
      case 'getPaperDraft':
        return jsonOutput_(getPaperDraft_(user, request.draftId));
      case 'getPaperDraftPreview':
        return jsonOutput_(getPaperDraftPreview_(user, request.draftId));
      case 'deletePaperDraft':
        return jsonOutput_(deletePaperDraft_(user, request.draftId));
      case 'submitPaperDraft':
        return jsonOutput_(submitPaperDraft_(user, request.draftId));
      default:
        throw new Error('Unsupported action: ' + action);
    }
  } catch (error) {
    return jsonOutput_({ ok: false, error: safeErrorMessage_(error) });
  }
}

function authenticate_(teacherId, pin) {
  const id = String(teacherId || '').trim().toUpperCase();
  const suppliedPin = String(pin || '');
  if (!id) throw new Error('Teacher ID is required.');

  const cache = CacheService.getScriptCache();
  const failKey = AUTH_FAIL_CACHE_PREFIX + id;
  const failCount = Number(cache.get(failKey) || 0);
  if (failCount >= AUTH_MAX_FAILURES) {
    throw new Error('Too many failed attempts. Please try again in 5 minutes.');
  }

  const knownTeacher = Object.prototype.hasOwnProperty.call(TEACHER_CLASS_MAP, id);
  const expectedPin = knownTeacher ? getExpectedPin_(id) : '';
  if (!knownTeacher || suppliedPin !== expectedPin) {
    cache.put(failKey, String(failCount + 1), AUTH_BLOCK_SECONDS);
    throw new Error('Invalid credentials.');
  }
  cache.remove(failKey);
  return {
    id: id,
    isAdmin: id === ADMIN_ID,
    paperOnly: id === PAPER_ONLY_TEACHER_ID,
    assignedClass: TEACHER_CLASS_MAP[id]
  };
}

function login_(teacherId, pin) {
  const id = String(teacherId || '').trim().toUpperCase();
  if (!id) throw new Error('Teacher ID is required.');
  const user = authenticate_(id, pin);
  return {
    ok: true,
    user: {
      teacherId: user.id,
      isAdmin: user.isAdmin,
      paperOnly: user.paperOnly === true,
      assignedClass: user.assignedClass
    }
  };
}

function getExpectedPin_(teacherId) {
  const properties = PropertiesService.getScriptProperties();
  const adminPin = String(properties.getProperty(ADMIN_PIN_PROPERTY) || '').trim();
  const teacherPin = String(properties.getProperty(DEFAULT_TEACHER_PIN_PROPERTY) || '').trim();

  if (teacherId === ADMIN_ID) {
    if (!adminPin) throw new Error('Backend configuration missing: set Script Property ' + ADMIN_PIN_PROPERTY + '.');
    return adminPin;
  }
  if (!teacherPin) throw new Error('Backend configuration missing: set Script Property ' + DEFAULT_TEACHER_PIN_PROPERTY + '.');
  return teacherPin;
}

function getTeacherDisplayName_(teacherId) {
  const id = cleanText_(teacherId).toUpperCase();
  try {
    const configured = parseJsonObject_(PropertiesService.getScriptProperties().getProperty(TEACHER_NAMES_PROPERTY));
    return cleanText_(configured[id]) || (id === PAPER_ONLY_TEACHER_ID ? 'Subject Teacher' : id);
  } catch (ignored) {
    return id;
  }
}

function getMarks_(user, filters) {
  if (user.paperOnly) throw new Error('T-16 is a paper-submission account and cannot access marks.');
  const requested = filters && filters.className ? cleanText_(filters.className) : '';
  const classFilter = user.isAdmin
    ? requested
    : user.assignedClass;

  const subjectFilter = cleanText_(filters && filters.subject).toUpperCase();
  const examTypeFilter = cleanText_(filters && filters.examType).toUpperCase();
  const componentFilter = cleanText_(filters && filters.component).toUpperCase();
  const rollNoFilter = normalizeRoll_(filters && filters.rollNo).toUpperCase();

  const sheet = ensureMasterSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { ok: true, rows: [], total: 0 };

  const rows = sheet.getRange(2, 1, lastRow - 1, MASTER_HEADERS.length).getValues();
  const out = [];
  rows.forEach(function(row) {
    const className = cleanText_(row[2]);
    const subject = cleanText_(row[3]).toUpperCase();
    const examType = cleanText_(row[4]).toUpperCase();
    const component = cleanText_(row[5]).toUpperCase();
    const rollNo = normalizeRoll_(row[6]).toUpperCase();

    if (classFilter && className !== classFilter) return;
    if (subjectFilter && subject !== subjectFilter) return;
    if (examTypeFilter && examType !== examTypeFilter) return;
    if (componentFilter && component !== componentFilter) return;
    if (rollNoFilter && rollNo !== rollNoFilter) return;

    out.push({
      timestamp: isoDate_(row[0]),
      teacherId: cleanText_(row[1]),
      className: className,
      subject: cleanText_(row[3]),
      examType: cleanText_(row[4]),
      component: cleanText_(row[5]),
      rollNo: normalizeRoll_(row[6]),
      marks: row[7],
      maxMarks: Number(row[8]) || 0
    });
  });

  return { ok: true, rows: out, total: out.length };
}

function upsertMarks_(user, entries) {
  if (!Array.isArray(entries) || !entries.length) {
    throw new Error('No marks entries received.');
  }
  const settings = getPaperSettings_();
  if (settings.marksEntryEnabled === false) {
    throw new Error(settings.adminNotice || 'Marks Entry is currently closed by Admin.');
  }

  const sheet = ensureMasterSheet_();
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  try {
    const lastRow = sheet.getLastRow();
    const existing = lastRow > 1 ? sheet.getRange(2, 1, lastRow - 1, MASTER_HEADERS.length).getValues() : [];
    const keyToSheetRow = new Map();

    existing.forEach(function(row, index) {
      const key = marksKey_(row[2], row[3], row[4], row[5], row[6]);
      if (key) keyToSheetRow.set(key, index + 2);
    });

    let created = 0;
    let updated = 0;
    const normalizedByKey = new Map();

    entries.forEach(function(entry) {
      const className = cleanText_(entry.class);
      const subject = cleanText_(entry.subject).toUpperCase();
      const exam = cleanText_(entry.examType);
      const component = cleanText_(entry.type).toUpperCase();
      const rollNo = normalizeRoll_(entry.rollNo);
      const marks = normalizeMarksValue_(entry.marks);
      const maxMarks = Number(entry.maxMarks);

      // MARKS ENTRY: strict class enforcement
      enforceMarksClassAccess_(user, className);
      if (!className || !subject || !exam || !component || !rollNo) {
        throw new Error('A marks entry is missing Class, Subject, Exam, Component or Roll No.');
      }
      if (!Number.isFinite(maxMarks) || maxMarks <= 0) {
        throw new Error('Invalid maximum marks.');
      }
      if (typeof marks === 'number' && (marks < 0 || marks > maxMarks)) {
        throw new Error('Marks for Roll ' + rollNo + ' must be between 0 and ' + maxMarks + '.');
      }

      const key = marksKey_(className, subject, exam, component, rollNo);
      normalizedByKey.set(key, [new Date(), user.id, className, subject, exam, component, rollNo, marks, maxMarks]);
    });

    const updates = [];
    const appends = [];
    normalizedByKey.forEach(function(rowValues, key) {
      const targetRow = keyToSheetRow.get(key);
      if (targetRow) {
        updates.push({ rowNumber: targetRow, rowValues: rowValues });
        updated += 1;
      } else {
        appends.push(rowValues);
        created += 1;
      }
    });

    updates.forEach(function(item) {
      sheet.getRange(item.rowNumber, 1, 1, MASTER_HEADERS.length).setValues([item.rowValues]);
    });

    if (appends.length) {
      sheet.getRange(sheet.getLastRow() + 1, 1, appends.length, MASTER_HEADERS.length).setValues(appends);
    }

    SpreadsheetApp.flush();
    return { ok: true, created: created, updated: updated, saved: created + updated };
  } finally {
    lock.releaseLock();
  }
}

function getPaperSettingsResponse_(user) {
  const settings = getPaperSettings_();
  return {
    ok: true,
    settings: settings,
    permissions: {
      isAdmin: user.isAdmin,
      canUpload: user.isAdmin ? false : (!settings.emergencyLock && settings.uploadEnabled && settings.submissionEnabled),
      canCreate: user.isAdmin ? false : (!settings.emergencyLock && settings.creatorEnabled && settings.submissionEnabled),
      canEnterMarks: user.isAdmin ? true : (!user.paperOnly && settings.marksEntryEnabled !== false),
      canViewLibrary: true
    }
  };
}

function updatePaperSettings_(user, input) {
  if (!user.isAdmin) throw new Error('Only Admin can change question-paper controls.');
  const current = getPaperSettings_();
  const next = {
    settingsVersion: 10,
    emergencyLock: toBoolean_(input && input.emergencyLock, current.emergencyLock),
    uploadEnabled: toBoolean_(input && input.uploadEnabled, current.uploadEnabled),
    creatorEnabled: toBoolean_(input && input.creatorEnabled, current.creatorEnabled),
    submissionEnabled: toBoolean_(input && input.submissionEnabled, current.submissionEnabled),
    marksEntryEnabled: toBoolean_(input && input.marksEntryEnabled, current.marksEntryEnabled !== false),
    adminNotice: cleanText_(input && input.adminNotice).slice(0, 300)
  };
  PropertiesService.getScriptProperties().setProperty(PAPER_SETTINGS_PROPERTY, JSON.stringify(next));
  return { ok: true, settings: next };
}

function getPaperSettings_() {
  const properties = PropertiesService.getScriptProperties();
  let raw = properties.getProperty(PAPER_SETTINGS_PROPERTY);
  if (!raw) {
    raw = properties.getProperty(LEGACY_PAPER_SETTINGS_PROPERTY);
    if (raw) properties.setProperty(PAPER_SETTINGS_PROPERTY, raw);
  }
  if (!raw) return Object.assign({}, DEFAULT_PAPER_SETTINGS);
  try {
    const parsed = JSON.parse(raw);
    const legacySettings = Number(parsed.settingsVersion || 0) < 10;
    const normalized = {
      settingsVersion: 10,
      emergencyLock: Boolean(parsed.emergencyLock),
      uploadEnabled: parsed.uploadEnabled !== false,
      creatorEnabled: legacySettings ? true : parsed.creatorEnabled !== false,
      submissionEnabled: parsed.submissionEnabled !== false,
      marksEntryEnabled: parsed.marksEntryEnabled !== false,
      adminNotice: cleanText_(parsed.adminNotice || DEFAULT_PAPER_SETTINGS.adminNotice).slice(0, 300)
    };
    if (legacySettings) properties.setProperty(PAPER_SETTINGS_PROPERTY, JSON.stringify(normalized));
    return normalized;
  } catch (ignored) {
    return Object.assign({}, DEFAULT_PAPER_SETTINGS);
  }
}

function assertPaperChannelOpen_(channel) {
  const settings = getPaperSettings_();
  if (settings.emergencyLock) {
    throw new Error(settings.adminNotice || 'Question-paper activity is temporarily locked by Admin.');
  }
  if (!settings.submissionEnabled) {
    throw new Error(settings.adminNotice || 'New question-paper submissions are currently closed.');
  }
  if (channel === 'upload' && !settings.uploadEnabled) {
    throw new Error(settings.adminNotice || 'Question-paper upload is currently disabled by Admin.');
  }
  if (channel === 'creator' && !settings.creatorEnabled) {
    throw new Error(settings.adminNotice || 'Manual paper creation is currently disabled by Admin.');
  }
  return settings;
}

function uploadPaper_(user, paper) {
  if (!paper || typeof paper !== 'object') {
    throw new Error('Question paper details are missing.');
  }
  if (user.isAdmin) {
    throw new Error('Admin upload is disabled. Use the Admin library to review teacher submissions.');
  }
  const className = cleanText_(paper.className);
  const subject = cleanText_(paper.subject);
  const exam = cleanText_(paper.exam);
  const title = cleanText_(paper.title || paper.paperTitle || '').slice(0, 180);
  const chapters = normalizePaperChapters_(className, paper.chapters);
  const maxMarks = Number(paper.maxMarks);
  const examDate = cleanText_(paper.examDate);
  const note = cleanText_(paper.note).slice(0, 250);
  const timeAllowed = cleanText_(paper.timeAllowed || inferPaperTime_(maxMarks)).slice(0, 80);
  const originalFileName = cleanText_(paper.fileName);
  const mimeType = cleanText_(paper.mimeType).toLowerCase();
  const declaredFileSize = Number(paper.fileSize) || 0;
  const fileBase64 = String(paper.fileBase64 || '');
  const revisionPaperId = cleanText_(paper.parentPaperId || paper.originalPaperId || '');
  const submissionToken = normalizeRequestToken_(paper.requestId || paper.submissionToken || '');

  // PAPER UPLOAD: free class selection for all teachers
  enforcePaperClassAccess_(user, className);

  if (!className || !subject || !exam || !chapters || !originalFileName || !fileBase64) {
    throw new Error(isPrePrimaryClass_(className)
      ? 'Class, Subject, Exam and File are required.'
      : 'Class, Subject, Exam, Chapters and File are required.');
  }
  if (!Number.isFinite(maxMarks) || maxMarks <= 0) {
    throw new Error('Maximum marks must be greater than zero.');
  }

  const extension = fileExtension_(originalFileName);
  const allowedPdf = mimeType === 'application/pdf' || extension === 'pdf';
  const allowedDocx = mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || extension === 'docx';
  if (!allowedPdf && !allowedDocx) {
    throw new Error('Only PDF and DOCX files are allowed.');
  }
  if (revisionPaperId && !allowedDocx) {
    throw new Error('A returned uploaded paper must be replaced with a corrected DOCX file.');
  }

  let bytes;
  try {
    bytes = Utilities.base64Decode(fileBase64.replace(/^data:[^,]+,/, ''));
  } catch (decodeError) {
    throw new Error('The uploaded file data could not be decoded. Select the PDF/DOCX again and retry.');
  }
  if (!bytes.length) throw new Error('The uploaded file is empty.');
  if (bytes.length > PAPER_MAX_BYTES || declaredFileSize > PAPER_MAX_BYTES) {
    throw new Error('The file exceeds the 8 MB upload limit.');
  }
  validateUploadedFileSignature_(bytes, allowedPdf ? 'pdf' : 'docx');
  if (!allowedPdf) validateDocxPackageIntegrity_(bytes);

  const effectiveMime = allowedPdf ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
  const sheet = ensureQuestionPaperSheet_();
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  let createdFile = null;
  let metadataPersisted = false;
  try {
    const previousSubmission = submissionToken ? findPaperBySubmissionToken_(sheet, user.id, submissionToken) : null;
    if (previousSubmission) return idempotentPaperResponse_(previousSubmission);

    let revisionRecord = null;
    if (revisionPaperId) {
      revisionRecord = findPaperRecord_(revisionPaperId);
      if (cleanText_(revisionRecord.teacherId).toUpperCase() !== user.id) {
        throw new Error('You do not have permission to replace this paper.');
      }
      if (cleanText_(revisionRecord.status) !== 'Correction Required') {
        throw new Error(cleanText_(revisionRecord.status) === 'Approved'
          ? 'Approved papers are final for teachers.'
          : 'This uploaded paper can be replaced only after the Principal returns it for correction.');
      }
    }
    // Correction replacements are existing Principal-requested revisions and
    // remain resubmittable even when the general upload window is closed.
    if (!revisionRecord) assertPaperChannelOpen_('upload');

    const version = nextPaperVersion_(sheet, className, subject, exam);
    const paperId = revisionRecord ? revisionRecord.paperId : Utilities.getUuid();
    const now = new Date();
    const folder = getQuestionPaperFolder_();
    const safeStoredName = buildStoredPaperName_(className, subject, exam, version, allowedPdf ? 'pdf' : 'docx');
    const blob = Utilities.newBlob(bytes, effectiveMime, safeStoredName);
    const file = folder.createFile(blob);
    createdFile = file;

    const contentRecord = {
      title: title,
      timeAllowed: timeAllowed,
      originalPaperId: revisionRecord ? (cleanText_(parseJsonObject_(revisionRecord.contentJson).originalPaperId) || revisionRecord.paperId) : paperId,
      parentPaperId: revisionRecord ? revisionRecord.paperId : '',
      previousVersion: revisionRecord ? Number(revisionRecord.version || 0) : 0,
      wasCorrectionResubmission: Boolean(revisionRecord),
      sourceType: 'Upload',
      originalFileName: originalFileName,
      submissionToken: submissionToken
    };
    const teacherName = getTeacherDisplayName_(user.id);

    if (revisionRecord) {
      const row = revisionRecord.rowNumber;
      sheet.getRange(row, 3).setValue(now);
      sheet.getRange(row, 5, 1, 10).setValues([[
        className, subject, exam, chapters, maxMarks,
        examDate, note, originalFileName, effectiveMime, bytes.length
      ]]);
      sheet.getRange(row, 15).setValue(file.getId());
      sheet.getRange(row, 16).setValue(version);
      sheet.getRange(row, 17).setValue('Submitted');
      // Column 18 (Principal note) is intentionally preserved so the returned instruction remains visible during re-review.
      sheet.getRange(row, 19).setValue('Upload');
      sheet.getRange(row, 20).setValue(timeAllowed);
      sheet.getRange(row, 21).setValue(0);
      sheet.getRange(row, 22).setValue(JSON.stringify(contentRecord));
      sheet.getRange(row, 23).setValue(teacherName);
      sheet.getRange(row, 24).setValue(allowedPdf ? file.getId() : '');
    } else {
      sheet.appendRow([
        paperId, now, now, user.id, className, subject, exam, chapters,
        maxMarks, examDate, note, originalFileName, effectiveMime, bytes.length,
        file.getId(), version, 'Submitted', '', 'Upload', timeAllowed, 0, JSON.stringify(contentRecord),
        teacherName, allowedPdf ? file.getId() : ''
      ]);
    }

    SpreadsheetApp.flush();
    metadataPersisted = true;

    if (revisionRecord) {
      if (revisionRecord.driveFileId && revisionRecord.driveFileId !== file.getId()) {
        trashFileQuietly_(revisionRecord.driveFileId);
      }
      if (revisionRecord.previewPdfFileId && revisionRecord.previewPdfFileId !== file.getId()) trashFileQuietly_(revisionRecord.previewPdfFileId);
      const previousRevisionContent = loadPaperContentRecord_(revisionRecord.contentJson);
      if (previousRevisionContent.standardizedHtmlFileId) trashFileQuietly_(previousRevisionContent.standardizedHtmlFileId);
      const previewPropertyKey = PAPER_PREVIEW_PROPERTY_PREFIX + cleanText_(revisionRecord.paperId);
      const cachedPreviewId = cleanText_(PropertiesService.getScriptProperties().getProperty(previewPropertyKey));
      if (cachedPreviewId && cachedPreviewId !== file.getId()) trashFileQuietly_(cachedPreviewId);
      PropertiesService.getScriptProperties().deleteProperty(previewPropertyKey);
    }

    return {
      ok: true,
      paperId: paperId,
      version: version,
      status: 'Submitted',
      sourceType: 'Upload',
      resubmitted: Boolean(revisionRecord),
      originalPreserved: true
    };
  } catch (error) {
    if (createdFile && !metadataPersisted) trashFileQuietly_(createdFile);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function importDocxPaper_(user, paper) {
  if (!paper || typeof paper !== 'object') throw new Error('DOCX paper details are missing.');
  if (user.isAdmin) throw new Error('Admin cannot import a teacher paper.');
  const importToken = normalizeRequestToken_(paper.requestId || paper.submissionToken || '');
  const importDraftId = importToken ? stableDraftIdFromRequest_('docx', importToken) : '';
  if (importDraftId) {
    try {
      const existingDraft = getPaperDraft_(user, importDraftId);
      if (existingDraft && existingDraft.draft) {
        return {
          ok: true,
          draftId: importDraftId,
          status: 'Draft',
          sourceType: 'DOCX Import',
          idempotent: true,
          message: 'This DOCX was already imported. The existing draft has been reopened.',
          warnings: Array.isArray(existingDraft.draft.importWarnings) ? existingDraft.draft.importWarnings : []
        };
      }
    } catch (existingDraftError) {
      if (!/draft not found/i.test(safeErrorMessage_(existingDraftError))) throw existingDraftError;
    }
  }
  const correctionParentId = cleanText_(paper.parentPaperId || paper.revisionParentId || '');
  let correctionRevision = null;
  if (correctionParentId) {
    correctionRevision = findPaperRecord_(correctionParentId);
    if (cleanText_(correctionRevision.teacherId).toUpperCase() !== user.id) {
      throw new Error('You do not have permission to correct this paper.');
    }
    if (cleanText_(correctionRevision.status) !== 'Correction Required') {
      throw new Error('Only a paper returned for correction can be replaced with a corrected DOCX.');
    }
  }
  if (!correctionRevision) assertPaperChannelOpen_('upload');

  const className = cleanText_(paper.className);
  const subject = cleanText_(paper.subject);
  const exam = cleanText_(paper.exam);
  const chapters = normalizePaperChapters_(className, paper.chapters);
  const maxMarks = Number(paper.maxMarks);
  const timeAllowed = cleanText_(paper.timeAllowed || inferPaperTime_(maxMarks)).slice(0, 80);
  const examDate = cleanText_(paper.examDate);
  const note = cleanText_(paper.note).slice(0, 250);
  const originalFileName = cleanText_(paper.fileName);
  const declaredFileSize = Number(paper.fileSize) || 0;
  const fileBase64 = String(paper.fileBase64 || '');
  const title = cleanText_(paper.title || originalFileName.replace(/\.docx$/i, '') || (className + ' ' + subject + ' ' + exam)).slice(0, 180);

  if (!correctionRevision) enforcePaperClassAccess_(user, className);
  if (!className || !subject || !exam || !chapters || !maxMarks || !timeAllowed || !originalFileName || !fileBase64) {
    throw new Error(isPrePrimaryClass_(className)
      ? 'Class, Subject, Exam, Maximum Marks, Time Allowed and DOCX file are required.'
      : 'Class, Subject, Exam, Chapters, Maximum Marks, Time Allowed and DOCX file are required.');
  }
  if (fileExtension_(originalFileName) !== 'docx') throw new Error('Select a .docx file for editable import.');
  if (!Number.isFinite(maxMarks) || maxMarks <= 0) throw new Error('Maximum marks must be greater than zero.');

  let bytes;
  try {
    bytes = Utilities.base64Decode(fileBase64.replace(/^data:[^,]+,/, ''));
  } catch (decodeError) {
    throw new Error('The DOCX file could not be read. Select it again and retry.');
  }
  if (!bytes.length) throw new Error('The selected DOCX file is empty.');
  if (bytes.length > PAPER_MAX_BYTES || declaredFileSize > PAPER_MAX_BYTES) throw new Error('The DOCX file exceeds the 8 MB upload limit.');
  validateUploadedFileSignature_(bytes, 'docx');
  validateDocxPackageIntegrity_(bytes);



  const sourceBlob = Utilities.newBlob(bytes, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', originalFileName);
  let sourceFile = null;
  try {
    sourceFile = getQuestionPaperFolder_().createFile(sourceBlob);
    const imported = convertDocxBlobToEditableHtml_(sourceBlob, originalFileName);
    const editorHtml = normalizePaperContentHtml_(imported.html);
    const bodyText = htmlToPlainText_(editorHtml);
    if (!bodyText) throw new Error('No editable text could be extracted from this DOCX file.');

    const result = savePaperDraft_(user, {
      draftId: importDraftId || undefined,
      requestId: importToken,
      title: title,
      className: className,
      subject: subject,
      exam: exam,
      chapters: chapters,
      maxMarks: maxMarks,
      examDate: examDate,
      note: note,
      timeAllowed: timeAllowed,
      instructions: cleanText_(paper.instructions || ''),
      languageMode: cleanText_(paper.languageMode || 'english'),
      editorHtml: editorHtml,
      bodyText: bodyText,
      detectedMarks: sumDetectedMarks_(editorHtml),
      totalQuestions: countQuestionBlocks_(editorHtml, bodyText),
      sourceType: 'DOCX Import',
      originalPaperId: cleanText_(paper.originalPaperId || ''),
      parentPaperId: cleanText_(paper.parentPaperId || ''),
      previousVersion: Number(paper.previousVersion || 0),
      originalFileName: originalFileName,
      sourceFileId: sourceFile.getId(),
      importWarnings: imported.warnings
    });
    if (result.idempotent === true && sourceFile) {
      trashFileQuietly_(sourceFile);
      sourceFile = null;
    }
    return {
      ok: true,
      draftId: result.draftId,
      status: 'Draft',
      sourceType: 'DOCX Import',
      message: imported.warnings.length
        ? 'DOCX imported. Review the highlighted conversion notes before submission.'
        : 'DOCX imported into the standard BGPS paper format.',
      warnings: imported.warnings
    };
  } catch (error) {
    if (sourceFile) trashFileQuietly_(sourceFile);
    throw error;
  }
}

function createManualPaper_(user, paper) {
  if (!paper || typeof paper !== 'object') throw new Error('Manual paper details are missing.');
  if (user.isAdmin) throw new Error('Admin cannot submit a teacher paper.');
  const className = cleanText_(paper.className);
  const subject = cleanText_(paper.subject);
  const exam = cleanText_(paper.exam);
  const chapters = normalizePaperChapters_(className, paper.chapters);
  const maxMarks = Number(paper.maxMarks);
  const examDate = cleanText_(paper.examDate);
  const note = cleanText_(paper.note).slice(0, 250);
  const timeAllowed = cleanText_(paper.timeAllowed).slice(0, 80);
  const instructions = cleanText_(paper.instructions).slice(0, 4000);
  const title = cleanText_(paper.title || (className + ' ' + subject + ' ' + exam + ' Paper')).slice(0, 180);
  const languageMode = cleanText_(paper.languageMode || 'english').toLowerCase();
  const editorHtml = normalizePaperContentHtml_(paper.editorHtml);
  const bodyText = cleanText_(paper.bodyText || editorHtml.replace(/<[^>]+>/g, ' '));
  const detectedMarks = Number(paper.detectedMarks || 0) || sumDetectedMarks_(editorHtml);
  const totalQuestions = Number(paper.totalQuestions || 0);
  const rawQuestions = Array.isArray(paper.questions) ? paper.questions : [];
  const originalPaperId = cleanText_(paper.originalPaperId || paper.revisionOriginalId || '');
  const parentPaperId = cleanText_(paper.parentPaperId || paper.revisionParentId || '');
  const previousVersion = Number(paper.previousVersion || 0);
  const submissionToken = normalizeRequestToken_(paper.requestId || paper.submissionToken || '');
  if (parentPaperId) {
    throw new Error('Returned papers must be corrected through the saved correction draft, not submitted as a new manual paper.');
  }

  // PAPER CREATION: free class selection for all teachers
  enforcePaperClassAccess_(user, className);

  if (!className || !subject || !exam || !chapters || !timeAllowed) {
    throw new Error(isPrePrimaryClass_(className) ? 'Class, Subject, Exam and Time Allowed are required.' : 'Class, Subject, Exam, Chapters and Time Allowed are required.');
  }
  if (!Number.isFinite(maxMarks) || maxMarks <= 0) {
    throw new Error('Maximum marks must be greater than zero.');
  }
  if (!timeAllowed) throw new Error('Time Allowed is required.');
  if (!editorHtml && !rawQuestions.length) throw new Error('Question paper content is blank.');

  let questions = [];
  let computedTotal = detectedMarks;
  if (rawQuestions.length) {
    if (rawQuestions.length > 150) throw new Error('A paper cannot contain more than 150 questions.');
    questions = rawQuestions.map(function(item, index) {
      const text = cleanText_(item && item.text);
      const section = cleanText_(item && item.section) || 'Section A';
      const chapter = cleanText_(item && item.chapter);
      const orText = cleanText_(item && item.orText);
      const marks = Number(item && item.marks);

      if (!text) throw new Error('Question ' + (index + 1) + ' is blank.');
      if (!Number.isFinite(marks) || marks <= 0) {
        throw new Error('Question ' + (index + 1) + ' must have valid marks.');
      }
      return {
        section: section.slice(0, 80),
        text: text.slice(0, 3000),
        marks: marks,
        chapter: chapter.slice(0, 160),
        orText: orText.slice(0, 3000)
      };
    });
    computedTotal = questions.reduce(function(sum, question) { return sum + Number(question.marks || 0); }, 0);
  }

  if (Number.isFinite(computedTotal) && Math.abs(computedTotal - maxMarks) > 0.01) {
    throw new Error('Detected question marks are ' + computedTotal + ', but Maximum Marks is ' + maxMarks + '.');
  }

  if (String(bodyText || '').toLowerCase().indexOf('type question here') !== -1) {
    throw new Error('Replace placeholder text before submission.');
  }
  const resolvedTotalQuestions = totalQuestions > 0 ? totalQuestions : (questions.length || countQuestionBlocks_(editorHtml, bodyText));
  if (resolvedTotalQuestions <= 0) throw new Error('At least one question is required.');

  const contentRecord = {
    paperId: '',
    title: title,
    className: className,
    subject: subject,
    exam: exam,
    chapters: chapters,
    maxMarks: maxMarks,
    examDate: examDate,
    note: note,
    timeAllowed: timeAllowed,
    instructions: instructions,
    languageMode: languageMode,
    editorHtml: editorHtml,
    bodyText: bodyText,
    detectedMarks: Number.isFinite(computedTotal) ? computedTotal : maxMarks,
    totalQuestions: resolvedTotalQuestions,
    questions: questions,
    originalPaperId: originalPaperId,
    parentPaperId: parentPaperId,
    previousVersion: previousVersion,
    revisionOriginalId: originalPaperId,
    revisionParentId: parentPaperId,
    revisionVersion: 0,
    submissionToken: submissionToken
  };

  if (!contentRecord.editorHtml && contentRecord.questions.length) {
    contentRecord.editorHtml = questionsToEditorHtml_(contentRecord.questions, contentRecord.instructions);
  }

  if (!contentRecord.editorHtml) {
    throw new Error('Editor HTML is required for canonical paper rendering.');
  }

  const sheet = ensureQuestionPaperSheet_();
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  let createdFile = null;
  let createdPdfFile = null;
  try {
    const previousSubmission = submissionToken ? findPaperBySubmissionToken_(sheet, user.id, submissionToken) : null;
    if (previousSubmission) return idempotentPaperResponse_(previousSubmission);
    assertPaperChannelOpen_('creator');
    const version = nextPaperVersion_(sheet, className, subject, exam);
    const paperId = Utilities.getUuid();
    const now = new Date();
    contentRecord.paperId = paperId;
    contentRecord.revisionVersion = version;
    const html = buildCanonicalPaperHtml_(contentRecord, user.id, version);
    const storedName = buildStoredPaperName_(className, subject, exam, version, 'html');
    const blob = Utilities.newBlob(html, 'text/html', storedName);
    const file = getQuestionPaperFolder_().createFile(blob);
    createdFile = file;
    const byteLength = blob.getBytes().length;
    createdPdfFile = getQuestionPaperFolder_().createFile(convertHtmlBlobToPdf_(blob, storedName.replace(/\.html$/i, '')));

    sheet.appendRow([
      paperId, now, now, user.id, className, subject, exam, chapters,
      maxMarks, examDate, note, storedName, 'text/html', byteLength,
      file.getId(), version, 'Submitted', '', 'Manual', timeAllowed,
      contentRecord.totalQuestions || 0, JSON.stringify(contentRecord), getTeacherDisplayName_(user.id), createdPdfFile.getId()
    ]);

    SpreadsheetApp.flush();
    return {
      ok: true,
      paperId: paperId,
      version: version,
      status: 'Submitted',
      sourceType: 'Manual',
      totalMarks: contentRecord.detectedMarks,
      totalQuestions: contentRecord.totalQuestions || 0
    };
  } catch (error) {
    if (typeof contentStorage !== 'undefined' && contentStorage && contentStorage.createdFile) trashFileQuietly_(contentStorage.createdFile);
    if (createdFile) trashFileQuietly_(createdFile);
    if (createdPdfFile) trashFileQuietly_(createdPdfFile);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function isPaperReadyForPrincipalReviewStatus_(status) {
  const key = cleanText_(status).toLowerCase().replace(/\s+/g, ' ');
  return ['submitted', 'resubmitted', 'corrected & resubmitted', 'corrected and resubmitted'].indexOf(key) !== -1;
}

function listPapers_(user) {
  if (user.isAdmin) repairPaperWorkflowOnce_();
  const sheet = ensureQuestionPaperSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { ok: true, papers: [] };

  const rows = sheet.getRange(2, 1, lastRow - 1, PAPER_HEADERS.length).getValues();
  const papers = rows
    .filter(function(row) {
      if (user.isAdmin) return true;
      if (cleanText_(row[3]).toUpperCase() !== user.id) return false;
      const rowContent = parseJsonObject_(row[21]);
      return !(cleanText_(row[16]).toLowerCase() === 'locked' && rowContent.superseded === true);
    })
    .map(function(row) {
      const content = parseJsonObject_(row[21]);
      const previousVersion = Number(content.previousVersion) || 0;
      const rawStatusKey = cleanText_(row[16]).toLowerCase().replace(/\s+/g, ' ');
      const statusSaysResubmitted = ['resubmitted', 'corrected & resubmitted', 'corrected and resubmitted'].indexOf(rawStatusKey) !== -1;
      // A Principal note is preserved when a returned paper is submitted again.
      // Use it as a recovery signal for older/repeated-return records whose
      // wasCorrectionResubmission flag was overwritten or never stored.
      const returnedAndSubmittedAgain = isPaperReadyForPrincipalReviewStatus_(row[16]) && Boolean(cleanText_(row[17]));
      const resubmitted = Boolean(
        content.wasCorrectionResubmission === true
        || statusSaysResubmitted
        || returnedAndSubmittedAgain
        || (content.wasCorrectionResubmission == null && (cleanText_(content.parentPaperId) || previousVersion > 0))
      );
      const rowSourceType = cleanText_(row[18]) || 'Upload';
      const rowMimeType = cleanText_(row[12]);
      const rowFileName = cleanText_(row[11]);
      const normalizedSourceType = rowSourceType.toLowerCase();
      const canStandardize = (normalizedSourceType === 'upload' || normalizedSourceType === 'docx upload')
        && (rowMimeType.toLowerCase().indexOf('wordprocessingml.document') !== -1 || fileExtension_(rowFileName) === 'docx');
      const hasStoredEditor = Boolean(String(content.editorHtml || '').trim() || cleanText_(content.contentDriveFileId));
      const rawRowStatus = cleanText_(row[16]) || 'Submitted';
      const rowStatus = rawRowStatus.toLowerCase();
      const readyForPrincipalReview = isPaperReadyForPrincipalReviewStatus_(rawRowStatus);
      const portalHtmlPaper = normalizedSourceType === 'manual'
        || rowMimeType.toLowerCase().indexOf('html') !== -1
        || /\.html?$/i.test(rowFileName);
      const adminDocxEditable = Boolean(user.isAdmin && canStandardize
        && readyForPrincipalReview
        && content.originalDeleted !== true);
      const adminPortalEditable = Boolean(user.isAdmin && readyForPrincipalReview
        && (hasStoredEditor || portalHtmlPaper));
      return {
        paperId: cleanText_(row[0]),
        uploadedAt: isoDate_(row[1]),
        updatedAt: isoDate_(row[2]),
        teacherId: cleanText_(row[3]),
        className: cleanText_(row[4]),
        subject: cleanText_(row[5]),
        exam: cleanText_(row[6]),
        chapters: cleanText_(row[7]),
        maxMarks: row[8],
        examDate: cleanText_(row[9]),
        note: cleanText_(row[10]),
        fileName: cleanText_(row[11]),
        mimeType: cleanText_(row[12]),
        fileSize: Number(row[13]) || 0,
        fileSizeLabel: formatBytes_(Number(row[13]) || 0),
        version: Number(row[15]) || 1,
        status: readyForPrincipalReview ? 'Submitted' : rawRowStatus,
        adminNote: cleanText_(row[17]),
        sourceType: rowSourceType,
        timeAllowed: cleanText_(row[19]),
        totalQuestions: Number(row[20]) || 0,
        teacherName: cleanText_(row[22]) || cleanText_(row[3]),
        hasFinalPdf: Boolean(cleanText_(row[23])),
        editable: user.isAdmin
          ? (canStandardize ? adminDocxEditable : adminPortalEditable)
          : hasStoredEditor,
        canStandardize: canStandardize,
        standardPreviewSaved: Boolean(
          cleanText_(row[23])
          && content.standardPreviewSaved === true
          && Number(content.standardPreviewSavedVersion || 0) === (Number(row[15]) || 1)
        ),
        standardPreviewSavedAt: cleanText_(content.standardPreviewSavedAt),
        originalDeleted: content.originalDeleted === true,
        originalAvailable: content.originalDeleted !== true,
        resubmitted: resubmitted,
        previousVersion: previousVersion,
        title: cleanText_(content.title) || cleanText_(row[11]) || (cleanText_(row[4]) + ' ' + cleanText_(row[5]) + ' ' + cleanText_(row[6]) + ' Paper')
      };
    });

  papers.sort(function(a, b) {
    return String(b.updatedAt).localeCompare(String(a.updatedAt));
  });

  return { ok: true, papers: papers };
}

function getPaperFile_(user, paperId) {
  const record = findPaperRecord_(paperId);
  if (!user.isAdmin && record.teacherId.toUpperCase() !== user.id) {
    throw new Error('You do not have permission to open this paper.');
  }

  let preferredFileId = cleanText_(record.status) === 'Approved' && record.previewPdfFileId
    ? record.previewPdfFileId
    : record.driveFileId;
  let file;
  try {
    file = DriveApp.getFileById(preferredFileId);
    if (file.isTrashed()) throw new Error('Preferred file is in Trash.');
  } catch (preferredError) {
    preferredFileId = record.driveFileId;
    file = DriveApp.getFileById(preferredFileId);
  }
  if (file.isTrashed()) throw new Error('This paper file is in Drive Trash.');
  const blob = file.getBlob();
  const bytes = blob.getBytes();
  if (bytes.length > PAPER_MAX_BYTES) {
    throw new Error('This stored file is too large to open through the portal.');
  }

  return {
    ok: true,
    fileName: preferredFileId === record.previewPdfFileId ? file.getName() : (record.originalFileName || file.getName()),
    mimeType: preferredFileId === record.previewPdfFileId ? 'application/pdf' : (record.mimeType || blob.getContentType()),
    fileBase64: Utilities.base64Encode(bytes)
  };
}

function getPaperOriginalFile_(user, paperId) {
  const record = findPaperRecord_(paperId);
  if (!user.isAdmin && record.teacherId.toUpperCase() !== user.id) {
    throw new Error('You do not have permission to open this paper.');
  }
  const content = loadPaperContentRecord_(record.contentJson);
  if (content.originalDeleted === true) throw new Error('The original DOCX was removed after final approval. The approved PDF remains available.');
  const originalFileId = cleanText_(content.sourceFileId || record.driveFileId);
  const originalFileName = cleanText_(content.originalFileName || record.originalFileName);
  const file = DriveApp.getFileById(originalFileId);
  if (file.isTrashed()) throw new Error('The original paper file is in Drive Trash.');
  const blob = file.getBlob();
  const bytes = blob.getBytes();
  if (bytes.length > PAPER_MAX_BYTES) {
    throw new Error('The original paper file is too large to open through the portal.');
  }
  return {
    ok: true,
    original: true,
    fileName: originalFileName || file.getName(),
    mimeType: fileExtension_(originalFileName) === 'docx' ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : (record.mimeType || blob.getContentType()),
    fileBase64: Utilities.base64Encode(bytes)
  };
}



/**
 * Run this function once from the Apps Script editor after installing the
 * supplied appsscript.json. It grants the Drive and external-request scopes
 * required for DOCX-to-PDF preview conversion.
 */
function authorizeBGPSDocxPreview() {
  // The Advanced Drive service performs the same authenticated Drive API call
  // used by the production conversion path. Running this once confirms that
  // the service is enabled and prompts for the required Drive permission.
  const result = Drive.Files.list({
    pageSize: 1,
    fields: 'files(id)'
  });
  if (!result || !Array.isArray(result.files)) {
    throw new Error('Google Drive preview service could not be initialized.');
  }
  return 'BGPS DOCX preview authorization complete.';
}


function isUploadedDocxRecord_(record) {
  const mime = cleanText_(record && record.mimeType).toLowerCase();
  const extension = fileExtension_(record && record.originalFileName);
  const sourceType = cleanText_(record && record.sourceType).toLowerCase();
  return (sourceType === 'upload' || sourceType === 'docx upload')
    && (mime.indexOf('wordprocessingml.document') !== -1 || extension === 'docx');
}

function buildBgpsStandardDocxDocument_(record, editedContentHtml) {
  if (!isUploadedDocxRecord_(record)) throw new Error('BGPS standard preview is available only for submitted DOCX uploads.');
  const suppliedEdit = String(editedContentHtml || '').trim();
  let editorHtml = '';
  let warnings = [];
  if (suppliedEdit) {
    editorHtml = normalizePaperContentHtml_(suppliedEdit);
    if (!htmlToPlainText_(editorHtml)) throw new Error('The edited BGPS working copy does not contain readable paper content.');
  } else {
    const source = DriveApp.getFileById(record.driveFileId);
    if (source.isTrashed()) throw new Error('The original DOCX is in Drive Trash.');
    const imported = convertDocxBlobToEditableHtml_(source.getBlob(), record.originalFileName || source.getName());
    editorHtml = normalizePaperContentHtml_(standardizeImportedDocxLayout_(imported.html));
    warnings = Array.isArray(imported.warnings) ? imported.warnings.slice(0, 10) : [];
    if (!htmlToPlainText_(editorHtml)) throw new Error('The DOCX did not contain readable paper content.');
  }
  if (!/\bbgps-standardized-docx\b/i.test(editorHtml)) editorHtml = '<div class="bgps-standardized-docx">' + editorHtml + '</div>';
  const bodyText = htmlToPlainText_(editorHtml);
  const totalQuestions = countQuestionBlocks_(editorHtml, bodyText);
  const detectedMarks = sumDetectedMarks_(editorHtml);
  if (totalQuestions <= 0) warnings.push('Question numbering could not be detected automatically. Verify the preview before saving.');
  if (detectedMarks > 0 && record.maxMarks > 0 && Math.abs(detectedMarks - record.maxMarks) > 0.01) warnings.push('Detected question marks total ' + detectedMarks + ', while Maximum Marks is ' + record.maxMarks + '.');
  const content = loadPaperContentRecord_(record.contentJson);
  const paper = {
    paperId: record.paperId,
    title: cleanText_(content.title) || String(record.originalFileName || '').replace(/\.docx$/i, '') || (record.className + ' ' + record.subject + ' ' + record.exam + ' Paper'),
    className: record.className, subject: record.subject, exam: record.exam, chapters: record.chapters,
    maxMarks: record.maxMarks, examDate: record.examDate, note: record.note,
    timeAllowed: record.timeAllowed || inferPaperTime_(record.maxMarks), instructions: '',
    languageMode: cleanText_(content.languageMode || 'english'), editorHtml: editorHtml,
    bodyText: bodyText, detectedMarks: detectedMarks, totalQuestions: totalQuestions, sourceType: 'DOCX Upload'
  };
  const documentHtml = buildCanonicalPaperHtml_(paper, record.teacherId, record.version);
  const baseName = buildStoredPaperName_(record.className, record.subject, record.exam, record.version, 'html').replace(/\.html$/i, '');
  return { documentHtml: documentHtml, editableContentHtml: editorHtml, baseName: baseName + ' - BGPS Standard', warnings: warnings, totalQuestions: totalQuestions, detectedMarks: detectedMarks };
}

function savedBgpsStandardIsCurrent_(record, content) {
  const workingFileId = cleanText_(content && content.standardizedHtmlFileId);
  const valid = Boolean(workingFileId && content && content.standardPreviewSaved === true && Number(content.standardPreviewSavedVersion || 0) === Number(record.version || 0));
  if (!valid) return false;
  try { const file = DriveApp.getFileById(workingFileId); return !file.isTrashed() && file.getBlob().getBytes().length > 0; }
  catch (error) { return false; }
}

function getBgpsStandardPreview_(user, paperId) {
  if (!user.isAdmin) throw new Error('Only Admin can prepare the BGPS standard preview.');
  const record = findPaperRecord_(paperId);
  if (!isUploadedDocxRecord_(record)) throw new Error('This option is available only for DOCX papers uploaded by teachers.');
  const content = loadPaperContentRecord_(record.contentJson);
  let generated = null;
  let saved = false;
  let savedAt = '';
  if (savedBgpsStandardIsCurrent_(record, content)) {
    try {
      const workingFile = DriveApp.getFileById(cleanText_(content.standardizedHtmlFileId));
      generated = buildBgpsStandardDocxDocument_(record, workingFile.getBlob().getDataAsString('UTF-8'));
      saved = true;
      savedAt = cleanText_(content.standardPreviewSavedAt);
    } catch (savedError) { console.warn('Saved BGPS working copy is unavailable; regenerating.', safeErrorMessage_(savedError)); }
  }
  if (!generated) generated = buildBgpsStandardDocxDocument_(record);
  const pdfBlob = convertHtmlBlobToPdf_(Utilities.newBlob(generated.documentHtml, 'text/html', generated.baseName + '.html'), generated.baseName);
  const bytes = pdfBlob.getBytes();
  if (!bytes.length) throw new Error('The BGPS standard preview PDF is empty.');
  if (bytes.length > PAPER_MAX_BYTES) throw new Error('The BGPS standard preview exceeds the 8 MB preview limit.');
  return {
    ok: true, saved: saved, savedAt: savedAt, fileName: generated.baseName + '.pdf', mimeType: 'application/pdf',
    fileBase64: Utilities.base64Encode(bytes), editableContentHtml: generated.editableContentHtml,
    warnings: saved && Array.isArray(content.standardPreviewWarnings) ? content.standardPreviewWarnings : generated.warnings,
    totalQuestions: generated.totalQuestions, detectedMarks: generated.detectedMarks,
    originalPreserved: content.originalDeleted !== true, originalDeleted: content.originalDeleted === true
  };
}

function saveBgpsStandardPreview_(user, paperId, editedContentHtml) {
  if (!user.isAdmin) throw new Error('Only Admin can save the BGPS standard preview.');
  const initialRecord = findPaperRecord_(paperId);
  if (!isPaperReadyForPrincipalReviewStatus_(initialRecord.status)) throw new Error('Only a paper awaiting Principal review can be standardized for approval.');
  const generated = buildBgpsStandardDocxDocument_(initialRecord, editedContentHtml);
  const workingBlob = Utilities.newBlob(generated.editableContentHtml, 'text/html', generated.baseName + ' - Working Copy.html');
  const previewBlob = convertHtmlBlobToPdf_(Utilities.newBlob(generated.documentHtml, 'text/html', generated.baseName + '.html'), generated.baseName).setName(generated.baseName + '.pdf');
  if (!previewBlob.getBytes().length) throw new Error('The generated BGPS PDF is empty.');
  if (previewBlob.getBytes().length > PAPER_MAX_BYTES) throw new Error('The generated BGPS PDF exceeds the 8 MB preview limit.');
  const folder = getQuestionPaperFolder_();
  let workingFile = null;
  let contentStorage = null;
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const record = findPaperRecord_(paperId);
    if (!isPaperReadyForPrincipalReviewStatus_(record.status)) throw new Error('The paper status changed before the BGPS working copy could be saved.');
    if (Number(record.version || 0) !== Number(initialRecord.version || 0) || record.driveFileId !== initialRecord.driveFileId) throw new Error('A newer paper version is available. Refresh and prepare the BGPS preview again.');
    workingFile = folder.createFile(workingBlob);
    const previousContent = loadPaperContentRecord_(record.contentJson);
    const shouldLogStandardSave = Number(previousContent.standardPreviewLoggedVersion || 0) !== Number(record.version || 0);
    const savedAt = new Date().toISOString();
    const nextContent = Object.assign({}, previousContent, {
      standardPreviewSaved: true, standardPreviewSavedAt: savedAt, standardPreviewSavedBy: user.id,
      standardPreviewSavedVersion: record.version, standardPreviewLoggedVersion: record.version,
      standardPreviewWarnings: generated.warnings, standardPreviewTotalQuestions: generated.totalQuestions,
      standardPreviewDetectedMarks: generated.detectedMarks, standardizedHtmlFileId: workingFile.getId(),
      standardizedSourceFileId: record.driveFileId, standardizedStorageMode: 'TEMP_HTML_UNTIL_APPROVAL',
      originalFilePreserved: previousContent.originalDeleted !== true
    });
    contentStorage = preparePaperContentStorage_(nextContent, record.contentJson);
    record.sheet.getRange(record.rowNumber, 3).setValue(new Date());
    record.sheet.getRange(record.rowNumber, 22).setValue(contentStorage.cellJson);
    record.sheet.getRange(record.rowNumber, 24).setValue('');
    SpreadsheetApp.flush();
    if (shouldLogStandardSave) {
      try { appendPrincipalActivity_(user, 'BGPS Format Saved', { teacherId: record.teacherId, className: record.className, subjects: record.subject, paperId: record.paperId, message: 'Principal saved the temporary BGPS working copy. No permanent PDF was created yet.' }); }
      catch (activityError) { console.warn('BGPS format was saved, but the activity log could not be updated.', safeErrorMessage_(activityError)); }
    }
    const oldWorkingId = cleanText_(previousContent.standardizedHtmlFileId);
    if (oldWorkingId && oldWorkingId !== workingFile.getId()) trashFileQuietly_(oldWorkingId);
    if (record.previewPdfFileId && record.previewPdfFileId !== record.driveFileId) trashFileQuietly_(record.previewPdfFileId);
    if (contentStorage.obsoleteFileId && contentStorage.obsoleteFileId !== contentStorage.fileId) trashFileQuietly_(contentStorage.obsoleteFileId);
    const rawPreviewKey = PAPER_PREVIEW_PROPERTY_PREFIX + cleanText_(record.paperId);
    const rawPreviewId = cleanText_(PropertiesService.getScriptProperties().getProperty(rawPreviewKey));
    if (rawPreviewId) trashFileQuietly_(rawPreviewId);
    PropertiesService.getScriptProperties().deleteProperty(rawPreviewKey);
    return {
      ok: true, saved: true, savedAt: savedAt, fileName: previewBlob.getName(), mimeType: 'application/pdf',
      fileBase64: Utilities.base64Encode(previewBlob.getBytes()), editableContentHtml: generated.editableContentHtml,
      warnings: generated.warnings, totalQuestions: generated.totalQuestions, detectedMarks: generated.detectedMarks,
      originalPreserved: previousContent.originalDeleted !== true, storageMode: 'TEMP_HTML_UNTIL_APPROVAL'
    };
  } catch (error) {
    if (workingFile) trashFileQuietly_(workingFile);
    if (contentStorage && contentStorage.createdFile) trashFileQuietly_(contentStorage.createdFile);
    throw error;
  } finally { lock.releaseLock(); }
}

function getPaperPreview_(user, paperId) {
  const record = findPaperRecord_(paperId);
  if (!user.isAdmin && record.teacherId.toUpperCase() !== user.id) {
    throw new Error('You do not have permission to open this paper.');
  }

  if (record.previewPdfFileId) {
    try {
      const finalPdf = DriveApp.getFileById(record.previewPdfFileId);
      if (!finalPdf.isTrashed()) {
        const finalBlob = finalPdf.getBlob();
        const finalBytes = finalBlob.getBytes();
        if (finalBytes.length > PAPER_MAX_BYTES) throw new Error('The final PDF is too large to preview through the portal.');
        return {
          ok: true,
          previewAvailable: true,
          fileName: finalPdf.getName(),
          originalFileName: record.originalFileName || finalPdf.getName(),
          mimeType: 'application/pdf',
          fileBase64: Utilities.base64Encode(finalBytes),
          finalReference: true
        };
      }
    } catch (previewError) {
      console.warn('Stored final PDF is unavailable; using the compatible source preview.', safeErrorMessage_(previewError));
    }
  }
  const file = DriveApp.getFileById(record.driveFileId);
  if (file.isTrashed()) throw new Error('This paper file is in Drive Trash.');
  const blob = file.getBlob();
  const mime = cleanText_(record.mimeType || blob.getContentType()).toLowerCase();
  const extension = fileExtension_(record.originalFileName || file.getName());

  if (mime.indexOf('pdf') !== -1 || extension === 'pdf') {
    const bytes = blob.getBytes();
    if (bytes.length > PAPER_MAX_BYTES) throw new Error('This PDF is too large to preview through the portal.');
    return {
      ok: true,
      previewAvailable: true,
      fileName: record.originalFileName || file.getName(),
      originalFileName: record.originalFileName || file.getName(),
      mimeType: 'application/pdf',
      fileBase64: Utilities.base64Encode(bytes)
    };
  }

  if (mime.indexOf('html') !== -1 || extension === 'html' || record.sourceType === 'Manual') {
    const bytes = blob.getBytes();
    if (bytes.length > PAPER_MAX_BYTES) throw new Error('This paper is too large to preview through the portal.');
    return {
      ok: true,
      previewAvailable: true,
      fileName: record.originalFileName || file.getName(),
      originalFileName: record.originalFileName || file.getName(),
      mimeType: 'text/html',
      fileBase64: Utilities.base64Encode(bytes)
    };
  }

  if (mime.indexOf('wordprocessingml.document') !== -1 || extension === 'docx') {
    try {
      const previewFile = getOrCreateDocxPreviewFile_(record, blob);
      const previewBlob = previewFile.getBlob();
      const bytes = previewBlob.getBytes();
      if (bytes.length > PAPER_MAX_BYTES) throw new Error('The generated PDF preview is too large.');
      return {
        ok: true,
        previewAvailable: true,
        fileName: previewFile.getName(),
        originalFileName: record.originalFileName || file.getName(),
        mimeType: 'application/pdf',
        fileBase64: Utilities.base64Encode(bytes),
        convertedFrom: 'DOCX'
      };
    } catch (error) {
      return {
        ok: true,
        previewAvailable: false,
        originalFileName: record.originalFileName || file.getName(),
        mimeType: record.mimeType || blob.getContentType(),
        error: /Drive is not defined|service.+enabled|accessNotConfigured/i.test(safeErrorMessage_(error))
          ? 'Document preview service is not enabled yet. The administrator must enable Google Drive API once in Apps Script.'
          : 'The automatic PDF preview could not be prepared. Download the original file or ask the teacher to resubmit a valid DOCX/PDF.'
      };
    }
  }

  return {
    ok: true,
    previewAvailable: false,
    originalFileName: record.originalFileName || file.getName(),
    mimeType: record.mimeType || blob.getContentType(),
    error: 'Preview is not available for this file type. Download the original file to open it.'
  };
}

function getOrCreateDocxPreviewFile_(record, sourceBlob) {
  const properties = PropertiesService.getScriptProperties();
  const propertyKey = PAPER_PREVIEW_PROPERTY_PREFIX + cleanText_(record.paperId);
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  let previewFile = null;
  try {
    // Double-check inside the lock. Without this, two simultaneous Preview
    // clicks can both create a Drive PDF before either stores the cache ID.
    const cachedId = cleanText_(properties.getProperty(propertyKey));
    if (cachedId) {
      try {
        const cached = DriveApp.getFileById(cachedId);
        if (!cached.isTrashed()) return cached;
      } catch (ignored) {}
      properties.deleteProperty(propertyKey);
    }

    const previewBlob = convertDocxBlobToPdf_(sourceBlob, record.originalFileName || 'Question Paper.docx');
    const baseName = String(record.originalFileName || 'Question Paper').replace(/\.docx$/i, '').trim() || 'Question Paper';
    previewBlob.setName(baseName + ' - Preview.pdf');
    previewFile = getQuestionPaperFolder_().createFile(previewBlob);
    properties.setProperty(propertyKey, previewFile.getId());
    return previewFile;
  } catch (error) {
    if (previewFile) trashFileQuietly_(previewFile);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function convertDocxBlobToPdf_(docxBlob, originalName) {
  const sourceMime = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
  const baseName = String(originalName || 'Question Paper.docx')
    .replace(/\.docx$/i, '')
    .trim() || 'Question Paper';
  const sourceBlob = Utilities.newBlob(
    docxBlob.getBytes(),
    sourceMime,
    baseName + '.docx'
  );

  let googleDocId = '';
  try {
    // Advanced Drive service uses Drive API v3 directly and avoids manually
    // constructing multipart or resumable HTTP requests in Apps Script.
    const converted = Drive.Files.create(
      {
        name: baseName,
        mimeType: GOOGLE_DOC_MIME
      },
      sourceBlob,
      {
        fields: 'id,mimeType'
      }
    );
    googleDocId = cleanText_(converted && converted.id);
    if (!googleDocId) {
      throw new Error('Google Drive did not return a converted document ID.');
    }

    // Drive conversion can take a moment before PDF export is available.
    let lastError = null;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      try {
        if (attempt > 0) Utilities.sleep(700 * attempt);
        const convertedFile = DriveApp.getFileById(googleDocId);
        const pdfBlob = convertedFile.getAs(MimeType.PDF);
        if (pdfBlob && pdfBlob.getBytes().length) {
          return pdfBlob.setContentType('application/pdf');
        }
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error('PDF export was not ready.');
  } catch (error) {
    console.error('BGPS DOCX conversion failed', safeErrorMessage_(error));
    throw error;
  } finally {
    if (googleDocId) {
      try { DriveApp.getFileById(googleDocId).setTrashed(true); } catch (ignored) {}
    }
  }
}

function convertDocxBlobToEditableHtml_(docxBlob, originalName) {
  const baseName = String(originalName || 'Question Paper.docx').replace(/\.docx$/i, '').trim() || 'Question Paper';
  const sourceBlob = Utilities.newBlob(
    docxBlob.getBytes(),
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    baseName + '.docx'
  );
  let googleDocId = '';
  try {
    const converted = Drive.Files.create({ name: baseName + ' - Import', mimeType: GOOGLE_DOC_MIME }, sourceBlob, { fields: 'id' });
    googleDocId = cleanText_(converted && converted.id);
    if (!googleDocId) throw new Error('Google Drive did not return an imported document ID.');

    let exportBlob = null;
    let lastError = null;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      try {
        if (attempt > 0) Utilities.sleep(600 * attempt);
        exportBlob = exportGoogleWorkspaceFile_(googleDocId, 'application/zip');
        if (exportBlob && exportBlob.getBytes().length) break;
      } catch (error) {
        lastError = error;
      }
    }
    if (!exportBlob || !exportBlob.getBytes().length) throw lastError || new Error('The converted document was not ready for editable export.');

    const parts = Utilities.unzip(exportBlob);
    const htmlPart = parts.find(function(part) { return /\.html?$/i.test(part.getName()); });
    if (!htmlPart) throw new Error('The DOCX conversion did not contain editable HTML.');
    const exportedHtml = htmlPart.getDataAsString('UTF-8');
    const inlinedHtml = inlineDocxExportStyles_(exportedHtml);
    const bodyMatch = inlinedHtml.match(/<body\b[^>]*>([\s\S]*?)<\/body>/i);
    let bodyHtml = bodyMatch ? bodyMatch[1] : inlinedHtml;
    const images = {};
    parts.forEach(function(part) {
      if (part === htmlPart) return;
      const contentType = cleanText_(part.getContentType()).toLowerCase();
      if (!/^image\/(?:png|jpeg|jpg|webp)$/.test(contentType)) return;
      const name = String(part.getName() || '').replace(/\\/g, '/');
      images[name] = 'data:' + contentType.replace('image/jpg', 'image/jpeg') + ';base64,' + Utilities.base64Encode(part.getBytes());
      images[name.split('/').pop()] = images[name];
    });
    bodyHtml = bodyHtml.replace(/(<img\b[^>]*\bsrc\s*=\s*)(['"])([^'"]+)\2/gi, function(all, prefix, quote, source) {
      const decoded = decodeURIComponent(String(source || '')).replace(/^\.\//, '').replace(/\\/g, '/');
      const replacement = images[decoded] || images[decoded.split('/').pop()];
      return replacement ? prefix + quote + replacement + quote : all;
    });

    const warnings = [];
    if (/<(?:math|svg)\b|m:oMath/i.test(exportedHtml)) warnings.push('Some equations were converted to their closest editable form. Please verify them.');
    if (/position\s*:\s*(?:absolute|fixed)|float\s*:/i.test(exportedHtml)) warnings.push('Floating items were placed in normal page order to keep the A4 layout stable.');
    const unresolvedImages = (bodyHtml.match(/<img\b[^>]*\bsrc\s*=\s*['"](?!data:image\/)/gi) || []).length;
    if (unresolvedImages) warnings.push(unresolvedImages + ' image' + (unresolvedImages === 1 ? '' : 's') + ' could not be embedded and require review.');
    if (unresolvedImages) {
      bodyHtml = bodyHtml.replace(/<img\b[^>]*\bsrc\s*=\s*(['"])(?!data:image\/)[\s\S]*?\1[^>]*>/gi, '<div class="diagram-box">Image requires review</div>');
    }
    bodyHtml = bodyHtml.replace(/<img\b([^>]*\bsrc\s*=\s*['"]data:image\/[\s\S]*?['"][^>]*)>/gi, function(all, attrs) {
      const image = /\bclass\s*=/.test(attrs)
        ? '<img ' + attrs.replace(/\bclass\s*=\s*(['"])([^'"]*)\1/i, 'class="diagram-image $2"') + '>'
        : '<img class="diagram-image" ' + attrs + '>';
      return '<div class="diagram-box has-image bgps-img-center" style="--bgps-image-width:55%;width:55%">' + image + '</div>';
    });
    const importedHeader = stripImportedPaperHeader_(bodyHtml);
    bodyHtml = importedHeader.html;
    if (importedHeader.removed) {
      warnings.push('The original DOCX header was replaced with the standard BGPS header. Please verify the selected Class, Subject and Exam.');
    }
    bodyHtml = cleanupImportedDocxSpacing_(bodyHtml);
    bodyHtml = standardizeImportedDocxLayout_(bodyHtml);
    return { html: bodyHtml, warnings: warnings };
  } catch (error) {
    const reason = safeErrorMessage_(error);
    console.error('BGPS DOCX editable import failed', reason);
    try {
      const fallback = extractEditableHtmlDirectlyFromDocx_(sourceBlob);
      fallback.warnings.unshift('Google Drive could not import this DOCX directly, so BGPS used its built-in DOCX reader. Please verify complex tables, equations and drawings before submission.');
      return fallback;
    } catch (fallbackError) {
      console.error('BGPS direct DOCX fallback failed', safeErrorMessage_(fallbackError));
    }
    if (/Drive is not defined|service.+enabled|accessNotConfigured|Drive API.+not.+enabled/i.test(reason)) {
      throw new Error('DOCX conversion service is not enabled. In Apps Script, enable the Advanced Google Drive service (Drive API v3), then run authorizeBGPSDocxPreview once and deploy a new version.');
    }
    if (/authoriz|permission|scope|access denied|insufficient|forbidden|403/i.test(reason)) {
      throw new Error('DOCX conversion permission is missing. Run authorizeBGPSDocxPreview once from the Apps Script editor, approve access, and deploy a new version.');
    }
    throw new Error('The DOCX conversion failed: ' + reason.slice(0, 220));
  } finally {
    if (googleDocId) trashFileQuietly_(googleDocId);
  }
}

function extractEditableHtmlDirectlyFromDocx_(docxBlob) {
  const parts = Utilities.unzip(docxBlob);
  const partByName = {};
  parts.forEach(function(part) { partByName[String(part.getName() || '').replace(/\\/g, '/').toLowerCase()] = part; });
  const documentPart = partByName['word/document.xml'];
  if (!documentPart) throw new Error('The DOCX package does not contain word/document.xml.');

  const relationshipTargets = {};
  const relationshipsPart = partByName['word/_rels/document.xml.rels'];
  if (relationshipsPart) {
    const relationshipsXml = relationshipsPart.getDataAsString('UTF-8');
    const relationshipRegex = /<Relationship\b([^>]*)\/?\s*>/gi;
    let relationship;
    while ((relationship = relationshipRegex.exec(relationshipsXml))) {
      const id = docxXmlAttribute_(relationship[1], 'Id');
      const target = docxXmlAttribute_(relationship[1], 'Target');
      if (id && target) relationshipTargets[id] = ('word/' + target).replace(/\\/g, '/').replace(/\/[^/]+\/\.\.\//g, '/').toLowerCase();
    }
  }

  const images = {};
  Object.keys(partByName).forEach(function(name) {
    if (name.indexOf('word/media/') !== 0) return;
    const part = partByName[name];
    const extension = (name.match(/\.([a-z0-9]+)$/i) || [])[1] || '';
    const mimeType = /^jpe?g$/i.test(extension) ? 'image/jpeg' : /^png$/i.test(extension) ? 'image/png' : /^gif$/i.test(extension) ? 'image/gif' : /^webp$/i.test(extension) ? 'image/webp' : '';
    if (!mimeType) return;
    images[name] = 'data:' + mimeType + ';base64,' + Utilities.base64Encode(part.getBytes());
    images[name.split('/').pop()] = images[name];
  });

  const documentXml = documentPart.getDataAsString('UTF-8');
  const bodyMatch = documentXml.match(/<w:body\b[^>]*>([\s\S]*?)<\/w:body>/i);
  const bodyXml = bodyMatch ? bodyMatch[1] : documentXml;
  const listState = {};
  const renderParagraph = function(paragraphXml) {
    const alignmentMatch = paragraphXml.match(/<w:jc\b[^>]*w:val=["']([^"']+)["']/i);
    const alignment = alignmentMatch ? String(alignmentMatch[1]).toLowerCase() : '';
    const numIdMatch = paragraphXml.match(/<w:numId\b[^>]*w:val=["'](\d+)["']/i);
    const levelMatch = paragraphXml.match(/<w:ilvl\b[^>]*w:val=["'](\d+)["']/i);
    let listPrefix = '';
    if (numIdMatch) {
      const key = numIdMatch[1] + ':' + (levelMatch ? levelMatch[1] : '0');
      listState[key] = (listState[key] || 0) + 1;
      listPrefix = listState[key] + '. ';
    }
    let content = '';
    const runRegex = /<w:r\b[^>]*>([\s\S]*?)<\/w:r>/gi;
    let run;
    while ((run = runRegex.exec(paragraphXml))) {
      const runXml = run[1];
      const embeddedId = (runXml.match(/r:embed=["']([^"']+)["']/i) || [])[1] || '';
      if (embeddedId) {
        const target = relationshipTargets[embeddedId] || '';
        const image = images[target] || images[target.split('/').pop()];
        if (image) content += '<img src="' + image + '" alt="Imported image">';
      }
      let text = '';
      const textRegex = /<w:t\b[^>]*>([\s\S]*?)<\/w:t>/gi;
      let textMatch;
      while ((textMatch = textRegex.exec(runXml))) text += docxXmlDecode_(textMatch[1]);
      if (/<w:tab\b/i.test(runXml)) text += '\t';
      if (/<w:br\b|<w:cr\b/i.test(runXml)) text += '\n';
      if (text) {
        let safeText = htmlEscape_(text).replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;').replace(/\n/g, '<br>');
        if (/<w:b\b/i.test(runXml)) safeText = '<strong>' + safeText + '</strong>';
        if (/<w:i\b/i.test(runXml)) safeText = '<em>' + safeText + '</em>';
        if (/<w:vertAlign\b[^>]*w:val=["']superscript/i.test(runXml)) safeText = '<sup>' + safeText + '</sup>';
        if (/<w:vertAlign\b[^>]*w:val=["']subscript/i.test(runXml)) safeText = '<sub>' + safeText + '</sub>';
        content += safeText;
      }
    }
    if (!content) return '<p><br></p>';
    const style = alignment === 'center' ? ' style="text-align:center"' : alignment === 'right' ? ' style="text-align:right"' : alignment === 'both' ? ' style="text-align:justify"' : '';
    return '<p' + style + '>' + htmlEscape_(listPrefix) + content + '</p>';
  };

  const output = [];
  const blockRegex = /<w:(p|tbl)\b[\s\S]*?<\/w:\1>/gi;
  let block;
  while ((block = blockRegex.exec(bodyXml))) {
    if (block[1].toLowerCase() === 'p') {
      output.push(renderParagraph(block[0]));
      continue;
    }
    const rows = [];
    const rowRegex = /<w:tr\b[\s\S]*?<\/w:tr>/gi;
    let row;
    while ((row = rowRegex.exec(block[0]))) {
      const cells = [];
      const cellRegex = /<w:tc\b[\s\S]*?<\/w:tc>/gi;
      let cell;
      while ((cell = cellRegex.exec(row[0]))) {
        const paragraphs = [];
        const paragraphRegex = /<w:p\b[\s\S]*?<\/w:p>/gi;
        let paragraph;
        while ((paragraph = paragraphRegex.exec(cell[0]))) paragraphs.push(renderParagraph(paragraph[0]));
        cells.push('<td>' + (paragraphs.join('') || '<p><br></p>') + '</td>');
      }
      if (cells.length) rows.push('<tr>' + cells.join('') + '</tr>');
    }
    if (rows.length) output.push('<table><tbody>' + rows.join('') + '</tbody></table>');
  }
  if (!output.length) throw new Error('No readable paragraphs or tables were found in the DOCX.');

  let html = output.join('');
  html = html.replace(/<img\b([^>]*\bsrc\s*=\s*["']data:image\/[\s\S]*?["'][^>]*)>/gi, '<div class="diagram-box has-image bgps-img-center" style="--bgps-image-width:55%;width:55%"><img class="diagram-image" $1></div>');
  const importedHeader = stripImportedPaperHeader_(html);
  html = cleanupImportedDocxSpacing_(importedHeader.html);
  html = standardizeImportedDocxLayout_(html);
  const warnings = ['Imported using the built-in DOCX reader.'];
  if (importedHeader.removed) warnings.push('The original DOCX header was replaced with the standard BGPS header. Please verify the selected Class, Subject and Exam.');
  return { html: html, warnings: warnings };
}

function docxXmlAttribute_(attributes, name) {
  const match = String(attributes || '').match(new RegExp("(?:^|\\s)" + name + "=[\\\"']([^\\\"']*)[\\\"']", 'i'));
  return match ? docxXmlDecode_(match[1]) : '';
}

function docxXmlDecode_(value) {
  return String(value || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&').replace(/&#(\d+);/g, function(_, code) { return String.fromCharCode(Number(code)); }).replace(/&#x([0-9a-f]+);/gi, function(_, code) { return String.fromCharCode(parseInt(code, 16)); });
}

function inlineDocxExportStyles_(html) {
  const source = String(html || '');
  const styles = {};
  const styleBlock = (source.match(/<style\b[^>]*>([\s\S]*?)<\/style>/i) || [])[1] || '';
  const ruleRegex = /\.([a-zA-Z0-9_-]+)\s*\{([^}]*)\}/g;
  let match;
  while ((match = ruleRegex.exec(styleBlock))) styles[match[1]] = match[2];
  return source.replace(/<([a-zA-Z0-9]+)([^>]*?)\sclass\s*=\s*(['"])([^'"]+)\3([^>]*)>/g, function(all, tag, before, quote, classNames, after) {
    const declarations = classNames.split(/\s+/).map(function(name) { return styles[name] || ''; }).filter(Boolean).join(';');
    if (!declarations) return all;
    const attrs = before + ' class=' + quote + classNames + quote + after;
    if (/\sstyle\s*=\s*(['"])/i.test(attrs)) {
      return '<' + tag + attrs.replace(/\sstyle\s*=\s*(['"])([\s\S]*?)\1/i, function(styleAll, styleQuote, existing) {
        return ' style=' + styleQuote + declarations + ';' + existing + styleQuote;
      }) + '>';
    }
    return '<' + tag + attrs + ' style="' + declarations.replace(/"/g, '') + '">';
  });
}

function exportGoogleWorkspaceFile_(fileId, mimeType) {
  const url = 'https://www.googleapis.com/drive/v3/files/' + encodeURIComponent(cleanText_(fileId)) +
    '/export?mimeType=' + encodeURIComponent(cleanText_(mimeType));
  const response = UrlFetchApp.fetch(url, {
    method: 'get',
    headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
    muteHttpExceptions: true
  });
  const code = response.getResponseCode();
  if (code < 200 || code >= 300) throw new Error('Google Drive export was not ready (HTTP ' + code + ').');
  return response.getBlob();
}

function stripImportedPaperHeader_(html) {
  const source = String(html || '');
  const blocks = [];
  const blockRegex = /<(p|h[1-6]|table|li)\b[^>]*>[\s\S]*?<\/\1>/gi;
  let match;
  while ((match = blockRegex.exec(source)) && blocks.length < 40) {
    blocks.push({
      start: match.index,
      end: blockRegex.lastIndex,
      text: htmlToPlainText_(match[0]).replace(/\s+/g, ' ').trim()
    });
  }
  if (blocks.length < 2) return { html: source, removed: false };

  let bodyStart = -1;
  for (let index = 0; index < blocks.length; index += 1) {
    const text = blocks[index].text;
    if (/^(?:(?:Q|Question)\s*\.?\s*\d+|\d+\s*[.)-])(?:\s|$)/i.test(text) ||
        /^(?:General\s+)?Instructions?\s*[:.-]?/i.test(text) ||
        /^(?:Section|खंड)\s+[A-Z0-9]/i.test(text)) {
      bodyStart = index;
      break;
    }
  }
  if (bodyStart < 1) return { html: source, removed: false };

  const leadingText = blocks.slice(0, bodyStart).map(function(block) { return block.text; }).join(' ');
  const hasSchoolName = /(?:B\s*\.?\s*G\s*\.?\s*)?PUBLIC\s+SCHOOL|BG\s+PUBLIC\s+SCHOOL/i.test(leadingText);
  const evidence = [
    /\bSUBJECT\s*:/i,
    /\bCLASS\s*:/i,
    /\b(?:TIME|DURATION)\s*:/i,
    /\b(?:MAXIMUM\s+MARKS|MAX\.?\s*MARKS|M\.?M\.?)\s*:/i,
    /\b(?:UNIT\s+TEST|TEST|EXAMINATION|EXAM|TERM)\b/i,
    /\bSESSION\s*:/i,
    /\bDATE\s*:/i
  ].filter(function(pattern) { return pattern.test(leadingText); }).length;
  if (!hasSchoolName || evidence < 2) return { html: source, removed: false };

  return {
    html: source.slice(0, blocks[0].start) + source.slice(blocks[bodyStart].start),
    removed: true
  };
}

function cleanupImportedDocxSpacing_(html) {
  let value = String(html || '');
  value = value.replace(/\s(?:height|min-height)\s*=\s*(['"]?)[^\s>]+\1/gi, '');
  value = value.replace(/<br\b[^>]*\b(?:page-break-before|break-before)\s*:\s*(?:always|page)[^>]*>/gi, '<br>');
  value = value.replace(/<(p|div)\b([^>]*)>([\s\S]*?)<\/\1>/gi, function(all, tag, attrs, content) {
    if (/<(?:img|table|hr)\b/i.test(content)) return all;
    const plain = htmlToPlainText_(content).replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
    return plain ? all : '<p data-bgps-import-empty="1"><br></p>';
  });
  value = value.replace(/(?:\s*<p data-bgps-import-empty="1"><br><\/p>){2,}/gi, '<p data-bgps-import-empty="1"><br></p>');
  value = value.replace(/<p data-bgps-import-empty="1"><br><\/p>/gi, '<p><br></p>');
  value = value.replace(/(?:<br\s*\/?>\s*){3,}/gi, '<br><br>');
  return value;
}

function standardizeImportedQuestionBlocks_(html) {
  return String(html || '').replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi, function(all, attrs, content) {
    const text = htmlToPlainText_(content).replace(/\s+/g, ' ');
    if (/^\s*(?:section|खंड)\s+[A-Z0-9]/i.test(text)) {
      return '<h2 class="section-heading"><span>' + content + '</span></h2>';
    }
    if (/^\s*(?:(?:Q|Question)\s*\.?\s*\d+|\d+\s*[.)-])/i.test(text)) {
      const cleanedAttrs = String(attrs || '').replace(/\sclass\s*=\s*(['"])([^'"]*)\1/i, ' class="question-line $2"');
      return '<p' + (cleanedAttrs === attrs ? cleanedAttrs + ' class="question-line"' : cleanedAttrs) + '>' + content + '</p>';
    }
    if (/^\s*OR\s*$/i.test(text)) {
      const orAttrs = String(attrs || '').replace(/\sclass\s*=\s*(['"])([^'"]*)\1/i, ' class="or-line $2"');
      return '<p' + (orAttrs === attrs ? orAttrs + ' class="or-line"' : orAttrs) + '>' + content + '</p>';
    }
    if (/^[A-Za-z0-9]+(?:\s+[A-Za-z0-9]+)*(?:\s*(?:\/|\\)\s*[A-Za-z0-9]+)+$/.test(text)) {
      const inlineAttrs = String(attrs || '').replace(/\sclass\s*=\s*(['"])([^'"]*)\1/i, ' class="bgps-inline-option $2"');
      return '<p' + (inlineAttrs === attrs ? inlineAttrs + ' class="bgps-inline-option"' : inlineAttrs) + '>' + content + '</p>';
    }
    return all;
  });
}

function standardizeImportedDocxLayout_(html) {
  let value = standardizeImportedQuestionBlocks_(html);
  value = value.replace(/<p\b([^>]*)>/gi, function(all, attrs) {
    if (/\bbgps-inline-option\b/i.test(attrs)) return all;
    const cleanedAttrs = String(attrs || '').replace(/\sstyle\s*=\s*(['"])([\s\S]*?)\1/gi, function(styleAll, quote, declarations) {
      const kept = String(declarations || '').split(';').filter(function(declaration) {
        const property = cleanText_(String(declaration).split(':')[0]).toLowerCase();
        return ['text-align', 'white-space', 'tab-size', 'margin', 'margin-left', 'margin-right', 'margin-top', 'margin-bottom', 'text-indent', 'line-height'].indexOf(property) === -1;
      }).filter(Boolean);
      return kept.length ? ' style="' + kept.join(';') + '"' : '';
    });
    return '<p' + cleanedAttrs + '>';
  });
  value = value.replace(/(?:(?:\s*<p\b[^>]*\bbgps-inline-option\b[^>]*>[\s\S]*?<\/p>){2,})/gi, function(run) {
    return '<div class="bgps-inline-options">' + String(run).trim() + '</div>';
  });
  return value;
}

function convertHtmlBlobToPdf_(htmlBlob, baseName) {
  try {
    const directPdf = htmlBlob.getAs(MimeType.PDF);
    const signature = directPdf.getBytes().slice(0, 5).map(function(value) { return Number(value) & 255; });
    if (signature.join(',') === '37,80,68,70,45') {
      return directPdf.setName(cleanText_(baseName || 'Question Paper') + '.pdf');
    }
  } catch (directError) {
    console.warn('Direct HTML-to-PDF conversion unavailable; using Drive conversion.', safeErrorMessage_(directError));
  }
  let googleDocId = '';
  try {
    const source = Utilities.newBlob(htmlBlob.getBytes(), 'text/html', cleanText_(baseName || 'Question Paper') + '.html');
    const converted = Drive.Files.create({ name: cleanText_(baseName || 'Question Paper') + ' - Print', mimeType: GOOGLE_DOC_MIME }, source, { fields: 'id' });
    googleDocId = cleanText_(converted && converted.id);
    if (!googleDocId) throw new Error('Google Drive did not return a print document ID.');
    let lastError = null;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      try {
        if (attempt > 0) Utilities.sleep(600 * attempt);
        const pdf = DriveApp.getFileById(googleDocId).getAs(MimeType.PDF);
        if (pdf && pdf.getBytes().length) return pdf.setName(cleanText_(baseName || 'Question Paper') + '.pdf');
      } catch (error) { lastError = error; }
    }
    throw lastError || new Error('The print-ready PDF was not ready.');
  } finally {
    if (googleDocId) trashFileQuietly_(googleDocId);
  }
}


function loadPaperContentRecord_(contentJson) {
  const compact = parseJsonObject_(contentJson);
  const contentFileId = cleanText_(compact.contentDriveFileId || '');
  if (!contentFileId) return compact;
  try {
    const file = DriveApp.getFileById(contentFileId);
    if (file.isTrashed()) throw new Error('Stored editable content is in Trash.');
    const full = parseJsonObject_(file.getBlob().getDataAsString());
    return Object.assign({}, compact, full, { contentDriveFileId: contentFileId });
  } catch (error) {
    console.error('Could not load paper content sidecar: ' + safeErrorMessage_(error));
    return compact;
  }
}

function preparePaperContentStorage_(content, previousContentJson) {
  const payload = JSON.stringify(content || {});
  const previous = parseJsonObject_(previousContentJson);
  const previousFileId = cleanText_(previous.contentDriveFileId || '');
  // Google Sheets cells are limited to 50,000 characters. Keep a safety margin.
  if (payload.length <= 45000) {
    return {
      cellJson: payload,
      createdFile: null,
      fileId: '',
      obsoleteFileId: previousFileId
    };
  }

  const paperId = cleanText_(content && content.paperId) || Utilities.getUuid();
  const storedName = 'paper-content-' + paperId + '-' + Date.now() + '.json';
  const file = getQuestionPaperFolder_().createFile(Utilities.newBlob(payload, 'application/json', storedName));
  const compact = Object.assign({}, content || {}, {
    editorHtml: '',
    bodyText: '',
    contentDriveFileId: file.getId(),
    hasDriveContent: true
  });
  const cellJson = JSON.stringify(compact);
  if (cellJson.length > 45000) {
    trashFileQuietly_(file);
    throw new Error('Paper metadata is too large to save safely. Reduce very large notes or embedded data.');
  }
  return {
    cellJson: cellJson,
    createdFile: file,
    fileId: file.getId(),
    obsoleteFileId: previousFileId
  };
}

function extractElementInnerHtmlByClass_(documentHtml, className) {
  const source = String(documentHtml || '');
  const wantedClass = cleanText_(className || '');
  if (!source || !wantedClass) return '';

  const openingTag = /<([a-z][a-z0-9:-]*)\b([^>]*)>/gi;
  let match = null;
  let target = null;
  while ((match = openingTag.exec(source))) {
    const classMatch = String(match[2] || '').match(/\bclass\s*=\s*(["'])([^"']*)\1/i);
    const classes = classMatch ? String(classMatch[2] || '').split(/\s+/).filter(String) : [];
    if (classes.indexOf(wantedClass) !== -1) {
      target = { tagName: String(match[1] || '').toLowerCase(), contentStart: openingTag.lastIndex };
      break;
    }
  }
  if (!target) return '';

  const tagPattern = /<\/?([a-z][a-z0-9:-]*)\b[^>]*>/gi;
  tagPattern.lastIndex = target.contentStart;
  let depth = 1;
  while ((match = tagPattern.exec(source))) {
    if (String(match[1] || '').toLowerCase() !== target.tagName) continue;
    const closing = /^<\//.test(match[0]);
    const selfClosing = /\/\s*>$/.test(match[0]);
    if (closing) depth -= 1;
    else if (!selfClosing) depth += 1;
    if (depth === 0) return source.slice(target.contentStart, match.index);
  }
  return '';
}

function looksLikePortalApplicationSource_(value) {
  const text = htmlToPlainText_(String(value || '')).toLowerCase();
  if (!text) return false;
  const signatures = [
    'let settings = null',
    'function escapehtml(value)',
    "byid('settingsstatus')",
    'function applysettings(value)',
    'window.bgps_',
    'papercontenteditor',
    'function setstatus(message'
  ];
  let matches = 0;
  signatures.forEach(function(signature) {
    if (text.indexOf(signature) !== -1) matches += 1;
  });
  return matches >= 3
    || (text.indexOf('let settings = null') !== -1
      && text.indexOf('function escapehtml(value)') !== -1);
}

function isUsablePaperEditorHtml_(value) {
  const html = String(value || '').trim();
  if (!html || looksLikePortalApplicationSource_(html)) return false;
  return Boolean(htmlToPlainText_(html));
}

function recoverPortalPaperEditorContent_(record) {
  const fileId = cleanText_(record && record.driveFileId);
  if (!fileId) return null;
  try {
    const file = DriveApp.getFileById(fileId);
    if (file.isTrashed()) return null;
    const name = cleanText_(file.getName());
    const mimeType = cleanText_(file.getMimeType()).toLowerCase();
    if (mimeType.indexOf('html') === -1 && !/\.html?$/i.test(name)) return null;
    const documentHtml = file.getBlob().getDataAsString('UTF-8');
    const recovered = normalizePaperContentHtml_(extractElementInnerHtmlByClass_(documentHtml, 'content'));
    const bodyText = htmlToPlainText_(recovered);
    if (!bodyText || !isUsablePaperEditorHtml_(recovered)) return null;
    return {
      editorHtml: recovered,
      bodyText: bodyText,
      warnings: ['Editable content was recovered from the saved portal paper. Verify the layout before saving.'],
      source: 'recovered-canonical-html'
    };
  } catch (error) {
    console.warn('Portal paper editable content could not be recovered.', safeErrorMessage_(error));
    return null;
  }
}

function resolvePaperEditorContent_(user, record, content) {
  const storedHtml = String(content && content.editorHtml || '').trim();
  const storedHtmlIsUsable = isUsablePaperEditorHtml_(storedHtml);
  const uploadedDocx = isUploadedDocxRecord_(record);

  if (!uploadedDocx) {
    if (storedHtmlIsUsable) {
      return {
        editorHtml: storedHtml,
        bodyText: String(content.bodyText || htmlToPlainText_(storedHtml)),
        warnings: Array.isArray(content.importWarnings) ? content.importWarnings.slice(0, 10) : [],
        source: 'stored-editor'
      };
    }
    if (storedHtml) console.warn('Rejected contaminated portal editor content for paper ' + cleanText_(record && record.paperId));
    const recovered = recoverPortalPaperEditorContent_(record);
    return recovered || { editorHtml: '', bodyText: '', warnings: [], source: 'reference-only' };
  }

  // The saved BGPS working copy is the latest authority when it exists.
  if (savedBgpsStandardIsCurrent_(record, content)) {
    try {
      const workingFile = DriveApp.getFileById(cleanText_(content.standardizedHtmlFileId));
      if (!workingFile.isTrashed()) {
        const workingHtml = normalizePaperContentHtml_(workingFile.getBlob().getDataAsString('UTF-8'));
        if (isUsablePaperEditorHtml_(workingHtml)) {
          return {
            editorHtml: workingHtml,
            bodyText: htmlToPlainText_(workingHtml),
            warnings: Array.isArray(content.standardPreviewWarnings) ? content.standardPreviewWarnings.slice(0, 10) : [],
            source: 'saved-bgps-working-copy'
          };
        }
      }
    } catch (workingError) {
      console.warn('Saved BGPS working copy could not be loaded for full editing.', safeErrorMessage_(workingError));
    }
  }

  if (storedHtmlIsUsable) {
    return {
      editorHtml: storedHtml,
      bodyText: String(content.bodyText || htmlToPlainText_(storedHtml)),
      warnings: Array.isArray(content.standardPreviewWarnings) ? content.standardPreviewWarnings.slice(0, 10) : [],
      source: 'stored-editor'
    };
  }

  const generated = buildBgpsStandardDocxDocument_(record);
  if (!isUsablePaperEditorHtml_(generated.editableContentHtml)) {
    throw new Error('The submitted DOCX could not be converted into safe editable paper content.');
  }
  return {
    editorHtml: generated.editableContentHtml,
    bodyText: htmlToPlainText_(generated.editableContentHtml),
    warnings: Array.isArray(generated.warnings) ? generated.warnings.slice(0, 10) : [],
    source: 'generated-from-original-docx'
  };
}

function getPaperContent_(user, paperId) {
  const record = findPaperRecord_(paperId);
  if (!user.isAdmin && record.teacherId.toUpperCase() !== user.id) {
    throw new Error('You do not have permission to open this paper.');
  }
  if (!user.isAdmin) {
    const status = cleanText_(record.status);
    if (status !== 'Correction Required') {
      throw new Error(status === 'Approved'
        ? 'Approved papers are final for teachers. Ask the Principal before making further changes.'
        : status === 'Submitted'
          ? 'This paper is submitted and locked while it awaits Principal review.'
          : 'This paper is not currently available for editing.');
    }
  }

  const content = loadPaperContentRecord_(record.contentJson);
  const resolvedEditor = resolvePaperEditorContent_(user, record, content);
  const editable = Boolean(String(resolvedEditor.editorHtml || '').trim());
  const title = cleanText_(content.title) || record.originalFileName || (record.className + ' ' + record.subject + ' ' + record.exam + ' Paper');
  return {
    ok: true,
    editable: editable,
    requiresReplacement: !editable,
    paper: {
      paperId: record.paperId,
      originalPaperId: cleanText_(content.originalPaperId || content.revisionOriginalId || record.paperId),
      parentPaperId: record.paperId,
      previousVersion: record.version,
      version: record.version,
      title: title,
      className: record.className,
      subject: record.subject,
      exam: record.exam,
      chapters: record.chapters,
      maxMarks: record.maxMarks,
      examDate: record.examDate,
      note: record.note,
      adminNote: record.adminNote,
      timeAllowed: cleanText_(content.timeAllowed || record.timeAllowed),
      instructions: cleanText_(content.instructions),
      languageMode: cleanText_(content.languageMode || 'english'),
      editorHtml: String(resolvedEditor.editorHtml || ''),
      bodyText: String(resolvedEditor.bodyText || content.bodyText || ''),
      detectedMarks: Number(content.detectedMarks || content.standardPreviewDetectedMarks || 0),
      totalQuestions: Number(content.totalQuestions || content.standardPreviewTotalQuestions || record.totalQuestions || 0),
      status: record.status,
      sourceType: (!user.isAdmin && isUploadedDocxRecord_(record)) ? 'DOCX Import' : record.sourceType,
      originalFileName: cleanText_(content.originalFileName || record.originalFileName || ''),
      sourceFileId: cleanText_(content.sourceFileId || record.driveFileId || ''),
      editorSource: resolvedEditor.source,
      importWarnings: resolvedEditor.warnings
    }
  };
}

function getPaperDraftPreview_(user, draftId) {
  const result = getPaperDraft_(user, draftId);
  const draft = result.draft || {};
  const html = buildCanonicalPaperHtml_(draft, draft.teacherId || user.id, Number(draft.previousVersion || 0) + 1);
  return {
    ok: true,
    draftId: draft.draftId,
    mimeType: 'text/html',
    documentHtml: html,
    title: draft.title || (draft.className + ' ' + draft.subject + ' ' + draft.exam),
    warnings: Array.isArray(draft.importWarnings) ? draft.importWarnings : []
  };
}

function saveAdminEditedUploadedDocx_(user, initialRecord, currentContent, editedContent) {
  if (!user.isAdmin) throw new Error('Only Admin can edit submitted DOCX papers.');
  if (!isUploadedDocxRecord_(initialRecord)) throw new Error('The paper is not an uploaded DOCX.');

  let editorHtml = normalizePaperContentHtml_(editedContent.editorHtml);
  if (!/\bbgps-standardized-docx\b/i.test(editorHtml)) {
    editorHtml = '<div class="bgps-standardized-docx">' + editorHtml + '</div>';
  }
  const bodyText = htmlToPlainText_(editorHtml);
  if (!bodyText) throw new Error('The edited paper does not contain readable content.');

  const totalQuestions = countQuestionBlocks_(editorHtml, bodyText);
  const detectedMarks = sumDetectedMarks_(editorHtml);
  const warnings = Array.isArray(currentContent.standardPreviewWarnings)
    ? currentContent.standardPreviewWarnings.slice(0, 10) : [];
  if (totalQuestions <= 0) warnings.push('Question numbering could not be detected automatically. Verify the paper before approval.');
  if (detectedMarks > 0 && editedContent.maxMarks > 0 && Math.abs(detectedMarks - editedContent.maxMarks) > 0.01) {
    warnings.push('Detected question marks total ' + detectedMarks + ', while Maximum Marks is ' + editedContent.maxMarks + '.');
  }

  const content = Object.assign({}, editedContent, {
    editorHtml: editorHtml,
    bodyText: bodyText,
    detectedMarks: detectedMarks > 0 ? detectedMarks : Number(editedContent.maxMarks || 0),
    totalQuestions: totalQuestions > 0 ? totalQuestions : Number(currentContent.standardPreviewTotalQuestions || initialRecord.totalQuestions || 0),
    sourceType: 'DOCX Upload',
    lastEditedBy: user.id,
    lastEditedAt: new Date().toISOString()
  });

  const canonicalHtml = buildCanonicalPaperHtml_(content, initialRecord.teacherId, initialRecord.version);
  const baseName = buildStoredPaperName_(content.className, content.subject, content.exam, initialRecord.version, 'html').replace(/\.html$/i, '');
  const workingBlob = Utilities.newBlob(editorHtml, 'text/html', baseName + ' - BGPS Working Copy.html');
  const previewBlob = convertHtmlBlobToPdf_(Utilities.newBlob(canonicalHtml, 'text/html', baseName + '.html'), baseName + ' - BGPS Preview')
    .setName(baseName + ' - BGPS Preview.pdf');
  if (!workingBlob.getBytes().length || workingBlob.getBytes().length > PAPER_MAX_BYTES) throw new Error('The edited working copy exceeds the 8 MB limit. Compress large images.');
  if (!previewBlob.getBytes().length || previewBlob.getBytes().length > PAPER_MAX_BYTES) throw new Error('The edited preview exceeds the 8 MB limit. Compress large images.');

  const folder = getQuestionPaperFolder_();
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  let workingFile = null;
  let previewFile = null;
  let contentStorage = null;
  try {
    const record = findPaperRecord_(initialRecord.paperId);
    if (!isPaperReadyForPrincipalReviewStatus_(record.status)) {
      throw new Error('Only a DOCX awaiting Principal review can be edited before approval.');
    }
    if (Number(record.version || 0) !== Number(initialRecord.version || 0) || record.driveFileId !== initialRecord.driveFileId) {
      throw new Error('A newer paper version is available. Refresh Paper Approval and open Edit again.');
    }

    const previousContent = loadPaperContentRecord_(record.contentJson);
    workingFile = folder.createFile(workingBlob);
    previewFile = folder.createFile(previewBlob);
    const savedAt = new Date().toISOString();
    const nextContent = Object.assign({}, previousContent, content, {
      paperId: record.paperId,
      standardPreviewSaved: true,
      standardPreviewSavedAt: savedAt,
      standardPreviewSavedBy: user.id,
      standardPreviewSavedVersion: record.version,
      standardPreviewLoggedVersion: record.version,
      standardPreviewWarnings: warnings.slice(0, 10),
      standardPreviewTotalQuestions: content.totalQuestions,
      standardPreviewDetectedMarks: content.detectedMarks,
      standardizedHtmlFileId: workingFile.getId(),
      standardizedSourceFileId: record.driveFileId,
      standardizedStorageMode: 'TEMP_HTML_UNTIL_APPROVAL',
      originalFilePreserved: previousContent.originalDeleted !== true
    });
    contentStorage = preparePaperContentStorage_(nextContent, record.contentJson);

    const sheet = record.sheet;
    sheet.getRange(record.rowNumber, 3).setValue(new Date());
    sheet.getRange(record.rowNumber, 5).setValue(content.className);
    sheet.getRange(record.rowNumber, 6).setValue(content.subject);
    sheet.getRange(record.rowNumber, 7).setValue(content.exam);
    sheet.getRange(record.rowNumber, 8).setValue(content.chapters);
    sheet.getRange(record.rowNumber, 9).setValue(content.maxMarks);
    sheet.getRange(record.rowNumber, 10).setValue(content.examDate);
    sheet.getRange(record.rowNumber, 11).setValue(content.note);
    // Columns 12-15 remain the untouched original DOCX metadata and Drive file.
    sheet.getRange(record.rowNumber, 20).setValue(content.timeAllowed);
    sheet.getRange(record.rowNumber, 21).setValue(content.totalQuestions);
    sheet.getRange(record.rowNumber, 22).setValue(contentStorage.cellJson);
    sheet.getRange(record.rowNumber, 24).setValue(previewFile.getId());
    SpreadsheetApp.flush();

    try {
      appendPrincipalActivity_(user, 'Paper Edit', {
        teacherId: record.teacherId,
        className: content.className,
        subjects: content.subject,
        paperId: record.paperId,
        message: 'Principal edited the uploaded DOCX in the full paper editor. Original DOCX preserved.'
      });
    } catch (activityError) {
      console.warn('Paper was updated, but the activity log could not be written.', safeErrorMessage_(activityError));
    }

    const oldWorkingId = cleanText_(previousContent.standardizedHtmlFileId);
    if (oldWorkingId && oldWorkingId !== workingFile.getId()) trashFileQuietly_(oldWorkingId);
    if (record.previewPdfFileId && record.previewPdfFileId !== record.driveFileId && record.previewPdfFileId !== previewFile.getId()) {
      trashFileQuietly_(record.previewPdfFileId);
    }
    if (contentStorage.obsoleteFileId && contentStorage.obsoleteFileId !== contentStorage.fileId) trashFileQuietly_(contentStorage.obsoleteFileId);

    return {
      ok: true,
      paperId: record.paperId,
      updated: true,
      standardPreviewSaved: true,
      savedAt: savedAt,
      maxMarks: content.maxMarks,
      totalQuestions: content.totalQuestions,
      detectedMarks: content.detectedMarks,
      status: record.status,
      originalPreserved: previousContent.originalDeleted !== true
    };
  } catch (error) {
    if (workingFile) trashFileQuietly_(workingFile);
    if (previewFile) trashFileQuietly_(previewFile);
    if (contentStorage && contentStorage.createdFile) trashFileQuietly_(contentStorage.createdFile);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function updatePaperContentAdmin_(user, paperId, input) {
  if (!user.isAdmin) throw new Error('Only Admin can edit submitted papers.');

  const record = findPaperRecord_(paperId);
  if (!isPaperReadyForPrincipalReviewStatus_(record.status)) {
    throw new Error('Only a paper awaiting Principal review can be edited. Approved and returned papers are locked.');
  }
  const current = loadPaperContentRecord_(record.contentJson);
  const patch = input && typeof input === 'object' ? input : {};
  const hasIncomingEditor = Boolean(String(patch.editorHtml || '').trim());
  if (!String(current.editorHtml || '').trim() && !hasIncomingEditor && !isUploadedDocxRecord_(record)) {
    throw new Error('This paper is reference-only and cannot be edited safely in the portal.');
  }
  const className = cleanText_(patch.className || record.className);
  const subject = cleanText_(patch.subject || record.subject);
  const exam = cleanText_(patch.exam || record.exam);
  const chapters = normalizePaperChapters_(className, patch.chapters != null ? patch.chapters : record.chapters);
  const examDate = cleanText_(patch.examDate != null ? patch.examDate : record.examDate);
  const title = cleanText_(patch.title || current.title || record.originalFileName).slice(0, 180);
  const maxMarks = Number(patch.maxMarks || record.maxMarks);
  const timeAllowed = cleanText_(patch.timeAllowed || current.timeAllowed || record.timeAllowed).slice(0, 80);
  const instructions = cleanText_(patch.instructions != null ? patch.instructions : current.instructions).slice(0, 4000);
  const note = cleanText_(patch.note != null ? patch.note : record.note).slice(0, 250);
  const languageMode = cleanText_(patch.languageMode || current.languageMode || 'english');
  const editorHtml = normalizePaperContentHtml_(patch.editorHtml != null ? patch.editorHtml : current.editorHtml);
  const bodyText = cleanText_(patch.bodyText || htmlToPlainText_(editorHtml));

  if (ALL_CLASSES.indexOf(className) === -1) throw new Error('Select a valid class.');
  if (!title || !subject || !exam) throw new Error('Paper Title, Subject and Exam / Term are required.');
  if (!chapters && !isPrePrimaryClass_(className)) throw new Error('Chapters / Portion is required.');
  if (!Number.isFinite(maxMarks) || maxMarks <= 0) throw new Error('Maximum marks must be greater than zero.');
  if (!timeAllowed) throw new Error('Time Allowed is required.');
  if (!editorHtml || bodyText.length < 20) throw new Error('Paper content is blank.');
  if (bodyText.toLowerCase().indexOf('type question here') !== -1) throw new Error('Replace placeholder text before saving.');

  const uploadedDocx = isUploadedDocxRecord_(record);
  const detectedMarks = sumDetectedMarks_(editorHtml);
  if (!uploadedDocx && detectedMarks > 0 && Math.abs(detectedMarks - maxMarks) > 0.01) {
    throw new Error('Detected question marks are ' + detectedMarks + ', but Maximum Marks is ' + maxMarks + '.');
  }
  const totalQuestions = countQuestionBlocks_(editorHtml, bodyText);
  if (!uploadedDocx && totalQuestions <= 0) throw new Error('At least one question is required.');

  const content = Object.assign({}, current, {
    paperId: record.paperId,
    title: title,
    className: className,
    subject: subject,
    exam: exam,
    chapters: chapters,
    maxMarks: maxMarks,
    examDate: examDate,
    note: note,
    timeAllowed: timeAllowed,
    instructions: instructions,
    languageMode: languageMode,
    editorHtml: editorHtml,
    bodyText: bodyText,
    detectedMarks: detectedMarks > 0 ? detectedMarks : maxMarks,
    totalQuestions: totalQuestions,
    revisionVersion: record.version,
    lastEditedBy: user.id,
    lastEditedAt: new Date().toISOString()
  });

  if (uploadedDocx) {
    return saveAdminEditedUploadedDocx_(user, record, current, content);
  }

  const canonicalHtml = buildCanonicalPaperHtml_(content, record.teacherId, record.version);
  const storedName = buildStoredPaperName_(className, subject, exam, record.version, 'html');
  const htmlBlob = Utilities.newBlob(canonicalHtml, 'text/html', storedName);
  const byteLength = htmlBlob.getBytes().length;
  if (byteLength > PAPER_MAX_BYTES) throw new Error('Edited paper exceeds the 8 MB storage limit.');

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  let createdFile = null;
  let createdPdfFile = null;
  let fileId = record.driveFileId;
  try {
    const freshRecord = findPaperRecord_(record.paperId);
    if (!isPaperReadyForPrincipalReviewStatus_(freshRecord.status)) {
      throw new Error('The paper status changed. Refresh Paper Approval before editing again.');
    }
    if (Number(freshRecord.version || 0) !== Number(record.version || 0) || freshRecord.driveFileId !== record.driveFileId) {
      throw new Error('A newer paper version is available. Refresh Paper Approval before saving.');
    }
    createdPdfFile = getQuestionPaperFolder_().createFile(convertHtmlBlobToPdf_(htmlBlob, storedName.replace(/\.html$/i, '')));
    try {
      const file = DriveApp.getFileById(record.driveFileId);
      if (file.isTrashed()) throw new Error('Stored file is in Trash.');
      file.setContent(canonicalHtml);
      file.setName(storedName);
      fileId = file.getId();
    } catch (fileError) {
      createdFile = getQuestionPaperFolder_().createFile(htmlBlob);
      fileId = createdFile.getId();
    }

    const sheet = record.sheet;
    sheet.getRange(record.rowNumber, 3).setValue(new Date());
    sheet.getRange(record.rowNumber, 5).setValue(className);
    sheet.getRange(record.rowNumber, 6).setValue(subject);
    sheet.getRange(record.rowNumber, 7).setValue(exam);
    sheet.getRange(record.rowNumber, 8).setValue(chapters);
    sheet.getRange(record.rowNumber, 9).setValue(maxMarks);
    sheet.getRange(record.rowNumber, 10).setValue(examDate);
    sheet.getRange(record.rowNumber, 11).setValue(note);
    sheet.getRange(record.rowNumber, 12).setValue(storedName);
    sheet.getRange(record.rowNumber, 13).setValue('text/html');
    sheet.getRange(record.rowNumber, 14).setValue(byteLength);
    sheet.getRange(record.rowNumber, 15).setValue(fileId);
    sheet.getRange(record.rowNumber, 20).setValue(timeAllowed);
    sheet.getRange(record.rowNumber, 21).setValue(totalQuestions);
    const contentStorage = preparePaperContentStorage_(content, record.contentJson);
    sheet.getRange(record.rowNumber, 22).setValue(contentStorage.cellJson);
    sheet.getRange(record.rowNumber, 24).setValue(createdPdfFile.getId());
    appendPrincipalActivity_(user, 'Paper Edit', {
      teacherId: record.teacherId,
      className: className,
      subjects: subject,
      paperId: record.paperId,
      message: 'Principal edited question-paper content in the full editor.'
    });
    SpreadsheetApp.flush();

    if (contentStorage.obsoleteFileId && contentStorage.obsoleteFileId !== contentStorage.fileId) trashFileQuietly_(contentStorage.obsoleteFileId);
    if (createdFile && record.driveFileId && record.driveFileId !== fileId) trashFileQuietly_(record.driveFileId);
    if (record.previewPdfFileId && record.previewPdfFileId !== createdPdfFile.getId()) trashFileQuietly_(record.previewPdfFileId);
    return {
      ok: true,
      paperId: record.paperId,
      updated: true,
      fileId: fileId,
      maxMarks: maxMarks,
      totalQuestions: totalQuestions,
      detectedMarks: content.detectedMarks,
      status: record.status
    };
  } catch (error) {
    if (createdFile) trashFileQuietly_(createdFile);
    if (createdPdfFile) trashFileQuietly_(createdPdfFile);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function paperFinalKey_(className, subject, exam, examDate, fallbackDate) {
  const session = academicSessionLabel_(cleanText_(examDate) || fallbackDate || new Date());
  return [className, subject, exam, session]
    .map(function(value) { return cleanText_(value).toUpperCase().replace(/\s+/g, ' '); })
    .join('|');
}

function paperFinalKeyFromRow_(row) {
  return paperFinalKey_(row[4], row[5], row[6], row[9], row[1] || row[2]);
}

function archiveApprovedRow_(sheet, row, rowNumber, winnerPaperId, archivedBy) {
  const nextRow = row.slice();
  const now = new Date();
  const note = ('Superseded by approved final ' + cleanText_(winnerPaperId)).slice(0, 500);
  let contentStorage = null;
  try {
    const content = loadPaperContentRecord_(row[21]);
    const nextContent = Object.assign({}, content, {
      superseded: true,
      supersededByPaperId: cleanText_(winnerPaperId),
      supersededAt: now.toISOString(),
      supersededBy: cleanText_(archivedBy || ADMIN_ID),
      supersededPreviousStatus: cleanText_(row[16]) || 'Approved'
    });
    contentStorage = preparePaperContentStorage_(nextContent, row[21]);
    nextRow[21] = contentStorage.cellJson;
  } catch (contentError) {
    console.warn('Could not add superseded metadata for paper ' + cleanText_(row[0]) + ': ' + safeErrorMessage_(contentError));
  }
  nextRow[2] = now;
  nextRow[16] = 'Locked';
  nextRow[17] = note;
  sheet.getRange(rowNumber, 1, 1, PAPER_HEADERS.length).setValues([nextRow]);
  if (contentStorage && contentStorage.obsoleteFileId && contentStorage.obsoleteFileId !== contentStorage.fileId) {
    trashFileQuietly_(contentStorage.obsoleteFileId);
  }
  return true;
}

function archiveOtherApprovedFinals_(winnerRecord, archivedBy) {
  const sheet = winnerRecord.sheet || ensureQuestionPaperSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { archived: 0, warnings: [] };
  const winnerKey = paperFinalKey_(winnerRecord.className, winnerRecord.subject, winnerRecord.exam, winnerRecord.examDate, winnerRecord.uploadedAt || winnerRecord.updatedAt);
  const rows = sheet.getRange(2, 1, lastRow - 1, PAPER_HEADERS.length).getValues();
  let archived = 0;
  const warnings = [];
  rows.forEach(function(row, index) {
    if (cleanText_(row[0]) === cleanText_(winnerRecord.paperId)) return;
    if (cleanText_(row[16]).toLowerCase() !== 'approved') return;
    if (paperFinalKeyFromRow_(row) !== winnerKey) return;
    try {
      archiveApprovedRow_(sheet, row, index + 2, winnerRecord.paperId, archivedBy);
      archived += 1;
    } catch (error) {
      warnings.push('Could not archive older final ' + cleanText_(row[0]) + ': ' + safeErrorMessage_(error));
    }
  });
  SpreadsheetApp.flush();
  return { archived: archived, warnings: warnings };
}

function repairDuplicateApprovedPapers_() {
  const sheet = ensureQuestionPaperSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { repaired: 0, groups: 0, warnings: [] };
  const rows = sheet.getRange(2, 1, lastRow - 1, PAPER_HEADERS.length).getValues();
  const groups = {};
  rows.forEach(function(row, index) {
    if (cleanText_(row[16]).toLowerCase() !== 'approved') return;
    const key = paperFinalKeyFromRow_(row);
    if (!groups[key]) groups[key] = [];
    groups[key].push({ row: row, rowNumber: index + 2 });
  });

  let repaired = 0;
  let duplicateGroups = 0;
  const warnings = [];
  Object.keys(groups).forEach(function(key) {
    const entries = groups[key];
    if (entries.length <= 1) return;
    duplicateGroups += 1;
    entries.sort(function(a, b) {
      const aTime = new Date(a.row[2] || a.row[1] || 0).getTime() || 0;
      const bTime = new Date(b.row[2] || b.row[1] || 0).getTime() || 0;
      return bTime - aTime || (Number(b.row[15]) || 0) - (Number(a.row[15]) || 0) || b.rowNumber - a.rowNumber;
    });
    const winner = entries[0];
    entries.slice(1).forEach(function(entry) {
      try {
        archiveApprovedRow_(sheet, entry.row, entry.rowNumber, winner.row[0], ADMIN_ID);
        repaired += 1;
      } catch (error) {
        warnings.push('Could not archive duplicate final ' + cleanText_(entry.row[0]) + ': ' + safeErrorMessage_(error));
      }
    });
  });
  SpreadsheetApp.flush();
  return { repaired: repaired, groups: duplicateGroups, warnings: warnings };
}

function repairPaperWorkflowOnce_() {
  const properties = PropertiesService.getScriptProperties();
  if (properties.getProperty(PAPER_WORKFLOW_REPAIR_PROPERTY) === 'done') return;
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) return;
  try {
    if (properties.getProperty(PAPER_WORKFLOW_REPAIR_PROPERTY) === 'done') return;
    const result = repairDuplicateApprovedPapers_();
    if (!result.warnings.length) properties.setProperty(PAPER_WORKFLOW_REPAIR_PROPERTY, 'done');
  } catch (error) {
    console.error('V12 duplicate-final repair could not complete: ' + safeErrorMessage_(error));
  } finally {
    lock.releaseLock();
  }
}

function repairPaperWorkflow_(user) {
  if (!user || !user.isAdmin) throw new Error('Only Admin can repair the paper workflow.');
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const result = repairDuplicateApprovedPapers_();
    if (!result.warnings.length) PropertiesService.getScriptProperties().setProperty(PAPER_WORKFLOW_REPAIR_PROPERTY, 'done');
    return { ok: true, repaired: result.repaired, duplicateGroups: result.groups, warnings: result.warnings };
  } finally {
    lock.releaseLock();
  }
}

function updatePaperStatus_(user, paperId, status, adminNote, deleteOriginalAfterApproval) {
  if (!user.isAdmin) throw new Error('Only Admin can change paper status.');
  const cleanStatus = cleanText_(status);
  if (['Approved', 'Correction Required'].indexOf(cleanStatus) === -1) throw new Error('Invalid paper status.');
  const note = cleanText_(adminNote).slice(0, 500);
  if (cleanStatus === 'Correction Required' && !note) throw new Error('Enter a clear correction note before returning the paper.');

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  let approvalCommitted = false;
  let finalPdfResult = null;
  let contentStorage = null;
  try {
    const record = findPaperRecord_(paperId);
    const currentStatusKey = (cleanText_(record.status) || 'Submitted').toLowerCase();
    // Network timeouts can make the browser retry after the Sheet commit has
    // already succeeded. Treat the same approval request as an idempotent success.
    if (currentStatusKey === 'approved' && cleanStatus === 'Approved') {
      const existingContent = loadPaperContentRecord_(record.contentJson);
      return {
        ok: true,
        paperId: record.paperId,
        status: 'Approved',
        editable: false,
        requiresReplacement: false,
        finalPdfFileId: cleanText_(record.previewPdfFileId || existingContent.finalApprovedPdfFileId),
        originalDeleted: existingContent.originalDeleted === true,
        originalDeleteWarning: '',
        archivedPreviousFinals: 0,
        archiveWarnings: [],
        idempotent: true
      };
    }
    if (!isPaperReadyForPrincipalReviewStatus_(record.status)) {
      throw new Error(currentStatusKey === 'approved'
        ? 'Approved papers are final and cannot be returned or approved again.'
        : 'This paper must be corrected and resubmitted by the teacher before the Principal can review it again.');
    }

    const sheet = record.sheet;
    if (cleanStatus === 'Correction Required') {
      const rowValues = sheet.getRange(record.rowNumber, 1, 1, PAPER_HEADERS.length).getValues()[0];
      rowValues[2] = new Date();
      rowValues[16] = 'Correction Required';
      rowValues[17] = note;
      sheet.getRange(record.rowNumber, 1, 1, PAPER_HEADERS.length).setValues([rowValues]);
      SpreadsheetApp.flush();
      const content = loadPaperContentRecord_(record.contentJson);
      const editable = !isUploadedDocxRecord_(record) && Boolean(String(content.editorHtml || '').trim());
      return { ok: true, paperId: record.paperId, status: cleanStatus, editable: editable, requiresReplacement: !editable, finalPdfFileId: '', originalDeleted: false, originalDeleteWarning: '' };
    }

    const content = loadPaperContentRecord_(record.contentJson);
    if (isUploadedDocxRecord_(record) && !savedBgpsStandardIsCurrent_(record, content)) {
      throw new Error('Preview and save the BGPS working copy before approving this DOCX paper.');
    }

    try {
      finalPdfResult = ensureFinalPdfForApproval_(record);
    } catch (previewError) {
      throw new Error('This paper cannot be approved because its final PDF could not be prepared. ' + safeErrorMessage_(previewError).slice(0, 220));
    }
    const finalPdfFileId = cleanText_(finalPdfResult && finalPdfResult.fileId);
    if (!finalPdfFileId) throw new Error('This paper cannot be approved until a final PDF is available.');

    const approvedAt = new Date().toISOString();
    const tempWorkingId = cleanText_(content.standardizedHtmlFileId);
    const nextContent = Object.assign({}, content, {
      standardPreviewApproved: true,
      standardPreviewApprovedAt: approvedAt,
      standardPreviewApprovedBy: user.id,
      finalApprovedPdfFileId: finalPdfFileId,
      standardizedStorageMode: 'FINAL_PDF_ONLY',
      originalDeleted: content.originalDeleted === true,
      originalFilePreserved: content.originalDeleted !== true,
      superseded: false,
      supersededByPaperId: ''
    });
    if (tempWorkingId) delete nextContent.standardizedHtmlFileId;
    contentStorage = preparePaperContentStorage_(nextContent, record.contentJson);

    const rowValues = sheet.getRange(record.rowNumber, 1, 1, PAPER_HEADERS.length).getValues()[0];
    rowValues[2] = new Date();
    rowValues[16] = 'Approved';
    rowValues[17] = note;
    rowValues[21] = contentStorage.cellJson;
    rowValues[23] = finalPdfFileId;
    sheet.getRange(record.rowNumber, 1, 1, PAPER_HEADERS.length).setValues([rowValues]);
    SpreadsheetApp.flush();
    approvalCommitted = true;

    const winnerRecord = findPaperRecord_(record.paperId);
    const archiveResult = archiveOtherApprovedFinals_(winnerRecord, user.id);
    let originalDeleted = content.originalDeleted === true;
    let originalDeleteWarning = '';

    if (deleteOriginalAfterApproval === true && isUploadedDocxRecord_(record) && !originalDeleted) {
      let originalFile = null;
      try {
        if (record.driveFileId === finalPdfFileId) throw new Error('The original and final file references are identical.');
        originalFile = DriveApp.getFileById(record.driveFileId);
        if (!originalFile.isTrashed()) originalFile.setTrashed(true);
        const deletedContent = Object.assign({}, nextContent, {
          originalDeleted: true,
          originalDeletedAt: new Date().toISOString(),
          originalDeletedBy: user.id,
          originalFilePreserved: false
        });
        const deletedStorage = preparePaperContentStorage_(deletedContent, contentStorage.cellJson);
        sheet.getRange(record.rowNumber, 22).setValue(deletedStorage.cellJson);
        SpreadsheetApp.flush();
        if (deletedStorage.obsoleteFileId && deletedStorage.obsoleteFileId !== deletedStorage.fileId) trashFileQuietly_(deletedStorage.obsoleteFileId);
        if (contentStorage.createdFile && (!deletedStorage.createdFile || contentStorage.createdFile.getId() !== deletedStorage.createdFile.getId())) {
          trashFileQuietly_(contentStorage.createdFile);
        }
        contentStorage = deletedStorage;
        originalDeleted = true;
      } catch (deleteError) {
        originalDeleteWarning = safeErrorMessage_(deleteError).slice(0, 220);
        try { if (originalFile && originalFile.isTrashed()) originalFile.setTrashed(false); } catch (restoreError) { console.error('Could not restore original DOCX after metadata failure: ' + safeErrorMessage_(restoreError)); }
      }
    }

    if (tempWorkingId) trashFileQuietly_(tempWorkingId);
    if (contentStorage.obsoleteFileId && contentStorage.obsoleteFileId !== contentStorage.fileId) trashFileQuietly_(contentStorage.obsoleteFileId);

    return {
      ok: true,
      paperId: record.paperId,
      status: 'Approved',
      editable: false,
      requiresReplacement: false,
      finalPdfFileId: finalPdfFileId,
      originalDeleted: originalDeleted,
      originalDeleteWarning: originalDeleteWarning,
      archivedPreviousFinals: archiveResult.archived,
      archiveWarnings: archiveResult.warnings
    };
  } catch (error) {
    if (!approvalCommitted && finalPdfResult && finalPdfResult.created && finalPdfResult.fileId) trashFileQuietly_(finalPdfResult.fileId);
    if (!approvalCommitted && contentStorage && contentStorage.createdFile) trashFileQuietly_(contentStorage.createdFile);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function ensureFinalPdfForApproval_(record) {
  if (isUploadedDocxRecord_(record)) {
    const content = loadPaperContentRecord_(record.contentJson);
    if (!savedBgpsStandardIsCurrent_(record, content)) throw new Error('The current BGPS working copy is missing or outdated.');
    const workingFile = DriveApp.getFileById(cleanText_(content.standardizedHtmlFileId));
    if (workingFile.isTrashed()) throw new Error('The BGPS working copy is in Drive Trash.');
    const generated = buildBgpsStandardDocxDocument_(record, workingFile.getBlob().getDataAsString('UTF-8'));
    const pdfBlob = convertHtmlBlobToPdf_(Utilities.newBlob(generated.documentHtml, 'text/html', generated.baseName + '.html'), generated.baseName).setName(generated.baseName + ' - APPROVED.pdf');
    if (!pdfBlob.getBytes().length) throw new Error('The generated final PDF is empty.');
    if (pdfBlob.getBytes().length > PAPER_MAX_BYTES) throw new Error('The final PDF exceeds the 8 MB storage limit.');
    const file = getQuestionPaperFolder_().createFile(pdfBlob);
    return { fileId: file.getId(), created: true };
  }
  const existingId = cleanText_(record.previewPdfFileId);
  if (existingId) {
    try {
      const existing = DriveApp.getFileById(existingId);
      if (!existing.isTrashed() && existing.getBlob().getBytes().length) return { fileId: existing.getId(), created: false };
    } catch (ignored) {}
  }
  const source = DriveApp.getFileById(record.driveFileId);
  if (source.isTrashed()) throw new Error('The stored source file is in Drive Trash.');
  const sourceBlob = source.getBlob();
  const mime = cleanText_(record.mimeType || sourceBlob.getContentType()).toLowerCase();
  const extension = fileExtension_(record.originalFileName || source.getName());
  if (mime.indexOf('pdf') !== -1 || extension === 'pdf') return { fileId: source.getId(), created: false };
  if (mime.indexOf('html') !== -1 || extension === 'html' || extension === 'htm') {
    const baseName = String(record.originalFileName || source.getName() || 'Question Paper').replace(/\.html?$/i, '');
    const pdfFile = getQuestionPaperFolder_().createFile(convertHtmlBlobToPdf_(sourceBlob, baseName));
    if (!pdfFile.getBlob().getBytes().length) {
      trashFileQuietly_(pdfFile);
      throw new Error('The generated PDF is empty.');
    }
    return { fileId: pdfFile.getId(), created: true };
  }
  throw new Error('The stored source format cannot be converted to a final PDF.');
}

function sendReminder_(user, reminder) {
  if (!user.isAdmin) throw new Error('Only Admin can send reminders.');

  const input = reminder && typeof reminder === 'object' ? reminder : {};
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName('ReminderLog');
  const headers = ['Timestamp', 'Admin ID', 'Teacher ID', 'Class', 'Subjects', 'Message'];
  if (!sheet) sheet = spreadsheet.insertSheet('ReminderLog');
  ensureHeaders_(sheet, headers);

  sheet.appendRow([
    new Date(),
    user.id,
    cleanText_(input.teacherId),
    cleanText_(input.className),
    cleanText_(input.subjects),
    cleanText_(input.message || 'Reminder from Principal Command Centre').slice(0, 500)
  ]);
  appendPrincipalActivity_(user, 'Reminder', input);
  SpreadsheetApp.flush();

  return { ok: true, reminderLogged: true };
}

function addPrincipalComment_(user, comment) {
  if (!user.isAdmin) throw new Error('Only Admin can add principal comments.');

  const input = comment && typeof comment === 'object' ? comment : {};
  const message = cleanText_(input.message).slice(0, 500);
  if (!message) throw new Error('Comment is required.');

  appendPrincipalActivity_(user, 'Comment', input);
  SpreadsheetApp.flush();
  return { ok: true, commentLogged: true };
}

function listPrincipalActivity_(user) {
  if (!user.isAdmin) throw new Error('Only Admin can view principal activity.');

  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('PrincipalActivityLog');
  if (!sheet || sheet.getLastRow() <= 1) return { ok: true, activity: [] };

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(cleanText_);
  const rows = sheet.getRange(2, 1, sheet.getLastRow() - 1, headers.length).getValues();
  const activity = rows.map(function(row) {
    const item = {};
    headers.forEach(function(header, index) { item[header] = row[index]; });
    return item;
  }).filter(item => cleanText_(item.Timestamp)).map(item => ({
    timestamp: item.Timestamp,
    type: cleanText_(item.Type),
    adminId: cleanText_(item['Admin ID']),
    teacherId: cleanText_(item['Teacher ID']),
    className: cleanText_(item.Class),
    subjects: cleanText_(item.Subjects),
    paperId: cleanText_(item['Paper ID']),
    message: cleanText_(item.Message)
  })).sort((a, b) => String(b.timestamp || '').localeCompare(String(a.timestamp || '')));

  return { ok: true, activity: activity };
}

function appendPrincipalActivity_(user, type, input) {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName('PrincipalActivityLog');
  const headers = ['Timestamp', 'Type', 'Admin ID', 'Teacher ID', 'Class', 'Subjects', 'Paper ID', 'Message'];
  if (!sheet) sheet = spreadsheet.insertSheet('PrincipalActivityLog');
  ensureHeaders_(sheet, headers);
  sheet.appendRow([
    new Date(),
    cleanText_(type),
    user.id,
    cleanText_(input.teacherId),
    cleanText_(input.className),
    cleanText_(input.subjects),
    cleanText_(input.paperId),
    cleanText_(input.message || 'Principal follow-up').slice(0, 500)
  ]);
}


function deleteDraftsLinkedToPaperUnlocked_(paperId) {
  const id = cleanText_(paperId);
  if (!id) return { deleted: 0, fileIds: [] };
  const sheet = ensurePaperDraftSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { deleted: 0, fileIds: [] };
  const headerMap = getHeaderMap_(sheet, PAPER_DRAFTS_HEADERS);
  const width = Math.max(sheet.getLastColumn(), PAPER_DRAFTS_HEADERS.length);
  const rows = sheet.getRange(2, 1, lastRow - 1, width).getValues();
  const targets = [];
  const fileIds = [];
  rows.forEach(function(row, index) {
    let draft = {};
    try { draft = draftFromRow_(row, headerMap, false); }
    catch (error) { console.warn('Could not inspect linked draft: ' + safeErrorMessage_(error)); }
    if (cleanText_(draft.parentPaperId) !== id && cleanText_(draft.originalPaperId) !== id) return;
    targets.push(index + 2);
    const contentFileId = cleanText_(rowValue_(row, headerMap, 'Content Drive File ID'));
    if (contentFileId) fileIds.push(contentFileId);
    if (draft.sourceFileId) fileIds.push(cleanText_(draft.sourceFileId));
  });
  targets.sort(function(a, b) { return b - a; }).forEach(function(rowNumber) { sheet.deleteRow(rowNumber); });
  return { deleted: targets.length, fileIds: fileIds };
}

function deletePaper_(user, paperId) {
  if (!user.isAdmin) throw new Error('Only Admin can delete submitted papers.');
  const id = cleanText_(paperId);
  if (!id) throw new Error('Paper ID is missing.');

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  let deletedRecord = null;
  let linkedDrafts = { deleted: 0, fileIds: [] };
  const cleanupIds = [];
  try {
    // Resolve the row only after acquiring the lock so a concurrent submission,
    // correction or repair cannot shift rows and cause the wrong paper to be deleted.
    const record = findPaperRecord_(id);
    const content = loadPaperContentRecord_(record.contentJson);
    deletedRecord = record;
    [record.driveFileId, record.previewPdfFileId, content.contentDriveFileId,
      content.sourceFileId, content.standardizedHtmlFileId].forEach(function(fileId) {
      const cleanId = cleanText_(fileId);
      if (cleanId && cleanupIds.indexOf(cleanId) === -1) cleanupIds.push(cleanId);
    });
    const previewPropertyKey = PAPER_PREVIEW_PROPERTY_PREFIX + record.paperId;
    const previewFileId = cleanText_(PropertiesService.getScriptProperties().getProperty(previewPropertyKey));
    if (previewFileId && cleanupIds.indexOf(previewFileId) === -1) cleanupIds.push(previewFileId);

    linkedDrafts = deleteDraftsLinkedToPaperUnlocked_(record.paperId);
    linkedDrafts.fileIds.forEach(function(fileId) {
      const cleanId = cleanText_(fileId);
      if (cleanId && cleanupIds.indexOf(cleanId) === -1) cleanupIds.push(cleanId);
    });
    record.sheet.deleteRow(record.rowNumber);
    PropertiesService.getScriptProperties().deleteProperty(previewPropertyKey);
    SpreadsheetApp.flush();
  } finally {
    lock.releaseLock();
  }

  // Sheet deletion is the authoritative commit. Drive cleanup happens only
  // afterwards, preventing a failed row delete from leaving a live record with
  // missing files.
  cleanupIds.forEach(function(fileId) { trashFileQuietly_(fileId); });
  return {
    ok: true,
    paperId: deletedRecord.paperId,
    title: [deletedRecord.className, deletedRecord.subject, deletedRecord.exam].filter(Boolean).join(' - '),
    deleted: true,
    linkedDraftsDeleted: linkedDrafts.deleted
  };
}

function findPaperRecord_(paperId) {
  const id = cleanText_(paperId);
  if (!id) throw new Error('Paper ID is missing.');

  const sheet = ensureQuestionPaperSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) throw new Error('Question paper not found.');

  const rows = sheet.getRange(2, 1, lastRow - 1, PAPER_HEADERS.length).getValues();
  for (let index = 0; index < rows.length; index++) {
    const row = rows[index];
    if (cleanText_(row[0]) === id) {
      return {
        sheet: sheet,
        rowNumber: index + 2,
        paperId: cleanText_(row[0]),
        uploadedAt: row[1],
        updatedAt: row[2],
        teacherId: cleanText_(row[3]),
        className: cleanText_(row[4]),
        subject: cleanText_(row[5]),
        exam: cleanText_(row[6]),
        chapters: cleanText_(row[7]),
        maxMarks: Number(row[8]) || 0,
        examDate: cleanText_(row[9]),
        note: cleanText_(row[10]),
        originalFileName: cleanText_(row[11]),
        mimeType: cleanText_(row[12]),
        fileSize: Number(row[13]) || 0,
        driveFileId: cleanText_(row[14]),
        version: Number(row[15]) || 1,
        status: cleanText_(row[16]),
        adminNote: cleanText_(row[17]),
        sourceType: cleanText_(row[18]) || 'Upload',
        timeAllowed: cleanText_(row[19]),
        totalQuestions: Number(row[20]) || 0,
        contentJson: String(row[21] || ''),
        teacherName: cleanText_(row[22]) || cleanText_(row[3]),
        previewPdfFileId: cleanText_(row[23])
      };
    }
  }

  throw new Error('Question paper not found.');
}

function normalizeRequestToken_(value) {
  return cleanText_(value).replace(/[^a-zA-Z0-9._:-]+/g, '').slice(0, PAPER_REQUEST_TOKEN_MAX_LENGTH);
}

function stableDraftIdFromRequest_(prefix, token) {
  const safePrefix = cleanText_(prefix || 'request').replace(/[^a-zA-Z0-9_-]+/g, '-').slice(0, 16) || 'request';
  const normalized = normalizeRequestToken_(token);
  if (!normalized) return '';
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, normalized, Utilities.Charset.UTF_8);
  const hash = Utilities.base64EncodeWebSafe(digest).replace(/=+$/g, '').slice(0, 32);
  return safePrefix + '-' + hash;
}

function findPaperBySubmissionToken_(sheet, teacherId, submissionToken) {
  const token = normalizeRequestToken_(submissionToken);
  const owner = cleanText_(teacherId).toUpperCase();
  if (!token || !owner || !sheet || sheet.getLastRow() <= 1) return null;
  const rows = sheet.getRange(2, 1, sheet.getLastRow() - 1, PAPER_HEADERS.length).getValues();
  for (let index = 0; index < rows.length; index += 1) {
    const row = rows[index];
    if (cleanText_(row[3]).toUpperCase() !== owner) continue;
    const content = parseJsonObject_(row[21]);
    if (normalizeRequestToken_(content.submissionToken || '') === token) {
      return findPaperRecord_(row[0]);
    }
  }
  return null;
}

function idempotentPaperResponse_(record) {
  return {
    ok: true,
    paperId: record.paperId,
    version: Number(record.version || 1),
    status: cleanText_(record.status) || 'Submitted',
    sourceType: cleanText_(record.sourceType) || 'Manual',
    resubmitted: Boolean(loadPaperContentRecord_(record.contentJson).wasCorrectionResubmission),
    idempotent: true,
    message: 'This submission was already received. The existing paper record was returned.'
  };
}

function savePaperDraft_(user, draft) {
  if (!draft || typeof draft !== 'object') throw new Error('Draft details are missing.');
  if (user.isAdmin) throw new Error('Admin cannot save teacher drafts.');

  const draftId = cleanText_(draft.draftId) || createDraftId_();
  const title = cleanText_(draft.title);
  const className = cleanText_(draft.className);
  const subject = cleanText_(draft.subject);
  const exam = cleanText_(draft.exam);
  const chapters = normalizePaperChapters_(className, draft.chapters);
  const maxMarks = Number(draft.maxMarks);
  const examDate = cleanText_(draft.examDate);
  const note = cleanText_(draft.note).slice(0, 250);
  const timeAllowed = cleanText_(draft.timeAllowed || inferPaperTime_(draft.maxMarks)).slice(0, 80);
  const instructions = cleanText_(draft.instructions || '').slice(0, 4000);
  const languageMode = cleanText_(draft.languageMode || 'english');
  const editorHtml = normalizePaperContentHtml_(draft.editorHtml);
  const bodyText = cleanText_(draft.bodyText || '');
  const detectedMarks = Number(draft.detectedMarks || 0);
  const totalQuestions = Number(draft.totalQuestions || 0) || countQuestionBlocks_(editorHtml, bodyText);
  const sourceType = cleanText_(draft.sourceType || '');
  const originalPaperId = cleanText_(draft.originalPaperId || draft.revisionOriginalId || '');
  const parentPaperId = cleanText_(draft.parentPaperId || draft.revisionParentId || '');
  const previousVersion = Number(draft.previousVersion || 0);
  const originalFileName = cleanText_(draft.originalFileName || '');
  const sourceFileId = cleanText_(draft.sourceFileId || '');
  const importWarnings = Array.isArray(draft.importWarnings) ? draft.importWarnings.map(cleanText_).filter(String).slice(0, 10) : [];
  const requestId = normalizeRequestToken_(draft.requestId || draft.submissionToken || '');

  if (!className || !subject || !exam || !title) {
    throw new Error('Draft must have Class, Subject, Exam and Title.');
  }

  let linkedCorrection = null;
  if (parentPaperId) {
    linkedCorrection = findPaperRecord_(parentPaperId);
    if (cleanText_(linkedCorrection.teacherId).toUpperCase() !== user.id) {
      throw new Error('You do not have permission to save this corrected paper.');
    }
    const linkedStatus = cleanText_(linkedCorrection.status);
    if (linkedStatus !== 'Correction Required') {
      throw new Error(linkedStatus === 'Approved'
        ? 'Approved papers are final for teachers.'
        : linkedStatus === 'Submitted'
          ? 'This paper has already been resubmitted and is locked while awaiting Principal review.'
          : 'This paper is not currently available for editing.');
    }
  }
  if (!linkedCorrection || cleanText_(linkedCorrection.status) !== 'Correction Required') {
    enforcePaperClassAccess_(user, className);
  }

  const sheet = ensurePaperDraftSheet_();
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  let createdFile = null;
  let obsoleteFileId = '';
  try {
    // A delayed autosave/retry must never recreate a draft after its submission
    // transaction has already produced the final paper row.
    const submittedPaper = findPaperBySubmissionToken_(ensureQuestionPaperSheet_(), user.id, 'draft:' + draftId);
    if (submittedPaper) {
      return {
        ok: true,
        draftId: draftId,
        status: 'Submitted',
        submittedPaperId: submittedPaper.paperId,
        locked: true,
        idempotent: true
      };
    }
    const headerMap = getHeaderMap_(sheet, PAPER_DRAFTS_HEADERS);
    const width = Math.max(sheet.getLastColumn(), PAPER_DRAFTS_HEADERS.length);
    const lastRow = sheet.getLastRow();
    const rows = lastRow > 1 ? sheet.getRange(2, 1, lastRow - 1, width).getValues() : [];
    let targetRow = 0;
    let targetValues = null;
    let previousFileId = '';

    for (let i = 0; i < rows.length; i++) {
      if (cleanText_(rowValue_(rows[i], headerMap, 'Draft ID')) === draftId) {
        if (cleanText_(rowValue_(rows[i], headerMap, 'Teacher ID')).toUpperCase() !== user.id) {
          throw new Error('You do not have permission to update this draft.');
        }
        targetRow = i + 2;
        targetValues = rows[i].slice();
        previousFileId = cleanText_(rowValue_(rows[i], headerMap, 'Content Drive File ID'));
        break;
      }
    }

    const now = new Date();
    const createdAt = targetValues ? rowValue_(targetValues, headerMap, 'Created At') : (draft.createdAt || now);
    const previousDraft = targetValues ? draftFromRow_(targetValues, headerMap, true) : {};
    if (targetValues && requestId && normalizeRequestToken_(previousDraft.requestId || '') === requestId) {
      return { ok: true, draftId: draftId, status: 'Cloud draft saved', idempotent: true };
    }
    if (targetValues && (cleanText_(previousDraft.status).toLowerCase() === 'submitted' || previousDraft.submittedPaperId)) {
      throw new Error('This draft is already submitted and cannot be changed.');
    }
    if (parentPaperId) {
      const currentParent = findPaperRecord_(parentPaperId);
      if (cleanText_(currentParent.teacherId).toUpperCase() !== user.id) throw new Error('You do not have permission to save this corrected paper.');
      if (cleanText_(currentParent.status) !== 'Correction Required') {
        throw new Error(cleanText_(currentParent.status) === 'Approved'
          ? 'Approved papers are final for teachers.'
          : 'This corrected paper is already submitted and locked for Principal review.');
      }
    }
    const contentRecord = {
      draftId: draftId,
      teacherId: user.id,
      title: title,
      className: className,
      subject: subject,
      exam: exam,
      chapters: chapters,
      maxMarks: maxMarks,
      examDate: examDate,
      note: note,
      timeAllowed: timeAllowed,
      instructions: instructions,
      languageMode: languageMode,
      editorHtml: editorHtml,
      bodyText: bodyText,
      detectedMarks: detectedMarks,
      totalQuestions: totalQuestions,
      status: 'Draft',
      sourceType: sourceType || previousDraft.sourceType || 'Manual',
      originalPaperId: originalPaperId,
      parentPaperId: parentPaperId,
      previousVersion: previousVersion,
      originalFileName: originalFileName || previousDraft.originalFileName || '',
      sourceFileId: sourceFileId || previousDraft.sourceFileId || '',
      importWarnings: importWarnings.length ? importWarnings : (previousDraft.importWarnings || []),
      requestId: requestId || previousDraft.requestId || ''
    };
    const storage = prepareDraftStorage_(contentRecord, previousFileId);
    createdFile = storage.createdFile;
    obsoleteFileId = storage.obsoleteFileId;

    const rowValues = targetValues || new Array(width).fill('');
    setRowValue_(rowValues, headerMap, 'Draft ID', draftId);
    setRowValue_(rowValues, headerMap, 'Created At', createdAt);
    setRowValue_(rowValues, headerMap, 'Updated At', now);
    setRowValue_(rowValues, headerMap, 'Teacher ID', user.id);
    setRowValue_(rowValues, headerMap, 'Title', title);
    setRowValue_(rowValues, headerMap, 'Class', className);
    setRowValue_(rowValues, headerMap, 'Subject', subject);
    setRowValue_(rowValues, headerMap, 'Exam / Term', exam);
    setRowValue_(rowValues, headerMap, 'Chapters', chapters);
    setRowValue_(rowValues, headerMap, 'Max Marks', maxMarks);
    setRowValue_(rowValues, headerMap, 'Exam Date', examDate);
    setRowValue_(rowValues, headerMap, 'Teacher Note', note);
    setRowValue_(rowValues, headerMap, 'Time Allowed', timeAllowed);
    setRowValue_(rowValues, headerMap, 'Instructions', instructions);
    setRowValue_(rowValues, headerMap, 'Language Mode', languageMode);
    setRowValue_(rowValues, headerMap, 'Editor HTML', storage.editorHtml);
    setRowValue_(rowValues, headerMap, 'Body Text', storage.bodyText);
    setRowValue_(rowValues, headerMap, 'Detected Marks', detectedMarks);
    setRowValue_(rowValues, headerMap, 'Total Questions', totalQuestions);
    setRowValue_(rowValues, headerMap, 'Status', 'Draft');
    setRowValue_(rowValues, headerMap, 'Source Type', contentRecord.sourceType);
    setRowValue_(rowValues, headerMap, 'Draft JSON', storage.draftJson);
    setRowValue_(rowValues, headerMap, 'Content Drive File ID', storage.fileId);

    if (targetRow) {
      sheet.getRange(targetRow, 1, 1, width).setValues([rowValues]);
    } else {
      sheet.getRange(sheet.getLastRow() + 1, 1, 1, width).setValues([rowValues]);
    }

    SpreadsheetApp.flush();
    if (obsoleteFileId) trashFileQuietly_(obsoleteFileId);
    return { ok: true, draftId: draftId, status: 'Cloud draft saved' };
  } catch (error) {
    if (createdFile) trashFileQuietly_(createdFile);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function listPaperDrafts_(user) {
  const sheet = ensurePaperDraftSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { ok: true, drafts: [] };

  const headerMap = getHeaderMap_(sheet, PAPER_DRAFTS_HEADERS);
  const width = Math.max(sheet.getLastColumn(), PAPER_DRAFTS_HEADERS.length);
  const rows = sheet.getRange(2, 1, lastRow - 1, width).getValues();
  const drafts = rows
    .filter(function(row) {
      return user.isAdmin || cleanText_(rowValue_(row, headerMap, 'Teacher ID')).toUpperCase() === user.id;
    })
    .map(function(row) {
      const draft = draftFromRow_(row, headerMap, false);
      draft.editorHtml = '';
      draft.bodyText = '';
      return draft;
    });

  return { ok: true, drafts: drafts };
}

function getPaperDraft_(user, draftId) {
  const id = cleanText_(draftId);
  if (!id) throw new Error('Draft ID is missing.');

  const sheet = ensurePaperDraftSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) throw new Error('Draft not found.');

  const headerMap = getHeaderMap_(sheet, PAPER_DRAFTS_HEADERS);
  const width = Math.max(sheet.getLastColumn(), PAPER_DRAFTS_HEADERS.length);
  const rows = sheet.getRange(2, 1, lastRow - 1, width).getValues();
  for (let i = 0; i < rows.length; i++) {
    if (cleanText_(rowValue_(rows[i], headerMap, 'Draft ID')) === id) {
      if (!user.isAdmin && cleanText_(rowValue_(rows[i], headerMap, 'Teacher ID')).toUpperCase() !== user.id) {
        throw new Error('You do not have permission to view this draft.');
      }
      return {
        ok: true,
        draft: draftFromRow_(rows[i], headerMap, true)
      };
    }
  }

  throw new Error('Draft not found.');
}

function deletePaperDraft_(user, draftId) {
  const id = cleanText_(draftId);
  if (!id) throw new Error('Draft ID is missing.');

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const sheet = ensurePaperDraftSheet_();
    const lastRow = sheet.getLastRow();
    if (lastRow <= 1) throw new Error('Draft not found.');

    const headerMap = getHeaderMap_(sheet, PAPER_DRAFTS_HEADERS);
    const width = Math.max(sheet.getLastColumn(), PAPER_DRAFTS_HEADERS.length);
    const rows = sheet.getRange(2, 1, lastRow - 1, width).getValues();
    for (let i = 0; i < rows.length; i++) {
      if (cleanText_(rowValue_(rows[i], headerMap, 'Draft ID')) === id) {
        if (!user.isAdmin && cleanText_(rowValue_(rows[i], headerMap, 'Teacher ID')).toUpperCase() !== user.id) {
          throw new Error('You do not have permission to delete this draft.');
        }
        const contentFileId = cleanText_(rowValue_(rows[i], headerMap, 'Content Drive File ID'));
        const draftContent = draftFromRow_(rows[i], headerMap, false);
        sheet.deleteRow(i + 2);
        SpreadsheetApp.flush();
        if (contentFileId) trashFileQuietly_(contentFileId);
        if (draftContent.sourceFileId) trashFileQuietly_(draftContent.sourceFileId);
        return { ok: true, draftId: id, deleted: true };
      }
    }

    throw new Error('Draft not found.');
  } finally {
    lock.releaseLock();
  }
}

function submitPaperDraft_(user, draftId) {
  if (user.isAdmin) throw new Error('Admin cannot submit teacher drafts.');
  const id = cleanText_(draftId);
  if (!id) throw new Error('Draft ID is missing.');

  const sheet = ensureQuestionPaperSheet_();
  const draftSheet = ensurePaperDraftSheet_();
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  let createdFile = null;
  let createdPdfFile = null;
  let createdContentFile = null;
  let obsoleteContentFileId = '';
  let paperMetadataPersisted = false;
  try {
    const submissionToken = normalizeRequestToken_('draft:' + id);
    const previousSubmission = findPaperBySubmissionToken_(sheet, user.id, submissionToken);
    if (previousSubmission) return idempotentPaperResponse_(previousSubmission);

    const headerMap = getHeaderMap_(draftSheet, PAPER_DRAFTS_HEADERS);
    const width = Math.max(draftSheet.getLastColumn(), PAPER_DRAFTS_HEADERS.length);
    const lastRow = draftSheet.getLastRow();
    if (lastRow <= 1) throw new Error('Draft not found.');
    const rows = draftSheet.getRange(2, 1, lastRow - 1, width).getValues();
    let draft = null;
    let rowNumber = 0;
    let rowValues = null;
    for (let i = 0; i < rows.length; i++) {
      if (cleanText_(rowValue_(rows[i], headerMap, 'Draft ID')) === id) {
        if (cleanText_(rowValue_(rows[i], headerMap, 'Teacher ID')).toUpperCase() !== user.id) {
          throw new Error('You do not have permission to submit this draft.');
        }
        draft = draftFromRow_(rows[i], headerMap, true);
        rowNumber = i + 2;
        rowValues = rows[i].slice();
        break;
      }
    }
    if (!draft || !draft.draftId) throw new Error('Draft not found.');
    if (cleanText_(draft.status).toLowerCase() === 'submitted' || draft.submittedPaperId) {
      throw new Error('This draft is already submitted.');
    }
    let revisionRecord = null;
    let revisionWasCorrection = false;
    if (draft.parentPaperId) {
      revisionRecord = findPaperRecord_(draft.parentPaperId);
      if (revisionRecord.teacherId.toUpperCase() !== user.id) throw new Error('You do not have permission to edit this paper.');
      const revisionStatus = cleanText_(revisionRecord.status);
      if (revisionStatus !== 'Correction Required') {
        throw new Error(revisionStatus === 'Approved'
          ? 'Approved papers are final for teachers.'
          : revisionStatus === 'Submitted'
            ? 'This corrected paper is already submitted and locked for Principal review.'
            : 'This paper is not currently available for editing.');
      }
      revisionWasCorrection = true;
    }
    const draftSourceType = cleanText_(draft.sourceType).toLowerCase();
    const submissionChannel = (draftSourceType === 'docx upload' || draftSourceType === 'docx import' || draftSourceType === 'upload') ? 'upload' : 'creator';
    // A returned paper is an existing Principal-requested revision, not a new
    // submission. It must remain resubmittable even if the general creation or
    // upload window is later closed.
    if (!revisionWasCorrection) assertPaperChannelOpen_(submissionChannel);
    if (!revisionWasCorrection) enforcePaperClassAccess_(user, draft.className);
    draft.chapters = normalizePaperChapters_(draft.className, draft.chapters);
    if (ALL_CLASSES.indexOf(cleanText_(draft.className)) === -1) throw new Error('Draft has an invalid class.');
    if (!cleanText_(draft.className) || !cleanText_(draft.subject) || !cleanText_(draft.exam) || !cleanText_(draft.chapters)) {
      throw new Error(isPrePrimaryClass_(draft.className) ? 'Draft is incomplete. Class, Subject and Exam are required.' : 'Draft is incomplete. Class, Subject, Exam and Chapters are required.');
    }
    if (!Number.isFinite(Number(draft.maxMarks)) || Number(draft.maxMarks) <= 0) {
      throw new Error('Draft has invalid maximum marks.');
    }
    if (!cleanText_(draft.timeAllowed)) throw new Error('Time Allowed is required.');
    const editorHtml = normalizePaperContentHtml_(draft.editorHtml);
    const bodyText = cleanText_(draft.bodyText || editorHtml.replace(/<[^>]+>/g, ' '));
    if (!editorHtml || bodyText.length < 20) throw new Error('Draft content is blank.');
    if (bodyText.toLowerCase().indexOf('type question here') !== -1) {
      throw new Error('Replace placeholder text before submission.');
    }
    const htmlDetectedMarks = sumDetectedMarks_(editorHtml);
    const detectedMarks = htmlDetectedMarks > 0 ? htmlDetectedMarks : Number(draft.detectedMarks || 0);
    // DOCX marks may be stored in Word tables, text boxes or drawing fields that
    // the HTML importer cannot count perfectly. Do not reject an otherwise valid
    // DOCX correction because of that extraction limitation. Manual/portal-created
    // papers retain strict marks validation.
    if (!isDocxBasedDraft_(draft) && Math.abs(detectedMarks - Number(draft.maxMarks)) > 0.01) {
      throw new Error('Draft detected marks (' + detectedMarks + ') do not match Maximum Marks (' + Number(draft.maxMarks) + ').');
    }
    const totalQuestions = Number(draft.totalQuestions || 0) || countQuestionBlocks_(editorHtml, bodyText);
    // Raw/imported DOCX papers can contain valid questions in Word paragraphs,
    // tables or text boxes without the portal's question-line classes. Keep the
    // strict empty-question guard for portal-created papers, but do not falsely
    // block a DOCX returned by the Principal from being resubmitted.
    if (!isDocxBasedDraft_(draft) && totalQuestions <= 0) {
      throw new Error('Draft must contain at least one question.');
    }

    const version = nextPaperVersion_(sheet, draft.className, draft.subject, draft.exam);
    const paperId = revisionRecord ? revisionRecord.paperId : Utilities.getUuid();
    const now = new Date();
    const contentRecord = {
      paperId: paperId,
      title: draft.title,
      className: draft.className,
      subject: draft.subject,
      exam: draft.exam,
      chapters: draft.chapters,
      maxMarks: draft.maxMarks,
      examDate: draft.examDate,
      note: draft.note,
      timeAllowed: draft.timeAllowed || inferPaperTime_(draft.maxMarks),
      instructions: draft.instructions || '',
      languageMode: draft.languageMode || 'english',
      editorHtml: editorHtml,
      bodyText: bodyText,
      detectedMarks: detectedMarks,
      totalQuestions: totalQuestions,
      originalPaperId: draft.originalPaperId || draft.parentPaperId || paperId,
      parentPaperId: draft.parentPaperId || '',
      previousVersion: draft.previousVersion || 0,
      revisionOriginalId: draft.originalPaperId || draft.parentPaperId || paperId,
      revisionParentId: draft.parentPaperId || '',
      revisionVersion: version,
      wasCorrectionResubmission: Boolean(revisionRecord && revisionWasCorrection),
      sourceType: draft.sourceType || 'Manual',
      originalFileName: draft.originalFileName || '',
      sourceFileId: draft.sourceFileId || '',
      importWarnings: Array.isArray(draft.importWarnings) ? draft.importWarnings : [],
      submissionToken: submissionToken
    };
    const html = buildCanonicalPaperHtml_(contentRecord, user.id, version);
    const storedName = buildStoredPaperName_(draft.className, draft.subject, draft.exam, version, 'html');
    const blob = Utilities.newBlob(html, 'text/html', storedName);
    const file = getQuestionPaperFolder_().createFile(blob);
    createdFile = file;
    const byteLength = blob.getBytes().length;
    const pdfBlob = convertHtmlBlobToPdf_(blob, storedName.replace(/\.html$/i, ''));
    createdPdfFile = getQuestionPaperFolder_().createFile(pdfBlob);
    const sourceType = cleanText_(draft.sourceType || 'Manual') || 'Manual';
    const teacherName = getTeacherDisplayName_(user.id);
    const contentStorage = preparePaperContentStorage_(contentRecord, revisionRecord ? revisionRecord.contentJson : '');
    createdContentFile = contentStorage.createdFile;
    obsoleteContentFileId = contentStorage.obsoleteFileId || '';

    if (revisionRecord) {
      const row = revisionRecord.rowNumber;
      sheet.getRange(row, 3).setValue(now);
      sheet.getRange(row, 5, 1, 10).setValues([[
        draft.className, draft.subject, draft.exam, draft.chapters, draft.maxMarks,
        draft.examDate, draft.note, storedName, 'text/html', byteLength
      ]]);
      sheet.getRange(row, 15).setValue(file.getId());
      sheet.getRange(row, 16).setValue(version);
      sheet.getRange(row, 17).setValue('Submitted');
      sheet.getRange(row, 19).setValue(sourceType);
      sheet.getRange(row, 20).setValue(draft.timeAllowed || '');
      sheet.getRange(row, 21).setValue(totalQuestions);
      sheet.getRange(row, 22).setValue(contentStorage.cellJson);
      sheet.getRange(row, 23).setValue(teacherName);
      sheet.getRange(row, 24).setValue(createdPdfFile.getId());
    } else {
      sheet.appendRow([
        paperId, now, now, user.id, draft.className, draft.subject, draft.exam, draft.chapters,
        draft.maxMarks, draft.examDate, draft.note, storedName, 'text/html', byteLength,
        file.getId(), version, 'Submitted', '', sourceType, draft.timeAllowed || '', totalQuestions,
        contentStorage.cellJson, teacherName, createdPdfFile.getId()
      ]);
    }
    SpreadsheetApp.flush();
    paperMetadataPersisted = true;
    if (obsoleteContentFileId && (!createdContentFile || obsoleteContentFileId !== createdContentFile.getId())) trashFileQuietly_(obsoleteContentFileId);
    if (revisionRecord) {
      if (revisionRecord.driveFileId && revisionRecord.driveFileId !== file.getId()
          && revisionRecord.driveFileId !== cleanText_(draft.sourceFileId)) trashFileQuietly_(revisionRecord.driveFileId);
      if (revisionRecord.previewPdfFileId && revisionRecord.previewPdfFileId !== createdPdfFile.getId()) trashFileQuietly_(revisionRecord.previewPdfFileId);
      const previousContent = loadPaperContentRecord_(revisionRecord.contentJson);
      const previousSourceFileId = cleanText_(previousContent.sourceFileId);
      if (previousSourceFileId && previousSourceFileId !== cleanText_(draft.sourceFileId)) trashFileQuietly_(previousSourceFileId);
    }

    try {
      const submittedJson = Object.assign({}, parseJsonObject_(rowValue_(rowValues, headerMap, 'Draft JSON')), {
        submittedPaperId: paperId,
        status: 'Submitted'
      });
      setRowValue_(rowValues, headerMap, 'Status', 'Submitted');
      setRowValue_(rowValues, headerMap, 'Draft JSON', JSON.stringify(submittedJson));
      draftSheet.getRange(rowNumber, 1, 1, width).setValues([rowValues]);
      SpreadsheetApp.flush();
      draftSheet.deleteRow(rowNumber);
      if (draft.contentDriveFileId) trashFileQuietly_(draft.contentDriveFileId);
    } catch (cleanupError) {
      console.error(cleanupError);
    }

    return {
      ok: true,
      paperId: paperId,
      version: version,
      status: 'Submitted',
      resubmitted: Boolean(revisionRecord && revisionWasCorrection),
      editedSubmission: false
    };
  } catch (error) {
    if (createdContentFile && !paperMetadataPersisted) trashFileQuietly_(createdContentFile);
    if (createdFile && !paperMetadataPersisted) trashFileQuietly_(createdFile);
    if (createdPdfFile && !paperMetadataPersisted) trashFileQuietly_(createdPdfFile);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function nextPaperVersion_(sheet, className, subject, exam) {
  const rows = sheet.getLastRow() > 1 ? sheet.getRange(2, 1, sheet.getLastRow() - 1, PAPER_HEADERS.length).getValues() : [];
  let version = 1;
  rows.forEach(function(row) {
    if (cleanText_(row[4]) === className && cleanText_(row[5]).toUpperCase() === subject.toUpperCase() && cleanText_(row[6]) === exam) {
      version = Math.max(version, (Number(row[15]) || 0) + 1);
    }
  });
  return version;
}

function buildManualPaperHtml_(paper, teacherId, version) {
  const grouped = {};
  paper.questions.forEach(function(question, index) {
    const key = question.section || 'Section A';
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push({ number: index + 1, text: question.text, marks: question.marks, chapter: question.chapter, orText: question.orText });
  });

  const sectionHtml = Object.keys(grouped).map(function(sectionName) {
    const questionsHtml = grouped[sectionName].map(function(question) {
      const chapter = question.chapter ? '<div class="chapter">Chapter: ' + htmlEscape_(question.chapter) + '</div>' : '';
      const alternative = question.orText ? '<div class="or">OR</div><div class="question-text">' + nl2br_(htmlEscape_(question.orText)) + '</div>' : '';
      return '<div class="question"><div class="qnum">Q.' + question.number + '</div><div class="qbody"><div class="question-text">' + nl2br_(htmlEscape_(question.text)) + '</div>' + alternative + chapter + '</div><div class="marks">[' + htmlEscape_(question.marks) + ']</div></div>';
    }).join('');

    const sectionMarks = grouped[sectionName].reduce(function(sum, q) { return sum + Number(q.marks || 0); }, 0);
    return '<section><div class="section-title"><span>' + htmlEscape_(sectionName) + '</span><span>' + sectionMarks + ' Marks</span></div>' + questionsHtml + '</section>';
  }).join('');

  const readingTime = inferReadingTime_(paper.className, paper.maxMarks);
  const instructionItems = paper.instructions ? paper.instructions.split(/\n+/).map(function(line) { return cleanText_(line); }).filter(String) : [];
  const instructionsHtml = instructionItems.length ? '<div class="instructions"><strong>General Instructions:</strong><ol>' + instructionItems.map(function(item) { return '<li>' + htmlEscape_(item) + '</li>'; }).join('') + '</ol></div>' : '';

  return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + htmlEscape_(paper.className + ' ' + paper.subject + ' ' + paper.exam) + '</title><style>@page{size:A4;margin:14mm}*{box-sizing:border-box}html,body{-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact}body{font-family:Georgia,serif;color:#111;margin:0;background:#fff;font-size:14px;line-height:1.45}.paper{max-width:190mm;margin:auto}.header{text-align:center;border-bottom:2px solid #111;padding-bottom:8px;margin-bottom:10px}h1{font-size:24px;margin:0}.exam{font-size:16px;font-weight:700;margin-top:3px;text-transform:uppercase}.meta{display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;border:1px solid #111;padding:8px;margin-bottom:10px;font-weight:700}.instructions{border:1px solid #777;padding:8px 12px;margin-bottom:12px}.instructions ol{margin:5px 0 0 20px;padding:0}.section-title{display:flex;justify-content:space-between;font-weight:700;background:#eee;border:1px solid #111;padding:6px 8px;margin:12px 0 4px}.question{display:grid;grid-template-columns:38px 1fr 52px;gap:5px;padding:7px 2px;border-bottom:1px dotted #aaa;break-inside:avoid}.qnum,.marks{font-weight:700}.marks{text-align:right}.or{text-align:center;font-weight:700;margin:5px 0}.chapter{font-size:10px;color:#555;margin-top:4px;font-style:italic}.footer{margin-top:22px;display:flex;justify-content:space-between;font-size:11px;color:#555}.no-print{margin:12px auto;text-align:center}@media print{html,body,.paper,.paper *{color:#000!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}.header,.meta,.instructions,.section-title{border-color:#000!important}.question{border-bottom-color:#444!important}.no-print{display:none}.paper{max-width:none}}@media(max-width:600px){body{font-size:13px}.meta{grid-template-columns:1fr}.question{grid-template-columns:32px 1fr 42px}}</style></head><body><div class="no-print"><button onclick="window.print()" style="padding:10px 18px;font-weight:700">Print Question Paper</button></div><main class="paper"><div class="header"><h1>BG PUBLIC SCHOOL</h1><div class="exam">' + htmlEscape_(paper.exam || 'TERM / EXAM') + '</div></div><div class="meta"><div>Class: ' + htmlEscape_(paper.className) + '</div><div>Subject: ' + htmlEscape_(paper.subject) + '</div><div>Time: ' + htmlEscape_(paper.timeAllowed) + '</div><div>Maximum Marks: ' + htmlEscape_(paper.maxMarks) + '</div><div>Reading Time: ' + htmlEscape_(readingTime) + '</div><div>Exam Date: ' + htmlEscape_(paper.examDate || '____________') + '</div></div>' + instructionsHtml + sectionHtml + '<div class="footer"><span>Teacher: ' + htmlEscape_(teacherId) + '</span><span>Version ' + htmlEscape_(version) + '</span></div></main></body></html>';
}

function buildManualPaperHtmlFromDraft_(draft, version) {
  const html = String(draft.editorHtml || '');
  const readingTime = inferReadingTime_(draft.className, draft.maxMarks);
  return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + htmlEscape_(draft.className + ' ' + draft.subject + ' ' + draft.exam) + '</title><style>@page{size:A4;margin:14mm}*{box-sizing:border-box}html,body{-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact}body{font-family:Georgia,serif;color:#111;margin:0;background:#fff;font-size:14px;line-height:1.5}.paper{max-width:190mm;margin:auto}.header{text-align:center;border-bottom:1.8px solid #111;padding-bottom:8px}.header h1{font-size:24px;margin:0}.exam{font-size:15px;font-weight:800;text-transform:uppercase;margin-top:3px}.meta{display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;border-bottom:1px solid #555;padding:8px 0 9px;margin-bottom:12px;font-weight:700}.meta div:nth-child(even){text-align:right}.content h2.section-heading{display:flex;justify-content:space-between;margin:17px 0 8px;padding:6px 8px;border:1px solid #222;background:#f0f0f0;font-size:14px}.content h3{font-size:14px;margin:12px 0 6px}.content p{margin:6px 0}.paper-instructions{border:1px solid #777;padding:8px 12px;margin-bottom:12px}.paper-instructions h3{margin:0 0 5px}.paper-instructions ol{margin:4px 0 0 20px;padding:0}.question-line{position:relative;padding-right:48px;break-inside:avoid}.mark-token{float:right;font-weight:800}.or-line{text-align:center;font-weight:800}.content table{width:100%;border-collapse:collapse;margin:8px 0}.content td,.content th{border:1px solid #333;padding:6px}.diagram-box{min-height:120px;border:1.5px dashed #666;display:grid;place-items:center;color:#777;margin:9px 0}.page-break{page-break-after:always;border-top:1px dashed #777;margin:24px 0}@media print{html,body,.paper,.paper *{color:#000!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}.header,.meta,.paper-instructions,.content h2.section-heading,.content td,.content th{border-color:#000!important}.print-action{display:none}}@media(max-width:600px){.meta{grid-template-columns:1fr}.content{padding:0 4px}}</style></head><body><main class="paper"><div class="header"><h1>BG PUBLIC SCHOOL</h1><div class="exam">' + htmlEscape_(draft.exam || 'TERM / EXAM') + '</div></div><div class="meta"><div>Class: ' + htmlEscape_(draft.className) + '</div><div>Subject: ' + htmlEscape_(draft.subject) + '</div><div>Time Allotted: ' + htmlEscape_(draft.maxMarks ? inferPaperTime_(draft.maxMarks) : '—') + '</div><div>Maximum Marks: ' + htmlEscape_(draft.maxMarks) + '</div><div>Reading Time: ' + htmlEscape_(readingTime) + '</div><div>Date: ____________</div></div><div class="content">' + html + '</div></main></body></html>';
}

function buildCanonicalPaperHtml_(paper, teacherId, version) {
  const readingTime = inferReadingTime_(paper.className, paper.maxMarks);
  let bodySource = String(paper.editorHtml || '');
  if (/^DOCX Upload$/i.test(cleanText_(paper.sourceType))) {
    bodySource = stripImportedPaperHeader_(bodySource).html;
    bodySource = cleanupImportedDocxSpacing_(bodySource);
    bodySource = standardizeImportedDocxLayout_(bodySource);
  }
  const safeBody = normalizePaperContentHtml_(bodySource);
  const paperTitle = cleanText_(paper.title) || (paper.className + ' ' + paper.subject + ' ' + paper.exam + ' Paper');
  const bodyHasInstructions = /class\s*=\s*["'][^"']*\bpaper-instructions\b[^"']*["']/i.test(safeBody);
  const instructionLines = cleanText_(paper.instructions || '')
    .split(/\n+/)
    .map(function(line) { return cleanText_(line); })
    .filter(String);
  const instructionsHtml = instructionLines.length && !bodyHasInstructions
    ? '<div class="paper-instructions"><h3>General Instructions</h3><ol>' + instructionLines.map(function(line) { return '<li>' + htmlEscape_(line) + '</li>'; }).join('') + '</ol></div>'
    : '';

  const css = [
    '@page{size:A4 portrait;margin:11mm 13mm}',
    '*{box-sizing:border-box}',
    'html,body{-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact}',
    'body{font-family:Georgia,"Noto Serif Devanagari","Mangal",serif;color:#111;margin:0;background:#fff;font-size:10.8pt;line-height:1.34}',
    '.paper{width:184mm;max-width:100%;margin:0 auto;background:#fff}',
    '.header{text-align:center;border-bottom:3px double #111;padding:0 0 5px;margin-bottom:0}',
    '.header h1{font-size:20pt;line-height:1.05;letter-spacing:1px;margin:0;font-weight:900;text-transform:uppercase}',
    '.exam{font-size:13pt;line-height:1.15;font-weight:900;text-transform:uppercase;margin-top:3px}',
    '.session{font-size:9.5pt;font-weight:700;margin-top:2px}',
    '.meta{display:grid;grid-template-columns:1fr 1fr;gap:4px 15px;border-bottom:1.2px solid #111;padding:7px 0 7px;margin-bottom:8px;font-size:9.7pt}',
    '.meta>div{display:flex;align-items:baseline;gap:5px;min-width:0}',
    '.meta>div:nth-child(even){justify-content:flex-end;text-align:right}',
    '.meta-label{font-weight:700;white-space:nowrap}',
    '.meta-value{font-weight:900;min-width:28mm;border-bottom:1px dotted #555;padding:0 2px 1px}',
    '.content{position:relative;min-height:220mm;font-size:10.5pt;line-height:1.34}',
    '.content::after{content:"";display:block;clear:both}',
    '.content p{margin:3px 0;orphans:2;widows:2;white-space:normal}',
    '.content p.bgps-inline-option{display:inline-block;min-width:19mm;margin:2px 3mm 3px 0;vertical-align:top;white-space:pre-wrap}',
    '.content .bgps-inline-options{display:flex;flex-wrap:wrap;gap:2mm;margin:2px 0 4px;break-inside:avoid;page-break-inside:avoid}',
    '.content .bgps-inline-options p.bgps-inline-option{margin:0;min-width:19mm;padding:1px 2px}',
    '.content h2.section-heading{clear:both;display:flex;justify-content:space-between;align-items:center;margin:8px 0 4px;padding:3px 6px;border:1px solid #222;background:#f1f1f1;font-size:10.2pt;break-after:avoid;page-break-after:avoid}',
    '.content h3,.content h4{clear:both;font-size:10.2pt;margin:7px 0 3px;break-after:avoid;page-break-after:avoid}',
    '.paper-instructions{clear:both;border:1px solid #777;padding:5px 9px;margin-bottom:7px;font-size:9.5pt;line-height:1.28;break-inside:avoid;page-break-inside:avoid}',
    '.paper-instructions h3{margin:0 0 3px;font-size:10pt}',
    '.paper-instructions ol{margin:3px 0 0 18px;padding:0}',
    '.question-line{position:relative;padding-right:12mm;break-inside:avoid;page-break-inside:avoid}',
    '.bgps-standardized-docx{font-family:Georgia,"Noto Serif Devanagari","Mangal",serif!important;font-size:10.5pt!important;line-height:1.34!important}',
    '.bgps-standardized-docx .question-line{font-family:inherit!important;font-size:10.5pt!important;line-height:1.34!important;padding-left:11mm!important;padding-right:12mm!important;text-indent:-11mm!important;margin:3px 0!important}',
    '.bgps-standardized-docx .question-line strong:first-child,.bgps-standardized-docx .question-line b:first-child,.bgps-standardized-docx .question-line span:first-child{font-family:inherit!important;font-size:10.5pt!important;font-weight:900!important;letter-spacing:0!important}',
    '.bgps-standardized-docx p,.bgps-standardized-docx li,.bgps-standardized-docx td,.bgps-standardized-docx th{font-family:inherit!important}',
    '.bgps-standardized-docx .bgps-font-1,.bgps-standardized-docx .bgps-font-2,.bgps-standardized-docx .bgps-font-3,.bgps-standardized-docx .bgps-font-4,.bgps-standardized-docx .bgps-font-5,.bgps-standardized-docx .bgps-font-6,.bgps-standardized-docx .bgps-font-7{font-size:inherit!important;line-height:inherit!important}',
    '.bgps-standardized-docx.bgps-layout-compact{font-size:9.8pt!important;line-height:1.2!important}',
    '.bgps-standardized-docx.bgps-layout-compact p{margin:1px 0!important;line-height:1.2!important}',
    '.bgps-standardized-docx.bgps-layout-compact p:has(>br:only-child){font-size:4pt!important;line-height:1!important;margin:0!important}',
    '.bgps-standardized-docx.bgps-layout-compact .question-line{font-size:9.8pt!important;line-height:1.2!important;margin:1px 0!important;padding-left:10mm!important;text-indent:-10mm!important}',
    '.bgps-standardized-docx.bgps-layout-compact .question-line strong:first-child,.bgps-standardized-docx.bgps-layout-compact .question-line b:first-child,.bgps-standardized-docx.bgps-layout-compact .question-line span:first-child{font-size:9.8pt!important}',
    '.bgps-standardized-docx.bgps-layout-compact h2.section-heading{margin:4px 0 2px!important;padding:2px 5px!important}',
    '.bgps-standardized-docx.bgps-layout-compact h3,.bgps-standardized-docx.bgps-layout-compact h4{margin:3px 0 1px!important}',
    '.bgps-standardized-docx.bgps-layout-compact .paper-instructions{padding:3px 7px!important;margin-bottom:4px!important;line-height:1.16!important}',
    '.bgps-standardized-docx.bgps-layout-compact ol,.bgps-standardized-docx.bgps-layout-compact ul{margin-top:1px!important;margin-bottom:2px!important}',
    '.bgps-standardized-docx.bgps-layout-compact li{margin-top:0!important;margin-bottom:0!important;line-height:1.18!important}',
    '.bgps-standardized-docx.bgps-layout-compact table{margin:2px 0!important}',
    '.bgps-standardized-docx.bgps-layout-compact td,.bgps-standardized-docx.bgps-layout-compact th{padding:2px 3px!important;line-height:1.12!important}',
    '.bgps-standardized-docx.bgps-layout-compact .diagram-box.has-image:not(.bgps-img-free){max-height:52mm!important;margin-top:.7mm!important;margin-bottom:1mm!important}',
    '.bgps-standardized-docx.bgps-layout-compact .diagram-box.has-image:not(.bgps-img-free)>img{max-height:50mm!important}',
    '.bgps-standardized-docx.bgps-layout-compact .bgps-image-row{gap:1.2mm!important;margin:1mm 0 1.5mm!important}',
    '.mark-token{float:right;font-weight:900;margin-left:6px}',
    '.or-line{text-align:center;font-weight:900;margin:4px 0;break-inside:avoid}',
    '.content table{clear:both;width:100%;border-collapse:collapse;margin:4px 0;break-inside:avoid;page-break-inside:avoid}',
    '.content td,.content th{border:1px solid #333;padding:3px 4px;color:#111;background:#fff;font-size:9.5pt;line-height:1.2}',
    '.content .diagram-box.has-image{box-sizing:border-box;width:var(--bgps-image-width,55%);max-width:100%!important;min-width:20%;height:auto;padding:1mm!important;border:0!important;background:#fff!important;text-align:center;break-inside:avoid!important;page-break-inside:avoid!important}',
    '.content .diagram-box.has-image>img,.content img.diagram-image{display:block!important;width:100%!important;height:auto!important;max-width:100%!important;max-height:230mm!important;margin:auto!important;object-fit:contain!important}',
    '.content .diagram-box.has-image>img{transform-origin:center center!important}',
    '.content .diagram-box.bgps-img-rotate-90>img{transform:rotate(90deg)!important}',
    '.content .diagram-box.bgps-img-rotate-180>img{transform:rotate(180deg)!important}',
    '.content .diagram-box.bgps-img-rotate-270>img{transform:rotate(270deg)!important}',
    '.content .diagram-box.bgps-img-center{display:block;float:none;clear:both;margin:2mm auto 2.6mm!important}',
    '.content .diagram-box.bgps-img-center.bgps-img-compact{display:inline-flex!important;float:none!important;clear:none!important;vertical-align:top!important;align-items:center!important;justify-content:center!important;max-width:31%!important;height:30mm!important;max-height:30mm!important;margin:1mm .8% 2mm!important;border:.25mm solid #777!important}',
    '.content .diagram-box.bgps-img-center.bgps-img-compact>img{max-height:28mm!important}',
    '.content .diagram-box.bgps-img-left{display:block;float:left;clear:none;max-width:48%!important;margin:1mm 3mm 2mm 0!important}',
    '.content .diagram-box.bgps-img-right{display:block;float:right;clear:none;max-width:48%!important;margin:1mm 0 2mm 3mm!important}',
    '.content .diagram-box.bgps-img-inline{display:inline-block!important;float:none!important;clear:none!important;vertical-align:middle!important;max-width:80%!important;margin:0 2mm 1mm!important}',
    '.content .diagram-box.bgps-img-floating{position:static!important;display:block!important;float:right!important;clear:none!important;max-width:48%!important;margin:1mm 0 2mm 3mm!important}',
    '.content .bgps-free-stage{position:relative!important;display:block!important;width:100%!important;height:var(--bgps-free-print-height,24px)!important;min-height:0!important;margin:0!important;padding:0!important;border:0!important;clear:both!important;overflow:visible!important;break-inside:avoid!important;page-break-inside:avoid!important}',
    '.content .bgps-free-stage>.diagram-box.bgps-img-free,.content>.diagram-box.bgps-img-free{position:absolute!important;left:var(--bgps-free-x,0px)!important;top:var(--bgps-free-y,0px)!important;display:block!important;float:none!important;clear:none!important;margin:0!important;transform:none!important;z-index:4}',
    '.content .diagram-caption{font-size:7.8pt;line-height:1.1;margin-top:.5mm;text-align:center;font-style:italic}',
    '.content .bgps-font-1,.content .bgps-font-2{font-size:9pt}.content .bgps-font-3{font-size:10.5pt}.content .bgps-font-4{font-size:12pt}.content .bgps-font-5,.content .bgps-font-6,.content .bgps-font-7{font-size:14pt}',
    '.content .bgps-fraction{display:inline-flex;flex-direction:column;vertical-align:middle;text-align:center;line-height:1.05;margin:0 .12em}.content .bgps-fraction>span:first-child{border-bottom:1px solid currentColor}',
    '.content sup,.content sub{font-size:.75em;line-height:0}',
    '.content ol.bgps-subparts-alpha,.content ol.bgps-subparts-roman{list-style:none;counter-reset:bgps-subpart;margin:4px 0 6px 28px;padding:0}',
    '.content ol.bgps-subparts-alpha>li,.content ol.bgps-subparts-roman>li{counter-increment:bgps-subpart;position:relative;padding-left:28px;margin:3px 0}',
    '.content ol.bgps-subparts-alpha>li::before,.content ol.bgps-subparts-roman>li::before{position:absolute;left:0;font-weight:700}',
    '.content ol.bgps-subparts-alpha>li::before{content:"(" counter(bgps-subpart,lower-alpha) ")"}',
    '.content ol.bgps-subparts-roman>li::before{content:"(" counter(bgps-subpart,lower-roman) ")"}',
    '.content .bgps-image-row{clear:both;display:grid!important;grid-template-columns:repeat(var(--cols,3),minmax(0,1fr))!important;gap:2mm;width:100%;margin:1.5mm 0 2.5mm;break-inside:avoid}',
    '.content .bgps-image-row[data-cols="2"]{--cols:2;--h:38mm}',
    '.content .bgps-image-row[data-cols="3"]{--cols:3;--h:31mm}',
    '.content .bgps-image-row[data-cols="4"]{--cols:4;--h:26mm}',
    '.content .bgps-image-row[data-cols="5"]{--cols:5;--h:23mm}',
    '.content .bgps-image-row>.diagram-box{float:none!important;clear:none!important;width:100%!important;max-width:none!important;height:var(--h,31mm)!important;max-height:var(--h,31mm)!important;margin:0!important;padding:.8mm!important;border:.25mm solid #777!important}',
    '.content .bgps-image-row>.diagram-box>img{max-height:calc(var(--h,31mm) - 2mm)!important}',
    '.page-break{clear:both;page-break-after:always;height:0;margin:0;border:0}',
    '.footer{display:none!important}',
    '.no-print{display:none!important}',
    '.bgps-v8-move-badge,.bgps-v8-drop-marker,.bgps-image-resize-handle,.bgps-image-drag-handle,.bgps-v10-resize-handle,[data-bgps-transient]{display:none!important}',
    '@media print{html,body,.paper,.paper *{color:#000!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}.header,.meta,.paper-instructions,.content h2.section-heading,.content table,.content td,.content th,.mark-token{border-color:#000!important}.meta-value{border-bottom-color:#000!important}.no-print{display:none}.paper{width:auto!important;max-width:none!important;margin:0!important}.diagram-box.has-image{break-inside:avoid!important;page-break-inside:avoid!important}}',
    '@media(max-width:600px){.paper{width:100%;padding:0 4px}.meta{grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:4px 8px;font-size:8.8pt}.meta-value{min-width:0;flex:1}.meta>div:nth-child(even){justify-content:flex-end;text-align:right}}'
  ].join('');

  return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + htmlEscape_(paperTitle) + '</title><style>' + css + '</style></head><body><div class="no-print"><button onclick="window.print()" style="padding:9px 16px;font-weight:700">Print / Save PDF</button></div><main class="paper"><div class="header"><h1>BG PUBLIC SCHOOL</h1><div class="exam">' + htmlEscape_(paper.exam || 'TERM / EXAM') + '</div><div class="session">Academic Session: ' + htmlEscape_(academicSessionLabel_(paper.examDate)) + '</div></div><div class="meta"><div><span class="meta-label">Class:</span><span class="meta-value">' + htmlEscape_(paper.className) + '</span></div><div><span class="meta-label">Subject:</span><span class="meta-value">' + htmlEscape_(paper.subject) + '</span></div><div><span class="meta-label">Time Allowed:</span><span class="meta-value">' + htmlEscape_(paper.timeAllowed || inferPaperTime_(paper.maxMarks)) + '</span></div><div><span class="meta-label">Maximum Marks:</span><span class="meta-value">' + htmlEscape_(paper.maxMarks) + '</span></div><div><span class="meta-label">Reading Time:</span><span class="meta-value">' + htmlEscape_(readingTime) + '</span></div><div><span class="meta-label">Date:</span><span class="meta-value">' + htmlEscape_(paper.examDate || '____________') + '</span></div></div>' + instructionsHtml + '<div class="content">' + safeBody + '</div><div class="footer"><span>Teacher: ' + htmlEscape_(teacherId || '') + '</span><span>Version ' + htmlEscape_(version || 1) + '</span></div></main></body></html>';
}

function questionsToEditorHtml_(questions, instructions) {
  const safeInstructions = cleanText_(instructions || '');
  const intro = safeInstructions
    ? '<div class="paper-instructions"><h3>General Instructions</h3><ol>' + safeInstructions.split(/\n+/).map(function(line) { return cleanText_(line); }).filter(String).map(function(line) { return '<li>' + htmlEscape_(line) + '</li>'; }).join('') + '</ol></div>'
    : '';
  const body = (questions || []).map(function(question, index) {
    const orText = cleanText_(question.orText);
    return '<p class="question-line"><strong>Q' + (index + 1) + '.</strong> ' + nl2br_(htmlEscape_(question.text || '')) + ' <span class="mark-token">[' + htmlEscape_(question.marks || '') + ']</span></p>' + (orText ? '<p class="or-line">OR</p><p class="question-line">' + nl2br_(htmlEscape_(orText)) + '</p>' : '');
  }).join('');
  return intro + body;
}

function stripUnsafeExternalImages_(html) {
  return String(html || '').replace(/<img\b[^>]*>/gi, function(tag) {
    const sourceMatch = String(tag).match(/\bsrc\s*=\s*(['"])([\s\S]*?)\1/i);
    const source = sourceMatch ? String(sourceMatch[2] || '').trim() : '';
    if (/^data:image\/(?:png|jpeg|jpg|webp);base64,/i.test(source)) return tag;
    const altMatch = String(tag).match(/\balt\s*=\s*(['"])([\s\S]*?)\1/i);
    const alt = cleanText_(altMatch ? altMatch[2] : '').slice(0, 120);
    return '<span class="bgps-paste-image-warning">[Linked image removed' + (alt ? ': ' + htmlEscape_(alt) : '') + ' — insert it using the portal Image button]</span>';
  });
}

function sanitizeHtmlForStorage_(html) {
  let value = stripUnsafeExternalImages_(html);
  validateEmbeddedImages_(value);
  value = value.replace(/<!--[\s\S]*?-->/g, '');
  value = value.replace(/<script[\s\S]*?<\/script>/gi, '');
  value = value.replace(/<style[\s\S]*?<\/style>/gi, '');
  value = value.replace(/<iframe[\s\S]*?<\/iframe>/gi, '');
  value = value.replace(/<object[\s\S]*?<\/object>/gi, '');
  value = value.replace(/<embed[\s\S]*?>/gi, '');
  value = value.replace(/<(?:link|meta|base|form|input|button|textarea|select|option|svg|math)\b[^>]*>/gi, '');
  value = value.replace(/<\/(?:form|button|textarea|select|option|svg|math)>/gi, '');
  value = value.replace(/<(span|div)\b[^>]*class\s*=\s*(['"])[^'"]*(?:bgps-v8-move-badge|bgps-v8-drop-marker|bgps-image-resize-handle|bgps-image-drag-handle)[^'"]*\2[^>]*>[\s\S]*?<\/\1>/gi, '');
  value = value.replace(/\son[a-z]+\s*=\s*(['"]).*?\1/gi, '');
  value = value.replace(/\son[a-z]+\s*=\s*[^\s>]+/gi, '');
  value = value.replace(/\s(?:contenteditable|draggable|tabindex|data-bgps-transient)\s*=\s*(['"])[\s\S]*?\1/gi, '');
  value = value.replace(/\s(?:contenteditable|draggable|tabindex|data-bgps-transient)\s*=\s*[^\s>]+/gi, '');
  value = value.replace(/(href|src)\s*=\s*(['"])\s*javascript:[\s\S]*?\2/gi, '$1="#"');
  if (byteLength_(value) > DRAFT_MAX_PAYLOAD_BYTES) {
    throw new Error('Question paper HTML is too large. Compress images or split the paper.');
  }
  return value;
}

function normalizePaperContentHtml_(html) {
  if (looksLikePortalApplicationSource_(html)) {
    throw new Error('Portal source code was detected instead of question-paper content. The unsafe copy was not saved.');
  }
  let value = sanitizeHtmlForStorage_(html);
  value = value.replace(/\sstyle\s*=\s*(['"])([\s\S]*?)\1/gi, function(all, quote, declarations) {
    const kept = String(declarations || '').split(';').map(function(item) {
      const parts = item.split(':');
      if (parts.length < 2) return '';
      const property = cleanText_(parts.shift()).toLowerCase();
      const rawValue = cleanText_(parts.join(':'));
      const lowerValue = rawValue.toLowerCase();
      if (property === 'text-align' && /^(left|right|center|justify)$/.test(lowerValue)) return property + ':' + lowerValue;
      if (property === 'font-weight' && /^(bold|[6-9]00)$/.test(lowerValue)) return 'font-weight:700';
      if (property === 'font-style' && lowerValue === 'italic') return 'font-style:italic';
      if (property === 'text-decoration' && lowerValue.indexOf('underline') !== -1) return 'text-decoration:underline';
      if (property === 'vertical-align' && /^(super|sub)$/.test(lowerValue)) return property + ':' + lowerValue;
      if (property === 'white-space' && /^(pre-wrap|pre-line)$/.test(lowerValue)) return property + ':' + lowerValue;
      if (property === 'tab-size' && /^(?:[2-9]|1[0-2])$/.test(lowerValue)) return property + ':' + lowerValue;
      if (property === '--bgps-image-width' && /^\d+(?:\.\d+)?%$/.test(lowerValue)) return property + ':' + lowerValue;
      if ((property === '--bgps-free-x' || property === '--bgps-free-y') && /^-?\d+(?:\.\d+)?px$/.test(lowerValue)) return property + ':' + lowerValue;
      if (property === '--bgps-free-stage-height' && /^\d+(?:\.\d+)?px$/.test(lowerValue)) return property + ':' + lowerValue;
      if (property === '--bgps-free-print-height' && /^\d+(?:\.\d+)?px$/.test(lowerValue)) return property + ':' + lowerValue;
      if (property === 'height' && /^var\(--bgps-free-stage-height\)$/i.test(rawValue)) return 'height:var(--bgps-free-stage-height)';
      if (property === 'position' && /^(absolute|relative)$/.test(lowerValue)) return 'position:' + lowerValue;
      if ((property === 'left' || property === 'top') && /^var\(--bgps-free-[xy]\)$/i.test(rawValue)) return property + ':' + rawValue;
      if (property === 'transform' && /^translate3d\(var\(--bgps-free-x\),\s*var\(--bgps-free-y\),\s*0\)$/i.test(rawValue)) return 'transform:translate3d(var(--bgps-free-x),var(--bgps-free-y),0)';
      if (property === 'transform' && lowerValue === 'none') return 'transform:none';
      if (property === 'margin' && /^0(?:px)?$/.test(lowerValue)) return 'margin:0';
      if (property === 'width' && /^\d+(?:\.\d+)?%$/.test(lowerValue)) return property + ':' + lowerValue;
      return '';
    }).filter(Boolean);
    return kept.length ? ' style="' + kept.join(';') + '"' : '';
  });
  value = value.replace(/<font\b[^>]*\bsize\s*=\s*(['"]?)([1-7])\1[^>]*>/gi, '<span class="bgps-font-$2">');
  value = value.replace(/<\/font>/gi, '</span>');
  value = value.replace(/<(p|div)\b[^>]*>\s*(?:<br\s*\/?>|&nbsp;|\s)*<\/\1>\s*(?=<(?:p|div)\b[^>]*>\s*(?:<br\s*\/?>|&nbsp;|\s)*<\/\1>)/gi, '');
  value = value.replace(/<img\b([^>]*?)>/gi, function(all, attrs) {
    return '<img' + attrs.replace(/\s(?:width|height)\s*=\s*(['"]?)[^\s>]+\1/gi, '') + '>';
  });
  value = value.replace(/<div\b([^>]*\bclass\s*=\s*(['"])[^'"]*\bbgps-free-stage\b[^'"]*\2[^>]*)>/gi, function(all, attrs) {
    const styleMatch = String(attrs || '').match(/\bstyle\s*=\s*(['"])([\s\S]*?)\1/i);
    const styleText = styleMatch ? styleMatch[2] : '';
    const printHeightMatch = styleText.match(/--bgps-free-print-height\s*:\s*(\d+(?:\.\d+)?)px/i);
    const printHeight = Math.max(24, Math.min(5000, Number((printHeightMatch || [])[1] || 24)));
    const canonicalStyle = '--bgps-free-stage-height:0px;--bgps-free-print-height:' + printHeight + 'px;height:0;position:relative';
    let nextAttrs = String(attrs || '');
    if (styleMatch) nextAttrs = nextAttrs.replace(/\bstyle\s*=\s*(['"])[\s\S]*?\1/i, 'style="' + canonicalStyle + '"');
    else nextAttrs += ' style="' + canonicalStyle + '"';
    return '<div' + nextAttrs + '>';
  });
  value = value.replace(/<div\b([^>]*\bclass\s*=\s*(['"])[^'"]*\bdiagram-box\b[^'"]*\bhas-image\b[^'"]*\2[^>]*)>/gi, function(all, attrs) {
    const styleMatch = String(attrs || '').match(/\bstyle\s*=\s*(['"])([\s\S]*?)\1/i);
    const styleText = styleMatch ? styleMatch[2] : '';
    const variableMatch = styleText.match(/--bgps-image-width\s*:\s*(\d+(?:\.\d+)?)%/i);
    const widthMatch = styleText.match(/(?:^|;)\s*width\s*:\s*(\d+(?:\.\d+)?)%/i);
    const raw = Number((variableMatch || widthMatch || [])[1] || 55);
    const width = Math.max(20, Math.min(100, Number.isFinite(raw) ? raw : 55));
    const freeXMatch = styleText.match(/--bgps-free-x\s*:\s*(-?\d+(?:\.\d+)?)px/i);
    const freeYMatch = styleText.match(/--bgps-free-y\s*:\s*(-?\d+(?:\.\d+)?)px/i);
    const isFree = /\bbgps-img-free\b/i.test(String(attrs || ''));
    let canonicalStyle = '--bgps-image-width:' + width + '%;width:' + width + '%';
    if (isFree) {
      const freeX = Math.max(-1200, Math.min(1200, Number((freeXMatch || [])[1] || 0)));
      const freeY = Math.max(-2400, Math.min(2400, Number((freeYMatch || [])[1] || 0)));
      canonicalStyle += ';--bgps-free-x:' + freeX + 'px;--bgps-free-y:' + freeY + 'px;position:absolute;left:var(--bgps-free-x);top:var(--bgps-free-y);transform:none;margin:0';
    }
    let nextAttrs = String(attrs || '');
    if (styleMatch) nextAttrs = nextAttrs.replace(/\bstyle\s*=\s*(['"])[\s\S]*?\1/i, 'style="' + canonicalStyle + '"');
    else nextAttrs += ' style="' + canonicalStyle + '"';
    return '<div' + nextAttrs + '>';
  });
  validateEmbeddedImages_(value);
  return value.trim();
}

function htmlToPlainText_(html) {
  return cleanText_(String(html || '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(?:p|div|li|tr|h[1-6])>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&#0*39;|&apos;/gi, "'")
    .replace(/&quot;/gi, '"')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n\s*\n+/g, '\n\n'));
}

function inferReadingTime_(className, maxMarks) {
  const match = String(className || '').match(/Class\s+(\d+)/i);
  const classNo = match ? Number(match[1]) : 0;
  return classNo >= 9 || Number(maxMarks) >= 70 ? 'Additional 15 Minutes' : 'Additional 10 Minutes';
}

function academicSessionLabel_(examDate) {
  const parsed = examDate ? new Date(examDate) : new Date();
  const date = Number.isNaN(parsed.getTime()) ? new Date() : parsed;
  const startYear = date.getMonth() >= 3 ? date.getFullYear() : date.getFullYear() - 1;
  return startYear + '–' + String((startYear + 1) % 100).padStart(2, '0');
}

function inferPaperTime_(maxMarks) {
  const marks = Number(maxMarks) || 0;
  if (marks <= 20) return '45 Minutes';
  if (marks <= 30) return '1 Hour';
  if (marks <= 40) return '1½ Hours';
  if (marks <= 50) return '2 Hours';
  if (marks <= 60) return '2½ Hours';
  return '3 Hours';
}

function isPrePrimaryClass_(className) {
  const normalized = cleanText_(className).toUpperCase().replace(/[._-]+/g, ' ').replace(/\s+/g, ' ');
  return ['PG', 'PLAYGROUP', 'PLAY GROUP', 'PRE NURSERY', 'NURSERY', 'LKG', 'UKG'].indexOf(normalized) !== -1;
}

function isDocxBasedDraft_(draft) {
  const sourceType = cleanText_(draft && draft.sourceType).toLowerCase();
  const fileName = cleanText_(draft && draft.originalFileName).toLowerCase();
  return sourceType.indexOf('docx') !== -1
    || ((sourceType === 'upload' || sourceType === 'import') && fileName.slice(-5) === '.docx');
}

function normalizePaperChapters_(className, chapters) {
  const cleaned = cleanText_(chapters);
  if (cleaned) return cleaned;
  return isPrePrimaryClass_(className) ? PRE_PRIMARY_CHAPTER_VALUE : '';
}

function validateUploadedFileSignature_(bytes, extension) {
  const values = (bytes || []).slice(0, 32).map(function(value) { return Number(value) & 255; });
  if (extension === 'pdf') {
    const signature = [37, 80, 68, 70, 45]; // %PDF-
    let found = false;
    for (let start = 0; start <= Math.max(0, values.length - signature.length); start++) {
      if (signature.every(function(value, index) { return values[start + index] === value; })) { found = true; break; }
    }
    if (!found) throw new Error('The selected file does not contain a valid PDF signature.');
    return;
  }
  if (extension === 'docx') {
    const zip = values[0] === 80 && values[1] === 75 &&
      ((values[2] === 3 && values[3] === 4) || (values[2] === 5 && values[3] === 6) || (values[2] === 7 && values[3] === 8));
    if (!zip) throw new Error('The selected file is not a valid DOCX/ZIP package.');
    return;
  }
  throw new Error('Unsupported upload format.');
}

function validateDocxPackageIntegrity_(bytes) {
  const values = (bytes || []).map(function(value) { return Number(value) & 255; });
  const containsAscii = function(text) {
    const needle = String(text || '').split('').map(function(character) { return character.charCodeAt(0); });
    for (let start = 0; start <= values.length - needle.length; start++) {
      let matches = true;
      for (let index = 0; index < needle.length; index++) {
        if (values[start + index] !== needle[index]) { matches = false; break; }
      }
      if (matches) return true;
    }
    return false;
  };
  let hasCentralDirectoryEnd = false;
  const searchStart = Math.max(0, values.length - 65557);
  for (let index = values.length - 4; index >= searchStart; index--) {
    if (values[index] === 80 && values[index + 1] === 75 && values[index + 2] === 5 && values[index + 3] === 6) {
      hasCentralDirectoryEnd = true;
      break;
    }
  }
  if (!hasCentralDirectoryEnd || !containsAscii('[Content_Types].xml') || !containsAscii('word/document.xml')) {
    throw new Error('This DOCX file is incomplete or damaged and does not contain the full Word document package. Open the original in Microsoft Word, choose File > Save As > Word Document (.docx), then upload the newly saved file.');
  }
}

function enforceMarksClassAccess_(user, className) {
  if (user.paperOnly) throw new Error('T-16 is authorised for question-paper submission only.');
  if (!user.isAdmin && cleanText_(className) !== user.assignedClass) {
    throw new Error('You can enter marks only for ' + user.assignedClass + '.');
  }
}

function enforcePaperClassAccess_(user, className) {
  if (user.isAdmin) return; // Admin can use any class
  const validClasses = ALL_CLASSES;
  if (!validClasses.includes(cleanText_(className))) {
    throw new Error('Invalid class name.');
  }
  // All non-admin teachers can create/upload papers for any class
}

function createDraftId_() {
  return 'draft-' + Utilities.getUuid().slice(0, 12);
}

function ensureMasterSheet_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(MASTER_SHEET_NAME);
  if (!sheet) sheet = spreadsheet.insertSheet(MASTER_SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, MASTER_HEADERS.length).setValues([MASTER_HEADERS]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function ensureQuestionPaperSheet_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(PAPER_SHEET_NAME);
  if (!sheet) sheet = spreadsheet.insertSheet(PAPER_SHEET_NAME);
  sheet.getRange(1, 1, 1, PAPER_HEADERS.length).setValues([PAPER_HEADERS]);
  sheet.setFrozenRows(1);
  if (sheet.getLastRow() <= 1) sheet.autoResizeColumns(1, PAPER_HEADERS.length);
  return sheet;
}

function ensurePaperDraftSheet_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(PAPER_DRAFTS_SHEET_NAME);
  if (!sheet) sheet = spreadsheet.insertSheet(PAPER_DRAFTS_SHEET_NAME);

  migratePaperDraftSheet_(sheet);
  sheet.setFrozenRows(1);
  if (sheet.getLastRow() <= 1) sheet.autoResizeColumns(1, Math.max(sheet.getLastColumn(), PAPER_DRAFTS_HEADERS.length));
  return sheet;
}

function ensurePaperDraftsSheet_() {
  return ensurePaperDraftSheet_();
}

function migratePaperDraftSheet_(sheet) {
  const currentWidth = Math.max(sheet.getLastColumn(), 1);
  const lastRow = sheet.getLastRow();
  const rawHeaders = sheet.getRange(1, 1, 1, currentWidth).getValues()[0];
  const headers = rawHeaders.map(function(value) { return cleanText_(value); });
  if (!headers.filter(Boolean).length) {
    sheet.getRange(1, 1, 1, PAPER_DRAFTS_HEADERS.length).setValues([PAPER_DRAFTS_HEADERS]);
    return PAPER_DRAFTS_HEADERS.slice();
  }

  const rows = lastRow > 1 ? sheet.getRange(2, 1, lastRow - 1, currentWidth).getValues() : [];
  const headerMap = {};
  headers.forEach(function(header, index) {
    if (header && headerMap[header] == null) headerMap[header] = index;
  });

  const nextHeaders = PAPER_DRAFTS_HEADERS.slice();
  const nextSet = new Set(nextHeaders);
  headers.forEach(function(header, index) {
    let name = header;
    if (!name && rows.some(function(row) { return cleanText_(row[index]) !== ''; })) {
      name = 'Legacy Column ' + (index + 1);
    }
    if (name && !nextSet.has(name)) {
      nextHeaders.push(name);
      nextSet.add(name);
    }
  });

  const needsMigration = nextHeaders.length !== headers.length || nextHeaders.some(function(header, index) {
    return headers[index] !== header;
  });
  if (!needsMigration) return headers;

  const migratedRows = rows.map(function(row) {
    return nextHeaders.map(function(header) {
      if (headerMap[header] != null) return row[headerMap[header]];
      return paperDraftDefaultValue_(row, headerMap, header);
    });
  });

  sheet.getRange(1, 1, 1, nextHeaders.length).setValues([nextHeaders]);
  if (migratedRows.length) {
    sheet.getRange(2, 1, migratedRows.length, nextHeaders.length).setValues(migratedRows);
  }
  if (currentWidth > nextHeaders.length) {
    sheet.getRange(1, nextHeaders.length + 1, Math.max(lastRow, 1), currentWidth - nextHeaders.length).clearContent();
  }
  SpreadsheetApp.flush();
  return nextHeaders;
}

function paperDraftLegacyValue_(row, headerMap, header) {
  const index = headerMap[header];
  return index == null ? '' : row[index];
}

function paperDraftDefaultValue_(row, headerMap, header) {
  const className = cleanText_(paperDraftLegacyValue_(row, headerMap, 'Class'));
  const maxMarks = Number(paperDraftLegacyValue_(row, headerMap, 'Max Marks')) || 0;
  const editorHtml = String(paperDraftLegacyValue_(row, headerMap, 'Editor HTML') || '');
  const bodyText = String(paperDraftLegacyValue_(row, headerMap, 'Body Text') || editorHtml.replace(/<[^>]+>/g, ' '));
  if (header === 'Time Allowed') return maxMarks > 0 ? inferPaperTime_(maxMarks) : '';
  if (header === 'Instructions') return '';
  if (header === 'Total Questions') return countQuestionBlocks_(editorHtml, bodyText);
  if (header === 'Draft JSON') {
    const content = {
      draftId: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Draft ID')),
      teacherId: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Teacher ID')),
      title: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Title')),
      className: className,
      subject: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Subject')),
      exam: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Exam / Term')),
      chapters: normalizePaperChapters_(className, paperDraftLegacyValue_(row, headerMap, 'Chapters')),
      maxMarks: maxMarks,
      examDate: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Exam Date')),
      note: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Teacher Note')),
      timeAllowed: maxMarks > 0 ? inferPaperTime_(maxMarks) : '',
      instructions: '',
      languageMode: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Language Mode')) || 'english',
      editorHtml: editorHtml,
      bodyText: bodyText,
      detectedMarks: Number(paperDraftLegacyValue_(row, headerMap, 'Detected Marks')) || 0,
      totalQuestions: countQuestionBlocks_(editorHtml, bodyText),
      status: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Status')) || 'Draft',
      sourceType: cleanText_(paperDraftLegacyValue_(row, headerMap, 'Source Type')) || 'Manual'
    };
    const json = JSON.stringify(content);
    return byteLength_(json) <= DRAFT_INLINE_JSON_MAX_BYTES ? json : '';
  }
  if (header === 'Content Drive File ID') return '';
  return '';
}

function ensureHeaders_(sheet, requiredHeaders) {
  const currentLastColumn = Math.max(sheet.getLastColumn(), 1);
  let headers = sheet.getRange(1, 1, 1, currentLastColumn).getValues()[0].map(function(value) {
    return cleanText_(value);
  });
  if (!headers.filter(Boolean).length) {
    sheet.getRange(1, 1, 1, requiredHeaders.length).setValues([requiredHeaders]);
    return requiredHeaders.slice();
  }

  const headerSet = new Set(headers.filter(Boolean));
  requiredHeaders.forEach(function(header) {
    if (!headerSet.has(header)) {
      headers.push(header);
      sheet.getRange(1, headers.length).setValue(header);
      headerSet.add(header);
    }
  });
  return headers;
}

function getHeaderMap_(sheet, requiredHeaders) {
  ensureHeaders_(sheet, requiredHeaders);
  const width = Math.max(sheet.getLastColumn(), requiredHeaders.length);
  const headers = sheet.getRange(1, 1, 1, width).getValues()[0].map(function(value) {
    return cleanText_(value);
  });
  const map = {};
  headers.forEach(function(header, index) {
    if (header && map[header] == null) map[header] = index;
  });
  return map;
}

function rowValue_(row, headerMap, header) {
  const index = headerMap[header];
  return index == null ? '' : row[index];
}

function setRowValue_(row, headerMap, header, value) {
  const index = headerMap[header];
  if (index != null) row[index] = value;
}

function parseJsonObject_(value) {
  const raw = String(value || '').trim();
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (ignored) {
    return {};
  }
}

function byteLength_(value) {
  return Utilities.newBlob(String(value || ''), 'text/plain').getBytes().length;
}

function validateEmbeddedImages_(html) {
  const value = String(html || '');
  const imageSrcRegex = /<img\b[^>]*\bsrc\s*=\s*(['"])([\s\S]*?)\1/gi;
  let sourceMatch;
  while ((sourceMatch = imageSrcRegex.exec(value))) {
    if (!/^data:image\/(?:png|jpeg|jpg|webp);base64,/i.test(String(sourceMatch[2] || '').trim())) {
      throw new Error('Paper images must be embedded PNG, JPEG or WebP data. Re-paste or insert the image through the portal.');
    }
  }
  const dataUrlRegex = /<img\b[^>]*\bsrc\s*=\s*(['"])(data:image\/([^;,'"]+);base64,([\s\S]*?))\1/gi;
  let match;
  while ((match = dataUrlRegex.exec(value))) {
    const mime = String(match[3] || '').toLowerCase();
    if (['png', 'jpeg', 'jpg', 'webp'].indexOf(mime) === -1) {
      throw new Error('Only PNG, JPEG and WebP image data URLs are allowed in paper content.');
    }
    const approxBytes = Math.ceil(String(match[4] || '').replace(/\s/g, '').length * 0.75);
    if (approxBytes > DRAFT_MAX_EMBEDDED_IMAGE_BYTES) {
      throw new Error('One embedded image is too large. Compress it below 1.5 MB before saving.');
    }
  }
  if (/data:image\/svg\+xml/i.test(value) || /<svg[\s>]/i.test(value)) {
    throw new Error('SVG content is not allowed in question-paper drafts.');
  }
  if (/data:image\/(?!png|jpeg|jpg|webp)/i.test(value)) {
    throw new Error('Only safe raster image data URLs are allowed.');
  }
}

function countQuestionBlocks_(editorHtml, bodyText) {
  const html = String(editorHtml || '');
  const questionLineCount = (html.match(/class\s*=\s*["'][^"']*\bquestion-line\b[^"']*["']/gi) || []).length;
  if (questionLineCount > 0) return questionLineCount;
  const text = cleanText_(bodyText || html.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ');
  const qPrefixCount = (text.match(/\b(?:Q|Question)\s*\.?\s*\d+[.)-]?/gi) || []).length;
  if (qPrefixCount > 0) return qPrefixCount;
  return (text.match(/\[\s*\d+(?:\.\d+)?(?:\s*\+\s*\d+(?:\.\d+)?)*\s*\]/g) || []).length;
}

function detectedMarkTokenValue_(value) {
  const cleaned = String(value || '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/^[\s[(]+|[\s)\]]+$/g, '')
    .replace(/\s*marks?\s*$/i, '')
    .trim();
  if (!/^\d+(?:\.\d+)?(?:\s*\+\s*\d+(?:\.\d+)?)*$/.test(cleaned)) return 0;
  return cleaned.split('+').reduce(function(sum, part) {
    const number = Number(part.trim());
    return sum + (Number.isFinite(number) ? number : 0);
  }, 0);
}

function sumDetectedMarks_(editorHtml) {
  const html = String(editorHtml || '');
  const explicitTokens = [];
  const markTokenRegex = /<([a-z][a-z0-9]*)\b[^>]*class\s*=\s*["'][^"']*\bmark-token\b[^"']*["'][^>]*>([\s\S]*?)<\/\1\s*>/gi;
  let explicitMatch;
  while ((explicitMatch = markTokenRegex.exec(html))) explicitTokens.push(explicitMatch[2]);

  // Keep the backend calculation identical to the Paper Creator: explicit
  // question mark tokens take priority over unrelated bracketed numbers.
  if (explicitTokens.length) {
    return explicitTokens.reduce(function(sum, token) {
      return sum + detectedMarkTokenValue_(token);
    }, 0);
  }

  // Imported/legacy content may only contain visible [5], [5 marks] or [2+3].
  const visibleText = html.replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ');
  const tokens = visibleText.match(/\[\s*\d+(?:\.\d+)?(?:\s*\+\s*\d+(?:\.\d+)?)*\s*(?:marks?)?\s*\]/gi) || [];
  return tokens.reduce(function(sum, token) {
    return sum + detectedMarkTokenValue_(token);
  }, 0);
}

function loadDraftContentFile_(fileId) {
  const id = cleanText_(fileId);
  if (!id) return {};
  const file = DriveApp.getFileById(id);
  if (file.isTrashed()) throw new Error('Draft content file is in Drive Trash.');
  return parseJsonObject_(file.getBlob().getDataAsString('UTF-8'));
}

function bulkDeleteApprovedOriginals_(user) {
  if (!user.isAdmin) throw new Error('Only Admin can delete approved original DOCX files.');

  const sheet = ensureQuestionPaperSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) {
    return { ok: true, eligible: 0, deleted: 0, alreadyRemoved: 0, skipped: 0, failed: 0 };
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  const result = {
    ok: true,
    eligible: 0,
    deleted: 0,
    alreadyRemoved: 0,
    skipped: 0,
    failed: 0,
    failures: []
  };
  const obsoleteContentFiles = [];

  try {
    const rows = sheet.getRange(2, 1, lastRow - 1, PAPER_HEADERS.length).getValues();

    rows.forEach(function(row, index) {
      const sheetRow = index + 2;
      const paperId = cleanText_(row[0]);
      const originalName = cleanText_(row[11]);
      const mimeType = cleanText_(row[12]).toLowerCase();
      const originalFileId = cleanText_(row[14]);
      const status = cleanText_(row[16]);
      const sourceType = cleanText_(row[18]).toLowerCase();
      const finalPdfFileId = cleanText_(row[23]);
      const isDocx = mimeType.indexOf('wordprocessingml.document') !== -1 || fileExtension_(originalName) === 'docx';

      if (status !== 'Approved' || (sourceType !== 'upload' && sourceType !== 'docx upload') || !isDocx) return;

      const content = loadPaperContentRecord_(row[21]);
      if (content.originalDeleted === true) {
        result.alreadyRemoved += 1;
        return;
      }

      result.eligible += 1;

      if (!originalFileId || !finalPdfFileId || originalFileId === finalPdfFileId) {
        result.skipped += 1;
        return;
      }

      try {
        const finalFile = DriveApp.getFileById(finalPdfFileId);
        if (finalFile.isTrashed() || !finalFile.getBlob().getBytes().length) {
          result.skipped += 1;
          return;
        }

        const originalFile = DriveApp.getFileById(originalFileId);
        const wasAlreadyTrashed = originalFile.isTrashed();
        if (!wasAlreadyTrashed) originalFile.setTrashed(true);

        const nextContent = Object.assign({}, content, {
          originalDeleted: true,
          originalDeletedAt: new Date().toISOString(),
          originalDeletedBy: user.id,
          originalFilePreserved: false,
          bulkOriginalCleanup: true
        });
        const storage = preparePaperContentStorage_(nextContent, row[21]);
        sheet.getRange(sheetRow, 3).setValue(new Date());
        sheet.getRange(sheetRow, 22).setValue(storage.cellJson);
        if (storage.obsoleteFileId && storage.obsoleteFileId !== storage.fileId) {
          obsoleteContentFiles.push(storage.obsoleteFileId);
        }

        if (wasAlreadyTrashed) result.alreadyRemoved += 1;
        else result.deleted += 1;
      } catch (error) {
        result.failed += 1;
        if (result.failures.length < 10) {
          result.failures.push({
            paperId: paperId,
            fileName: originalName,
            error: safeErrorMessage_(error).slice(0, 180)
          });
        }
      }
    });

    SpreadsheetApp.flush();
    obsoleteContentFiles.forEach(trashFileQuietly_);

    if (result.deleted || result.alreadyRemoved) {
      try {
        appendPrincipalActivity_(user, 'Approved Original DOCX Cleanup', {
          paperId: 'BULK',
          message: result.deleted + ' approved original DOCX file(s) moved to Drive Trash; '
            + result.alreadyRemoved + ' already removed; '
            + result.skipped + ' skipped; '
            + result.failed + ' failed.'
        });
      } catch (activityError) {
        console.warn('Bulk original cleanup completed, but the activity log could not be updated.', safeErrorMessage_(activityError));
      }
    }

    return result;
  } finally {
    lock.releaseLock();
  }
}

function trashFileQuietly_(fileOrId) {
  try {
    if (!fileOrId) return;
    const file = typeof fileOrId === 'string' ? DriveApp.getFileById(fileOrId) : fileOrId;
    if (file && !file.isTrashed()) file.setTrashed(true);
  } catch (cleanupError) {
    console.error(cleanupError);
  }
}

function prepareDraftStorage_(content, previousFileId) {
  validateEmbeddedImages_(content.editorHtml || '');
  const payload = JSON.stringify(content);
  const payloadBytes = byteLength_(payload);
  if (payloadBytes > DRAFT_MAX_PAYLOAD_BYTES) {
    throw new Error('Draft content is too large to save. Compress images or split the paper.');
  }

  const htmlBytes = byteLength_(content.editorHtml || '');
  if (payloadBytes <= DRAFT_INLINE_JSON_MAX_BYTES && htmlBytes <= DRAFT_INLINE_HTML_MAX_BYTES) {
    return {
      draftJson: payload,
      editorHtml: content.editorHtml || '',
      bodyText: content.bodyText || '',
      fileId: '',
      createdFile: null,
      obsoleteFileId: cleanText_(previousFileId)
    };
  }

  const storedName = 'draft-content-' + cleanText_(content.draftId || Utilities.getUuid()) + '.json';
  const file = getQuestionPaperFolder_().createFile(Utilities.newBlob(payload, 'application/json', storedName));
  const compact = Object.assign({}, content, {
    editorHtml: '',
    bodyText: '',
    hasDriveContent: true,
    contentDriveFileId: file.getId()
  });
  return {
    draftJson: JSON.stringify(compact),
    editorHtml: '',
    bodyText: '',
    fileId: file.getId(),
    createdFile: file,
    obsoleteFileId: cleanText_(previousFileId)
  };
}

function draftFromRow_(row, headerMap, loadContent) {
  const fileId = cleanText_(rowValue_(row, headerMap, 'Content Drive File ID'));
  let driveContent = {};
  if (fileId && loadContent !== false) driveContent = loadDraftContentFile_(fileId);
  const jsonContent = parseJsonObject_(rowValue_(row, headerMap, 'Draft JSON'));
  const merged = Object.assign({}, jsonContent, driveContent);

  const draft = {
    draftId: cleanText_(rowValue_(row, headerMap, 'Draft ID')),
    paperId: cleanText_(rowValue_(row, headerMap, 'Draft ID')),
    createdAt: isoDate_(rowValue_(row, headerMap, 'Created At')),
    updatedAt: isoDate_(rowValue_(row, headerMap, 'Updated At')),
    teacherId: cleanText_(rowValue_(row, headerMap, 'Teacher ID')),
    title: cleanText_(rowValue_(row, headerMap, 'Title')) || cleanText_(merged.title),
    className: cleanText_(rowValue_(row, headerMap, 'Class')) || cleanText_(merged.className),
    subject: cleanText_(rowValue_(row, headerMap, 'Subject')) || cleanText_(merged.subject),
    exam: cleanText_(rowValue_(row, headerMap, 'Exam / Term')) || cleanText_(merged.exam),
    chapters: cleanText_(rowValue_(row, headerMap, 'Chapters')) || cleanText_(merged.chapters),
    maxMarks: Number(rowValue_(row, headerMap, 'Max Marks')) || Number(merged.maxMarks) || 0,
    examDate: cleanText_(rowValue_(row, headerMap, 'Exam Date')) || cleanText_(merged.examDate),
    note: cleanText_(rowValue_(row, headerMap, 'Teacher Note')) || cleanText_(merged.note),
    timeAllowed: cleanText_(rowValue_(row, headerMap, 'Time Allowed')) || cleanText_(merged.timeAllowed),
    instructions: cleanText_(rowValue_(row, headerMap, 'Instructions')) || cleanText_(merged.instructions),
    languageMode: cleanText_(rowValue_(row, headerMap, 'Language Mode')) || cleanText_(merged.languageMode || 'english'),
    editorHtml: String(merged.editorHtml || rowValue_(row, headerMap, 'Editor HTML') || ''),
    bodyText: String(merged.bodyText || rowValue_(row, headerMap, 'Body Text') || ''),
    detectedMarks: Number(rowValue_(row, headerMap, 'Detected Marks')) || Number(merged.detectedMarks) || 0,
    totalQuestions: Number(rowValue_(row, headerMap, 'Total Questions')) || Number(merged.totalQuestions) || 0,
    status: cleanText_(rowValue_(row, headerMap, 'Status')) || cleanText_(merged.status || 'Draft'),
    sourceType: cleanText_(rowValue_(row, headerMap, 'Source Type')) || cleanText_(merged.sourceType || 'Manual'),
    draftJson: rowValue_(row, headerMap, 'Draft JSON') || '',
    contentDriveFileId: fileId,
    originalPaperId: cleanText_(merged.originalPaperId || merged.revisionOriginalId || ''),
    parentPaperId: cleanText_(merged.parentPaperId || merged.revisionParentId || ''),
    previousVersion: Number(merged.previousVersion || 0),
    submittedPaperId: cleanText_(merged.submittedPaperId || ''),
    originalFileName: cleanText_(merged.originalFileName || ''),
    sourceFileId: cleanText_(merged.sourceFileId || ''),
    importWarnings: Array.isArray(merged.importWarnings) ? merged.importWarnings : [],
    requestId: normalizeRequestToken_(merged.requestId || merged.submissionToken || '')
  };
  if (!draft.timeAllowed && draft.maxMarks) draft.timeAllowed = '';
  if (!draft.totalQuestions && draft.editorHtml) {
    draft.totalQuestions = countQuestionBlocks_(draft.editorHtml, draft.bodyText);
  }
  return draft;
}

function getQuestionPaperFolder_() {
  const properties = PropertiesService.getScriptProperties();
  let savedId = properties.getProperty(PAPER_FOLDER_PROPERTY);
  if (!savedId) {
    savedId = properties.getProperty(LEGACY_PAPER_FOLDER_PROPERTY);
    if (savedId) properties.setProperty(PAPER_FOLDER_PROPERTY, savedId);
  }
  if (savedId) {
    try {
      const savedFolder = DriveApp.getFolderById(savedId);
      if (!savedFolder.isTrashed()) return savedFolder;
    } catch (ignored) {
      properties.deleteProperty(PAPER_FOLDER_PROPERTY);
    }
  }
  const existing = DriveApp.getFoldersByName(PAPER_FOLDER_NAME);
  let folder = existing.hasNext() ? existing.next() : null;
  if (!folder) {
    const legacyExisting = DriveApp.getFoldersByName(LEGACY_PAPER_FOLDER_NAME);
    folder = legacyExisting.hasNext() ? legacyExisting.next() : DriveApp.createFolder(PAPER_FOLDER_NAME);
  }
  properties.setProperty(PAPER_FOLDER_PROPERTY, folder.getId());
  return folder;
}

function buildStoredPaperName_(className, subject, exam, version, extension) {
  return [className, subject, exam, 'V' + version]
    .map(function(value) {
      return cleanText_(value).replace(/[^a-zA-Z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    })
    .filter(String)
    .join('_') + '.' + extension;
}

function marksKey_(className, subject, exam, component, rollNo) {
  const parts = [
    cleanText_(className).toUpperCase(),
    cleanText_(subject).toUpperCase(),
    cleanText_(exam).toUpperCase(),
    cleanText_(component).toUpperCase(),
    normalizeRoll_(rollNo).toUpperCase()
  ];
  return parts.every(String) ? parts.join('|') : '';
}

function normalizeMarksValue_(value) {
  const raw = cleanText_(value).toUpperCase();
  if (raw === 'AB' || raw === 'ABSENT' || raw === 'A') return 'AB';
  const number = Number(value);
  if (!Number.isFinite(number)) throw new Error('Marks must be a number or AB.');
  return number;
}

function normalizeRoll_(value) {
  const raw = cleanText_(value);
  if (!raw) return '';
  const number = Number(raw);
  return Number.isFinite(number) ? String(number) : raw;
}

function fileExtension_(fileName) {
  const match = String(fileName || '').toLowerCase().match(/\.([a-z0-9]+)$/);
  return match ? match[1] : '';
}

function cleanText_(value) {
  return String(value == null ? '' : value).trim();
}

function isoDate_(value) {
  if (!value) return '';
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? cleanText_(value) : date.toISOString();
}

function formatBytes_(bytes) {
  if (!bytes) return '0 KB';
  if (bytes < 1024 * 1024) return Math.max(1, Math.round(bytes / 1024)) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function toBoolean_(value, fallback) {
  if (typeof value === 'boolean') return value;
  if (value === 'true' || value === 1 || value === '1') return true;
  if (value === 'false' || value === 0 || value === '0') return false;
  return Boolean(fallback);
}

function htmlEscape_(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function nl2br_(value) {
  return String(value || '').replace(/\r?\n/g, '<br>');
}

function jsonOutput_(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}

function safeErrorMessage_(error) {
  return error && error.message ? String(error.message) : String(error || 'Unknown server error.');
}
function authorizeDriveOnce() {
  const folder = getQuestionPaperFolder_();
  Logger.log("Drive authorised. Folder ID: " + folder.getId());
}
function authorizeDriveWriteOnce() {
  const folder = getQuestionPaperFolder_();

  const file = folder.createFile(
    "BGPS_PERMISSION_TEST.txt",
    "Drive write permission verified"
  );

  console.log("SUCCESS: " + file.getId());
  file.setTrashed(true);
}
